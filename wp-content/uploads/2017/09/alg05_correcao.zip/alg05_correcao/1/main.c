#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que calcule a media ponderada das notas de 3 provas. 
A primeira e a segunda prova tem peso 1 e a terceira tem peso 2. 
Ao final, mostrar a media do aluno e indicar se o aluno foi aprovado 
ou reprovado. A nota para aprova��o deve ser igual ou superior a 60
pontos.
*/

int main(int argc, char *argv[]) {
	float n1, n2, n3, media;
	//entrada
	printf("Informe um valor para n1:");
	scanf("%f", &n1);
	printf("Informe um valor para n2:");
	scanf("%f", &n2);	
	printf("Informe um valor para n3:");
	scanf("%f", &n3);
	//processamento
	media = ((n1*1) + (n2*1) + (n3*2))/4;
	if(media >= 60.00)
	{
		//saida
		printf("Aluno aprovado %.2f", media);		
	}
	else
	{
		//saida
		printf("Aluno reprovado %.2f", media);			
	}
	
	return 0;
}





