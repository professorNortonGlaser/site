#include <stdio.h>
#include <stdlib.h>

/* 
Leia o salario de um trabalhador e o valor da presta��o de um empr�stimo. 
Se a presta��o for maior que 20% do salario imprima:  Empr�stimo n�o concedido, 
caso contrario imprima:  Empr�stimo concedido.
*/

int main(int argc, char *argv[]) {
	float salario, valorMensal, percentual;
	//entrada
	printf("Informe o valor do salario:");
	scanf("%f", &salario);
	printf("Informe o valor da prestacao mensal:");
	scanf("%f", &valorMensal);
	//processamento
	percentual = salario * 0.2; // 0.2 = 20/100;
	if(percentual >= valorMensal){
		printf("Emprestimo concedido ! limite de %f", percentual);
	}
	else {
		printf("Emprestimo nao concedido ! limite de %f", percentual);
	}
	
	return 0;
}
