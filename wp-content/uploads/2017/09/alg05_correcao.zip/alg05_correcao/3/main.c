#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo em C que receba um numero inteiro 
e verifique se este e positivo ou negativo, exiba uma mensagem
*/

int main(int argc, char *argv[]) {
	int numero;
	//entrada
	printf("Informe um valor:");
	scanf("%d", &numero);
	if(numero > 0){
		printf("Numero %d positivo!", numero);
	}
	else {
		printf("Numero %d negativo!", numero);
	}
	
	return 0;	
}
