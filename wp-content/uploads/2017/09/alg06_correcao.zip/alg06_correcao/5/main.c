#include <stdio.h>
#include <stdlib.h>

/* 
Desenvolva um programa em C que:
Leia 4 (quatro) n�meros;
Calcule o quadrado de cada um;
Se o valor resultante do quadrado do terceiro for >= 1000, imprima-o e finalize;
Caso contr�rio, imprima os valores lidos e seus respectivos quadrados.
*/

int main(int argc, char *argv[]) {
	int a,b,c,d,qA,qB,qC,qD;
	
	printf("Informe um valor para a:");
	scanf("%d", &a);
	printf("Informe um valor para b:");
	scanf("%d", &b);
	printf("Informe um valor para c:");
	scanf("%d", &c);
	printf("Informe um valor para d:");
	scanf("%d", &d);
	qA = a * a;
	qB = b * b;
	qC = c * c;
	qD = d * d;
	if(qC > 1000){
		printf("Quadrado do terceiro %d", qC);	
	} 
	else {
		printf("A= %d Quadrado = %d\n",a, qA);	
		printf("B= %d Quadrado = %d\n",b, qB);	
		printf("C= %d Quadrado = %d\n",c, qC);	
		printf("D= %d Quadrado = %d\n",d, qD);	
	}
		
	
	return 0;
}
