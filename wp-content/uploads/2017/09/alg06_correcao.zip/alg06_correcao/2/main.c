#include <stdio.h>
#include <stdlib.h>

/* Informe dois n�meros reais e um n�mero inteiro que represente a opera��o 
matem�tica a ser realizada (1-soma, 2-subtra��o, 3- multiplica��o, 4-divis�o) 
utilize o comando sele��o aninhado e exiba o resultado da opera��o matem�tica escolhida. */

int main(int argc, char *argv[]) {
	float a,b, resultado;
	int op;
	
	printf("1-soma\n2-subtrair\n3-multiplicar\n4-dividir\nEscolha a operacao:");
	scanf("%d",&op);
	printf("Informe um valor a:");
	scanf("%f",&a);
	printf("Informe um valor b:");
	scanf("%f",&b);
	if(op>4){
		printf("Operacao invalida !!!");	
	} 
	else{	
		if(op==1){
			resultado = a +b;	
		} 
		else{
			if(op==2){
				resultado = a - b;	
			}
			else {
				if(op==3){
					resultado = a * b;
				} 
				else{
					resultado = a/b;				
				}
			}	
		} 
		printf("O resultado da opercao = %f", resultado);
	}
	return 0;
}
