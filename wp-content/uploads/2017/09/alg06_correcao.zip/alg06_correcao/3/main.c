#include <stdio.h>
#include <stdlib.h>

/* 
 Jo�o, comprou um PC para controlar o rendimento di�rio de seu trabalho. 
 Toda vez que ele traz um peso de peixes maior que o estabelecido pelo regulamento de pesca do estado 
 de S�o Paulo (50 quilos) deve pagar um multa de R$ 4,00 por quilo excedente. 
 Jo�o precisa que voc� fa�a um programa em C  
 que leia a vari�vel P (peso de peixes) e verifique se h� excesso. 
 Se houver, gravar na vari�vel E (Excesso) e na vari�vel M o valor da multa que Jo�o dever� pagar. 
 Caso contr�rio mostrar tais vari�veis com o conte�do ZERO.
 */

int main(int argc, char *argv[]) {
	float E,P,M;
	//Entrada
	printf("Informe o peso total:");
	scanf("%f", &P);
	//processamento
	if(P>50)
	{
		E = P - 50;
		M = E * 4.00;		
	} 
	else
	{
		E = 0;
		M = 0;
	}
	printf("Peso=%f, Excesso=%f, Multa=%f", P, E, M);
	
	return 0;
}
