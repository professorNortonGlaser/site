﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="sessao.aspx.cs" Inherits="pw13_correcao.sessao" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        nome:
        <asp:TextBox ID="txtNome" runat="server"></asp:TextBox>
        <br />        email:
        <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
        <br />       telefone:
        <asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox>
        <br />        senha:
        <asp:TextBox ID="txtSenha" runat="server"></asp:TextBox>
        <br />
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" Text="Voltar" OnClick="voltar" />
    
    </div>
    </form>
</body>
</html>
