﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw13_correcao
{
    public partial class sessao : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtEmail.Text = Session["email"].ToString();
            txtNome.Text = (String)Session["nome"];
            txtSenha.Text = Session["senha"].ToString();
            txtTelefone.Text = Session["telefone"].ToString();
        }

        protected void voltar(object sender, EventArgs e)
        {
            Response.Redirect("index.html");
        }
    }
}