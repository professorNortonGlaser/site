﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using MySql.Data.MySqlClient;
using System.Data;

namespace pw14_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) //e a primeira carga
            {
                carregarLivros();
            }
        }

        private void carregarLivros(){
            String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select titulo from livro order by titulo";
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql,conexao);
            DataSet ds = new DataSet();
            conversor.Fill(ds, "tb1");
            conexao.Close();
            cboProduto.DataSource = ds.Tables["tb1"];
            cboProduto.DataTextField = "titulo";
            cboProduto.DataBind();
        }

        protected void Enviar(object sender, EventArgs e)
        {
            MailAddress de = new MailAddress("fatecpwAds2016@outlook.com"); 
            MailAddress para = new MailAddress(txtEmail.Text);
            MailMessage email = new MailMessage();
            email.From = de;
            email.To.Add(para);
            email.IsBodyHtml = true;
            email.Subject = "Orçamento de produtos";
            String corpo = "Nome: " + txtNome.Text + "<br>" +
                            "Email: " + txtEmail.Text + "<br>" +
                            "Telefone:" + txtTelefone.Text + "<br>" +
                            "Produto:" + cboProduto.SelectedValue + "<br>" +
                            "Qtd:" + txtQtd.Text + "<br>" +
                            "Obs:" + txtMsg.Text + "<Br>";
            email.Body = corpo;
            try
            {
                SmtpClient smtp = new SmtpClient("smtp-mail.outlook.com");
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.Credentials = new
                    NetworkCredential("fatecpwAds2016@outlook.com", "FreiJoao59");
                smtp.Send(email);
                lblMensagem.Text = "Email Enviado com sucesso!";

            }
            catch (Exception err)
            {
                lblMensagem.Text = "Ocorreu um erro tenta mais tarde !" + err.Message;
            }


        }
    }
}