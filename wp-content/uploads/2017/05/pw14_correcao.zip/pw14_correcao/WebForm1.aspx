﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw14_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <asp:ScriptManager ID="ScriptManager1" runat="server">
        </asp:ScriptManager>
        <br />
        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
                <h1>Orçamento</h1>
                Nome:
                <asp:TextBox ID="txtNome" runat="server"></asp:TextBox>              
                <br />
                <br />
                email:
                <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
                <br />               <br />
                Telefone:
                <asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox>  <br />          <br />
                Produto:
                <asp:DropDownList ID="cboProduto" runat="server">
                </asp:DropDownList>             <br />             <br />
                Qtd:
                <asp:TextBox ID="txtQtd" runat="server" TextMode="Number"></asp:TextBox>                <br />                <br />
                Mensagem:
                <asp:TextBox ID="txtMsg" runat="server" TextMode="MultiLine"></asp:TextBox>                <br /><br />
                <asp:Button ID="Button1" runat="server" Text="Enviar" OnClick="Enviar" />                <br />                <br />
                <asp:Label ID="lblMensagem" runat="server" Text=""></asp:Label><br />
                <br />
            </ContentTemplate>
        </asp:UpdatePanel>
        <asp:UpdateProgress ID="UpdateProgress1" runat="server">
            <ProgressTemplate>
                Enviando......
            </ProgressTemplate>
        </asp:UpdateProgress>
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
