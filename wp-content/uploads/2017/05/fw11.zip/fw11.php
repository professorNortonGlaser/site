﻿<html>
<body>
<?php
	$cod="";
	$nom="";
	$val="";
	$qtd="";
	$con = new mysqli("localhost","root", "root","fweb");
	if(isset($_POST["bt1"])){
		$cod=$_POST["cod"];
		$nom=$_POST["nom"];
		$val=$_POST["val"];
		$qtd=$_POST["qtd"];
		$sql="insert into produto(codigo, nome, valor, qtd) values($cod,'$nom',$val,$qtd)";
		mysqli_query($con, $sql);
		echo "Registro inserido com sucesso!";
	}
	if(isset($_POST["bt3"])){
		$cod=$_POST["cod"];
		$nom=$_POST["nom"];
		$val=$_POST["val"];
		$qtd=$_POST["qtd"];
		$sql="update produto set nome='$nom', valor=$val, qtd=$qtd where codigo=$cod";
		mysqli_query($con, $sql);
		echo "Registro alterado com sucesso!";
	}
	if(isset($_POST["bt4"])){
		$cod=$_POST["cod"];
		$sql="delete from produto where codigo=$cod";
		mysqli_query($con, $sql);
		echo "Registro removido com sucesso!";
	}
	if(isset($_POST["bt2"])){
		$cod=$_POST["cod"];
		$sql="select * from produto where codigo=$cod";
		$reg = mysqli_query($con, $sql);
		if($col = mysqli_fetch_array($reg)){
			$cod = $col["codigo"];	
			$nom = $col["nome"];	
			$val = $col["valor"];	
			$qtd = $col["qtd"];	
		} else {
			echo "Registro não encontrado";
		}
	}
	
	$con->close();
?>
<form method="post" action="fw11.php"> 
codigo:<input type="text" id="codigo" name="cod"
value="<?php echo $cod; ?>" /><br>
nome:<input type="text" id="nome" name="nom"
value="<?php echo $nom; ?>" /><br>
valor:<input type="text" id="valor" name="val"
value="<?php echo $val; ?>" /><br>
qtd:<input type="text" id="qtd" name="qtd"
value="<?php echo $qtd; ?>" /><br>
<input type="submit" name="bt1" value="Inserir">
<input type="submit" name="bt2" value="Pesquisar">
<input type="submit" name="bt3" value="Alterar">
<input type="submit" name="bt4" value="Excluir">
</form>
</body>
</html>
