#include <stdio.h>
#include <stdlib.h>

/* 
8- Crie um algoritmo onde ser� informado um valor inteiro inicial,  
e um la�o o usu�rio devera informar outro numero inteiro, 
o programa dever� responder se o numero atual e menor ou maior 
 que o numero inicial informado,
  o la�o somente ser� interrompido quando o numero atual
  for igual ao n�mero anterior informado. 
  Exiba quantas tentativas foram necess�rias para que o numero 
  fosse descoberto.
 */

int main(int argc, char *argv[]) {
int x, num, cont;
	cont = 0;
	printf("Informe um numero a ser descoberto:");
	scanf("%d",&x);
	system("cls");
	do{
		printf("Informe um numero:");
		scanf("%d",&num);
		if(num>x){
			printf("X e menor ! \n");			
			cont++;		
		} else {
			if(num<x){
				printf("X e maior ! \n");				
				cont++;		
			}				
		}					
	}while(num!=x);
	printf("Vc precisou de %d tentativas ", cont);
	
	
	return 0;
}
