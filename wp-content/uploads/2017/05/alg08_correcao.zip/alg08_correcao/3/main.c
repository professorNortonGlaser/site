#include <stdio.h>
#include <stdlib.h>

/* 
3- Fa�a um la�o que calcule a media de todos os n�meros informados,
 a condi��o de termino do la�o e quando for digitado ZERO
 */

int main(int argc, char *argv[]) {
	int cont;
	float numero, media;
	cont=0;
	media=0;
	do{
		printf("Informe um numero:");
		scanf("%f",&numero);
		if(numero !=0){		
			media = media + numero;
			cont++;		
		}
	}while(numero != 0);
	media = media / cont;
	printf("A media dos numeros informado= %f", media);
	
	
	
	return 0;
}
