#include <stdio.h>
#include <stdlib.h>

/* 
4- fa�a um la�o �fa�a at� com 10 intera��es, 
verifique quantas vezes n�meros m�ltiplos de 2 e de 3 s�o informados
*/

int main(int argc, char *argv[]) {
	int i, cont, numero, resto2, resto3;
	cont=0;
	for(i=0;i<10;i++){
		printf("Informe um numero:");	
		scanf("%d",&numero);
		resto2 = numero % 2;
		resto3 = numero % 3;
		if(resto2==0 && resto3==0){
			cont++;	
		}
	}
	printf("O total de numeros multiplos de 2 e 3 =%d", cont);
	
	return 0;
}
