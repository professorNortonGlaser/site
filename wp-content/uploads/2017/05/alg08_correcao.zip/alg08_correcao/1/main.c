#include <stdio.h>
#include <stdlib.h>

/* 
Dado o algoritmo abaixo escrito em C :
int i, a, b;
for(i=0; i<20; i++) // x a y
{
   scanf("%d",&a);
   scanf("%d",&b);
   r = a + b;
   printf("%d\n", r);
}
a- reescreva com o la�o enquanto fa�a (while)
b- reescreva com o la�o fa�a enquanto (do while)
*/

int main(int argc, char *argv[]) {
	int i, a, b, r;
	i = 0;
	while(i<20){ //0 a N
		scanf("%d",&a);
   		scanf("%d",&b);
		r = a + b;
   		printf("%d\n", r);		
		i=i+1; // i++;			
	}
	i=0;
	do{		// 1 a N
		scanf("%d",&a);
   		scanf("%d",&b);
		r = a + b;
   		printf("%d\n", r);	
		i++;		
	}while(i<20);
	
	return 0;
}
