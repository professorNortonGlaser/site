#include <stdio.h>
#include <stdlib.h>

/* 
2- Dado o algoritmo abaixo escrito em C :

int x = 10;
while(x>0)
{
  prinf("%d",x);
  x--;
}
a- reescreva com o la�o fa�a at� (for)
b- reescreva com o la�o fa�a enquanto (do while)
 */

int main(int argc, char *argv[]) {
	int x = 10;
	while(x>0) // 0 a N
	{
  		printf("%d \n",x);
  		x--;
	}
	for(x=10;x>0;x--){  // x a Y
		printf("%d \n",x);
	}
	x = 10;
	do{ // 1 a N
		printf("%d \n",x);
  		x--;	
	}while(x>0);
	
	
	return 0;
}
