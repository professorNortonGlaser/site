#include <stdio.h>
#include <stdlib.h>

/* 
5- Crie um la�o e verifique qual a maior sequencia de n�meros pares 
informados, o la�o fara 10 itera��es.
Exe:  1, 2,3,4,6,8,5,3,2,5,8,4,0   Sequencia :4,6,8   , 3 n�meros
 */

int main(int argc, char *argv[]) {
	int i,numero, seq, maiorSeq, resto2;
	seq = 0;
	maiorSeq = 0;

	for(i=0;i<10;i++){
		printf("Informe um numero:");
		scanf("%d",&numero);	
		resto2 = numero % 2;
		if(resto2==0){
			seq++;	
		} else {
			if(seq > maiorSeq){
				maiorSeq = seq;
			}	
			seq = 0;
		}				
	}
	printf("A maior sequencia foi de %d itens", maiorSeq);


	return 0;
}
