<html>
	<body>
	<form method="post" action="login.php">
	Email:<input type="text" name="ema" /><br>
	Senha:<input type="password" name="sen" /><br>
	<input type="submit" value="Entrar" name="bt1">
	</form>
	<?php
		if(isset($_POST["bt1"])){
			fazerLogin();	
		}
	?>
	</body>
</html>	
<?php

function fazerLogin(){
	$email = $_POST["ema"];
	$senha = $_POST["sen"];
	$con = new mysqli("localhost","root","root","fweb");
	$sql = "select * from usuario where email='$email' and senha='$senha'";
	$reg = mysqli_query($con,$sql);
	if($col = mysqli_fetch_array($reg)){
		session_start();
		$_SESSION["codigo"] = $col["codigo"];
		$_SESSION["nome"] = $col["nome"];
		header('location: http://localhost/segura.php');
	} else {
		echo "Email ou senha ivalidos!";	
	}
	$con->close();
}
?>