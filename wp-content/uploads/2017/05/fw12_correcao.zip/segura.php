<html>
	<body>
	<?php
		session_start();
		if(isset($_POST["btn2"])){
			session_destroy();		
		}
	
			
		if(isset($_SESSION["codigo"])==false)
		{
			header("Location: http://localhost/login.php");	
		}
		echo "Ola, ".$_SESSION["nome"].", bem vindo!";
	?>
	<form method="post" action="segura.php">
	<input type="submit" value="sair" name="btn2">
	</form>
	

	</body>
</html>	