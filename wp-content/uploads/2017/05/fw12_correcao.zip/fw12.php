<html>
	<body>
	<table border="1">
	<tr><td><b>codigo</b></td>
		<td><b>nome</b></td>		
		<td><b>email</b></td> 		 
		<td><b>senha</b></td>	
	</tr>
	<?php carregaLista(); ?>
	</table>
	</body>
</html>
<?php
function carregaLista(){
	$con = new mysqli("localhost","root","root","fweb");
	$sql = "select * from usuario order by nome";
	$reg = mysqli_query($con, $sql);
	$cor = "white";
	while($col = mysqli_fetch_array($reg)){
		echo "<tr bgcolor='$cor'><td>".$col["codigo"]."</td>";
		echo "<td>".$col["nome"]."</td>";
		echo "<td>".$col["email"]."</td>";
		echo "<td>".$col["senha"]."</td></tr>";
		if($cor=="white") {
			$cor = "cyan";	
		} else {
			$cor = "white";	
		}
			
	}		
	$con->close();
}
?>	