﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient; 
using System.Data;

namespace pw12
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            // isPostBack = False (primeira carga)
            if (!IsPostBack)
            {
                carregar();
            }
        }

        private void carregar()
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from cliente order by nome";
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            MySqlDataReader registros = comando.ExecuteReader();
            DropDownList1.Items.Clear();
            String aux = "";
            while (registros.Read())
            {
                String nome = registros["nome"].ToString();
                DropDownList1.Items.Add(nome);
                aux = aux + registros["codigo"].ToString() + ", " +
                            registros["nome"].ToString() + "<br>";
            }
            Literal1.Text = aux;
            conexao.Close();

        }

        protected void carregar(object sender, EventArgs e)
        {
            carregar();
        }

        protected void carregarBind(object sender, EventArgs e)
        {            
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from cliente order by nome";
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql, conexao);
            conversor.Fill(ds, "consultaCliente");
            conexao.Close();

            BulletedList1.DataSource = ds.Tables["consultaCliente"];
            BulletedList1.DataTextField = "email";
            BulletedList1.DataBind();

            GridView1.DataSource = ds.Tables["consultaCliente"];
            GridView1.DataBind();

        }
    }
}