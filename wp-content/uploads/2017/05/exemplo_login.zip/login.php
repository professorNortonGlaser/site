<html>
	<body>
	<form method="post" action="login.php">
	Email:
	<input type="text" name="email" id="email">
	<br>
	Senha:
	<input type="password" name="senha" id="senha">
	<br>
	<input type="submit" value="entrar" name="bt1">	
	<?php
		if(isset($_POST["bt1"])){
			verificar();	
		}
	?>	
	</form>	
	</body>
</html>	
<?php
	function verificar(){
		$con = new mysqli("localhost","root","root","jogos");
		$email = $_POST["email"];
		$senha = $_POST["senha"];
		$sql = "select * from usuario where	email='$email' and senha='$senha'";
		$reg = mysqli_query($con, $sql);
		if($col = mysqli_fetch_array($reg)){
			session_start();
			$_SESSION["codigo"] = $col["codigo"];
			$_SESSION["nome"] = $col["nome"];	
			header("location: http://localhost/usuario.php");
		} else {
			echo "usuario ou senha invalidos!";
		}
		$con->close();
	}
?>	