<html>
<body>
<?php
	session_start();
	echo "Ola,". $_SESSION["nome"] . " seja bem vindo !";
?>
</body>
</html>