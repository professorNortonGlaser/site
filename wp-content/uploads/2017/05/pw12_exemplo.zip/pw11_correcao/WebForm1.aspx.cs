﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

namespace pw11_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {
            carregarPagina();
            if (Session["codigo"] != null)
            {
                Label1.Text = (String)Session["nome"];
            }
        }

        private void carregarPagina()
        {
            DataSet ds = new DataSet(); //BD em memoria do Servidor Aplicação
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from livro";
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql, conexao);
            conversor.Fill(ds, "todosLivros");

            sql = "select * from livro where valor <50";
            MySqlDataAdapter conversor2 = new MySqlDataAdapter(sql, conexao);
            conversor2.Fill(ds, "promo");
            conexao.Close();
            GridView1.DataSource = ds.Tables["todosLivros"];
            GridView1.DataBind();

            DropDownList1.DataSource = ds.Tables["promo"];
            DropDownList1.DataTextField = "titulo";
            DropDownList1.DataValueField = "codigo";
            DropDownList1.DataBind();

        }
    }
}