﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="login.aspx.cs" Inherits="pw11_correcao.login" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <br />
        <br />
        Email:<asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
        <br />
        <br />
        <br />
        Senha:<asp:TextBox ID="txtSenha" runat="server" TextMode="Password"></asp:TextBox>
        <br />
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="Entrar" Text="Entrar" />
        <br />
        <br />
        <br />
        <asp:Label ID="lblMensagem" runat="server" Text="Label"></asp:Label>
    
    </div>
    </form>
</body>
</html>
