﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace pw11_correcao
{
    public partial class login : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Entrar(object sender, EventArgs e)
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            String sql = "select * from cliente where email='{0}' and senha='{1}'";
            sql = String.Format(sql, txtEmail.Text, txtSenha.Text);
            conexao.Open();
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            MySqlDataReader registro = comando.ExecuteReader();
            if (registro.Read())
            {
                //criando varianveis de sessao
                Session["codigo"] = registro["codigo"].ToString();
                Session["nome"] = registro["nome"].ToString();
                //Response.Redirect => redireciona para outra pagina
                Response.Redirect("webForm1.aspx");
            }
            else
            {
                lblMensagem.Text = "Usuario ou senha invalidos";
            }
            conexao.Close();

        }
    }
}