﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace pw09_correcao
{
    public partial class livro : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {
            //isPostBack==true a pagina recarregada == false e a primeira vez
            if(!IsPostBack) // se for a primeira vez 
            {
                //REQUEST["nome do parametro"] para recuperar valores enviados GET/POST
                txtCodigo.Text = Request["cod"];
                pesquisar();
            }
        }

        protected void inserir(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "insert into livro(titulo, autor, qtd, valor, " +
                    "paginas, resumo) values('{0}','{1}',{2},{3},{4},'{5}')";
                sql = String.Format(sql, txtTitulo.Text, txtAutor.Text, txtQtd.Text,
                    txtValor.Text, txtPaginas.Text, txtResumo.Text);
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery(); //nao retorna valores;
                conexao.Close();
                Label1.Text = "Registro inserido !";
            }
            catch (Exception err)
            {
                Label1.Text = "ocorreu um erro !" + err.Message;
            }


        }

        protected void pesquisar(object sender, EventArgs e)
        {
            pesquisar();
        }

        private void pesquisar()
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "select * from  livro where codigo=" + txtCodigo.Text;
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                MySqlDataReader registro = comando.ExecuteReader();
                if (registro.Read())
                {
                    txtAutor.Text = registro["autor"].ToString();
                    txtPaginas.Text = registro["paginas"].ToString();
                    txtQtd.Text = registro["qtd"].ToString();
                    txtResumo.Text = registro["resumo"].ToString();
                    txtTitulo.Text = registro["titulo"].ToString();
                    txtValor.Text = registro["valor"].ToString();
                    Label1.Text = "";
                }
                else
                {
                    Label1.Text = "Registro não existe";
                }
                conexao.Close();

            }
            catch (Exception err)
            {
                Label1.Text = "ocorreu um erro !" + err.Message;
            }
        }

        protected void alterar(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "update livro set titulo='{0}', autor='{1}', qtd='{2}', valor='{3}', " +
                    "paginas='{4}', resumo='{5}' where codigo={6}";
                sql = String.Format(sql, txtTitulo.Text, txtAutor.Text, txtQtd.Text,
                    txtValor.Text, txtPaginas.Text, txtResumo.Text, txtCodigo.Text);
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery(); //nao retorna valores;
                conexao.Close();
                Label1.Text = "Registro alterado!";
            }
            catch (Exception err)
            {
                Label1.Text = "ocorreu um erro !" + err.Message;
            }
        }

        protected void excluir(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "delete from livro where codigo=" + txtCodigo.Text;
                
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery(); //nao retorna valores;
                conexao.Close();
                Label1.Text = "Registro removido!";
            }
            catch (Exception err)
            {
                Label1.Text = "ocorreu um erro !" + err.Message;
            }
        }
    }
}