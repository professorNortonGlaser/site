#include <stdio.h>
#include <stdlib.h>

/* 
  fa�a um algoritmo que implemente um vetor de 20 posi��es,
  leia as 20 posi��es e identifique em um novo la�o,
  qual o maior e menor numero informado 
  e qual a media dos n�meros informados.
 */

int main(int argc, char *argv[]) {
	float numeros[20];
	float maior, menor, media=0;
	int c;
	for(c=0;c<20;c++){
		printf("Informe um valor para o item %d=", c);
		scanf("%f",&numeros[c]);	
	}
	for(c=0;c<20;c++){
		if(c==0){
			maior = numeros[c];
			menor = numeros[c];			
		} else {
			if(numeros[c] > maior){
				maior = numeros[c];	
			}
			if(numeros[c] < menor){
				menor = numeros[c];	
			}	
		}	
		media = media + numeros[c];
	}
	media = media /20 ;
	printf("Menor=%f, maior=%f, media=%f", menor, maior, media);
	return 0;
}
