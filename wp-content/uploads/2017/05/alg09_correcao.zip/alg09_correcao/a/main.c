#include <stdio.h>
#include <stdlib.h>

/* 
a- Fa�a um algoritmo que armazene um vetor de inteiros de 20 posi��es,
 identifique  o percentual de n�meros impares e de n�meros pares 
 informados.
 */

int main(int argc, char *argv[]) {
	int numeros[20];
	int i, resto;
	float percPar=0;
	float percImpar=0;
	for(i=0;i<20;i++){
		printf("Informe um valor para o item %d=", i);	
		scanf("%d",&numeros[i]);
	}
	for(i=0;i<20;i++){
		resto = numeros[i] % 2;
		if(resto==0){
			percPar++;	
		} else {
			percImpar++;	
		}	 
	}
	percPar = (percPar/20)*100;
	percImpar = (percImpar/20)*100;
	printf("Pares %f, impares %f",percPar, percImpar);
	
	
	
	return 0;
}
