<html>
	<head>
		<link rel="stylesheet" href="estilo.css">
	</head>
	<body>
	<?php montaVitrine(); ?>	
	</body>
</html>
<?php
	function montaVitrine(){
		$con = new mysqli("localhost", "root", "root", "jogos");
		$sql = "select * from produto order by nome";
		$reg = mysqli_query($con, $sql);
		while($col = mysqli_fetch_array($reg)){
			echo "<div class='produto'>";
			echo "<h3>". $col["nome"] ."</h3>";
			echo "<img src='pro".$col["codigo"] .".jpg'>";
			echo "R$ ". $col["valor"] ."<br>";
			echo "<a href='detalhe.php?id=". $col["codigo"] ."'>[+ detalhes]</a>";
			echo "</div>";
		}			
		$con->close();
	}	
?> 	