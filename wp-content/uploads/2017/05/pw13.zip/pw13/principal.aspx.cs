﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw13
{
    public partial class principal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["codigoCliente"]==null)
            {
                Response.Redirect("login.aspx");
            }

            if (!IsPostBack)
            {
                Label1.Text = "Ola, " + Session["nomeCliente"].ToString();
                Label2.Text = Session.SessionID;
                Application["msg"] = "O sistema sera reiniciado em 1h";
            }

        }

        protected void logoff(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("login.aspx");
        }
    }
}