﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="login.aspx.cs" Inherits="pw13.login" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <h2>Login</h2>
        <p>
            email:<asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
        </p>
        <p>
            senha:<asp:TextBox ID="txtSenha" runat="server" TextMode="Password"></asp:TextBox>
        </p>
        <p>
            <asp:Button ID="Button1" runat="server" OnClick="acessar" Text="Entrar" />
        </p>
        <p>
            <asp:Label ID="lblMensagem" runat="server"></asp:Label>
        </p>
    
    </div>
    </form>
</body>
</html>
