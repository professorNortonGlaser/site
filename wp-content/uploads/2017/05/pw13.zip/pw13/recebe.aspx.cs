﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw13
{
    public partial class recebe : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String nome, idade;
            //REQUEST => recuperar os parametros enviados via GET ou via POST
            nome = Request["nome"];
            idade = Request["idade"];

            TextBox1.Text = nome;
            TextBox2.Text = idade;

        }
    }
}