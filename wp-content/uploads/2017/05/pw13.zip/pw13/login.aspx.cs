﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient; //adicionei

namespace pw13
{
    public partial class login : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void acessar(object sender, EventArgs e)
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            string sql = "select * from cliente where email='" + txtEmail.Text 
                    + "' and senha='"+ txtSenha.Text +"'";
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            MySqlDataReader registro = comando.ExecuteReader();
            if (registro.Read())
            {
                Session["codigoCliente"] = registro["codigo"].ToString();
                Session["nomeCliente"] = registro["nome"].ToString();
                //redirecionar para outra pagina
                Response.Redirect("principal.aspx");
            }
            else
            {
                lblMensagem.Text = "Usuario ou senha invalidos !";
            }
            conexao.Close();
        }
    }
}