﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace pw09_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void somar(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(TextBox1.Text);
                double b = Convert.ToDouble(TextBox2.Text);
                double r = a + b;
                Label1.Text = Convert.ToString(r);
            }
            catch (Exception err)
            {
                Label1.Text = "Ocorreu um erro, verifique os numeros !";
                String erro = DateTime.Now + "=>" + err.Message;
                File.AppendAllText("C:\\Users\\Public\\erro.log", erro);
            }
        }

        protected void subtrair(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(TextBox1.Text);
                double b = Convert.ToDouble(TextBox2.Text);
                double r = a - b;
                Label1.Text = Convert.ToString(r);
            }
            catch (Exception err)
            {
                Label1.Text = "Ocorreu um erro, verifique os numeros !";
                String erro = DateTime.Now + "=>" + err.Message;
                File.AppendAllText("C:\\Users\\Public\\erro.log", erro);
            }
        }

        protected void multiplicar(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(TextBox1.Text);
                double b = Convert.ToDouble(TextBox2.Text);
                double r = a * b;
                Label1.Text = Convert.ToString(r);
            }
            catch (Exception err)
            {
                Label1.Text = "Ocorreu um erro, verifique os numeros !";
                String erro = DateTime.Now + "=>" + err.Message;
                File.AppendAllText("C:\\Users\\Public\\erro.log", erro);
            }
        }

        protected void dividir(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(TextBox1.Text);
                double b = Convert.ToDouble(TextBox2.Text);
                double r = a / b;
                Label1.Text = Convert.ToString(r);
            }
            catch (Exception err)
            {
                Label1.Text = "Ocorreu um erro, verifique os numeros !";
                String erro = DateTime.Now + "=>" + err.Message;
                File.AppendAllText("C:\\Users\\Public\\erro.log", erro);
            }
        }
    }
}