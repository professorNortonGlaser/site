﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw09_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <h1>Calculadora</h1>
        <p>
            N1:<asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
        </p>
        <p>
            N2:<asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>
        </p>
        <p>
            <asp:Button ID="Button1" runat="server" OnClick="somar" Text="+" />
            <asp:Button ID="Button2" runat="server" OnClick="subtrair" Text="-" />
            <asp:Button ID="Button3" runat="server" OnClick="multiplicar" Text="*" />
            <asp:Button ID="Button4" runat="server" OnClick="dividir" Text="/" />
        </p>
        <p>
            <asp:Label ID="Label1" runat="server"></asp:Label>
        </p>
    
    </div>
    </form>
</body>
</html>
