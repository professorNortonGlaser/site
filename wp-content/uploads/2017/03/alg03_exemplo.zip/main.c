#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float a, b, c, media;
	//printf comando para imprimir uma msg na tela
	printf("Informe um valor para A :");
	// %f - identifica q vamos ler um valor real
	scanf("%f",&a);
	printf("Informe um valor para B :");	
	scanf("%f",&b);	
	printf("Informe um valor para C :");	
	scanf("%f",&c);	

	media = (a+b+c)/3;
	printf("A media = %f ", media);

	return 0;
}
