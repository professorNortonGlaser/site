﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw10_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    Data de Inscrição 
        <br />
        <asp:TextBox ID="txtData" runat="server"></asp:TextBox>
        <asp:RangeValidator ID="RangeValidator1" runat="server" ControlToValidate="txtData" ErrorMessage="– Período de 01/07/2017 ate 31/12/2017" MaximumValue="31/12/2017" MinimumValue="01/07/2017" Type="Date"></asp:RangeValidator>
        <br />
Email 
        <br />
        <asp:TextBox ID="txtEmail" runat="server" OnTextChanged="TextBox2_TextChanged"></asp:TextBox>
        <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" ControlToValidate="txtEmail" ErrorMessage="– validação de e-mail valido" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
        <br />
Senha<br />
        <asp:TextBox ID="txtSenha" runat="server" TextMode="Password"></asp:TextBox>
        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtSenha" ErrorMessage="– campo obrigatório"></asp:RequiredFieldValidator>
        <br />
Confirmação de senha 
        <br />
        <asp:TextBox ID="txtConfirma" runat="server" TextMode="Password"></asp:TextBox>
        <asp:CompareValidator ID="CompareValidator1" runat="server" ControlToCompare="txtSenha" ControlToValidate="txtConfirma" ErrorMessage="– verificar se esta igual ao campo senha"></asp:CompareValidator>
        <br />
cep  
        <br />
        <asp:TextBox ID="txtCep" runat="server"></asp:TextBox>
        <asp:RegularExpressionValidator ID="RegularExpressionValidator2" runat="server" ControlToValidate="txtCep" ErrorMessage="– código numérico de 8 dígitos" ValidationExpression="\d{5}(-\d{3})?"></asp:RegularExpressionValidator>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" Text="Button" />
        <asp:Button ID="Button2" runat="server" CausesValidation="False" Text="Button" />
        <br />
    </div>
    </form>
</body>
</html>
