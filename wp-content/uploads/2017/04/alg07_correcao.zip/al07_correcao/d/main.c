#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que dado valor inteiro informado, 
calcule e exiba a tabuada do numero de 1 a 10
x a y => Fa�a at�
 */

int main(int argc, char *argv[]) {
	int num, cont, prod;
	printf("Informe a tabuada a ser calculada:");
	scanf("%d",&num);
	for(cont=1; cont<=10; cont++){
		prod = cont * num;
		printf("%d x %d = %d \n", num, cont, prod);		
	}	
	return 0;
}

