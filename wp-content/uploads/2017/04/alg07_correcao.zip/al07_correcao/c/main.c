#include <stdio.h>
#include <stdlib.h>

/*  Elabore um algoritmo que gere e escreva os n�meros
 �mpares dos n�meros entre 100 e 200. 
 X a Y Fa�a Ate
 */

int main(int argc, char *argv[]) {
	int x;
	int resto;
	
	for(x=100;x<=200;x++)
	{
		resto = x % 2;	
		if(resto==1){
			printf("%d ", x);
		}	
	}
	
	return 0;
}
