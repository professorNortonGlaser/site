#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float saldo = 1000;
	float valor = 0;
	int op;
	int continua = 0;
	
	do
	{		
		printf("Escolha uma alternativa:\n1-Saldo\n2-Saque\n3-Deposito:");
		scanf("%d",&op);
		
		switch(op){
			case 1:{
				printf("Seu saldo = %f", saldo);			
				break;
			}	
			case 2:{
				printf("Qual o valor a ser sacado :");
				scanf("%f", &valor);
				if(valor > saldo){
					printf("Saque nao realizado, valor acima do saldo !");	
				} else {
					saldo = saldo - valor;
					printf("Valor sacado, seu saldo atual = %f", saldo);				
				}
				break;
			}
			case 3:{
				printf("Qual o valor a ser depositado :");
				scanf("%f", &valor);
				saldo = saldo + valor;
				printf("Valor depositado, seu saldo atual = %f", saldo);				
				break;
			}
			default :{
				printf("Alternativa invalida !");			
			}		
		}
		printf("\nDeseja Continua 0-nao 1-sim:");
		scanf("%d", &continua);	
	} while(continua==1);
	return 0;
}
