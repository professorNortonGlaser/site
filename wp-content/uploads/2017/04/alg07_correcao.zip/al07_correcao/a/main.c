#include <stdio.h>
#include <stdlib.h>

/* 
 A � Fa�a um algoritmo que implemente um la�o que leia X n�meros inteiros 
 e identifique qual o menor o maior e a media,
 quando o n�mero informado for zero, interrompa o la�o e exiba os 
 valores.
 1 a N => Fa�a Enquanto
*/

int main(int argc, char *argv[]) {
	int maior=0;
	int menor=0;
	float media = 0;
	int numero = 0;
	int cont = 0;
	
	do //la�o fa�a Enquanto 1 a N
	{
		printf("Informe um numero !");
		scanf("%d", &numero);
		if(numero!=0){	
			if(cont==0){ //quando for a primeira repeti��o, o menor e maior assumem 
				maior = numero;
				menor = numero;	
			} else {							
				if(numero > maior){ //verifica caso maior	
					maior = numero;	
				}				
				if(numero < menor){ //verifico caso menor
					menor = numero;	
				}
			}			
			media = media +numero; //calculo media
			cont++;		
		}
	} while(numero!=0);
	media = media / cont;
	printf("Maior=%d, Menor=%d, Media=%f", maior,menor,media);
	
	
	
	return 0;
}
