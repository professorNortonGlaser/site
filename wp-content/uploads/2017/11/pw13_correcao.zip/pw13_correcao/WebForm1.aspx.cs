﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Data;
using MySql.Data.MySqlClient;

namespace pw13_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (! IsPostBack) // true = A pagina for recarregada
            {
                carregar();   
            }
        }

        private void carregar()
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select codigo, titulo from livro order by titulo";
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql, conexao);
            DataSet ds = new DataSet();
            conversor.Fill(ds, "livros");
            conexao.Close();
            cboProduto.DataSource = ds.Tables["livros"];
            cboProduto.DataValueField = "codigo";
            cboProduto.DataTextField = "titulo";
            cboProduto.DataBind();
        }

        protected void enviarEmail(object sender, EventArgs e)
        {
            MailAddress de = new MailAddress("fatecpwAds2016@outlook.com");
            MailAddress para = new MailAddress(txtEmail.Text);
            MailMessage email = new MailMessage();
            email.From = de;
            email.To.Add(para);
            email.CC.Add(de);
            email.Subject = "Orçamento de produto ";
            String body = "Nome: <b>" + txtNome.Text + "</b><br>" +
                            "Telefone: <b>" + txtTelefone.Text + "</b><br>" +
                            "Produto: <b>" + cboProduto.SelectedValue + "</b><br>" +
                            "Qtd:<b>" + txtQtd.Text + "</b><br>" +
                            "Mensagem:<b>" + txtMsg.Text +"</b><br>";              
            email.Body = body;
            email.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient("smtp-mail.outlook.com");
            try
            {
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.Credentials = new
                    NetworkCredential("fatecpwAds2016@outlook.com", "FreiJoao59");
                smtp.Send(email);
                Label1.Text = "Email enviado com sucesso!";
            }
            catch (Exception err)
            {
                Label1.Text = "Ocorreu um erro" + err.Message;
            }
        }

    }
}