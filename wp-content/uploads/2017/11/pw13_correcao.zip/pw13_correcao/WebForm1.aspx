﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw13_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        Evio de Email com ajax<br />
        <br />
        <asp:ScriptManager ID="ScriptManager1" runat="server">
        </asp:ScriptManager>
        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
                <br />
                Nome:
                <asp:TextBox ID="txtNome" runat="server"></asp:TextBox>
                <br />
                <br />
                email:<asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
                <br />
                <br />
                Telefone:
                <asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox>
                <br />
                <br />
                Produto:
                <asp:DropDownList ID="cboProduto" runat="server">
                </asp:DropDownList>
                <br />
                <br />
                Qtd:
                <asp:TextBox ID="txtQtd" runat="server"></asp:TextBox>
                <br />
                <br />
                Mensagem:<asp:TextBox ID="txtMsg" runat="server" TextMode="MultiLine"></asp:TextBox>
                <br />
                <br />
                <asp:Button ID="Button1" runat="server" OnClick="enviarEmail" Text="Enviar" />
                <br />
                <br />
                <asp:Label ID="Label1" runat="server"></asp:Label>
&nbsp;<asp:UpdateProgress ID="UpdateProgress1" runat="server">
                    <ProgressTemplate>
                        <img src="redirecting.gif" runat="server" />
                    </ProgressTemplate>                    
                </asp:UpdateProgress>
            </ContentTemplate>
        </asp:UpdatePanel>
        <br />
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
