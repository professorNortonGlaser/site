﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="sessao.aspx.cs" Inherits="pw12_correcao.sessao" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        SESSAO.ASPX<br />
        <br />
        <br />
        Nome:<asp:TextBox ID="txtNome" runat="server"></asp:TextBox>
        <br />
        <br />
        Email:<asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
        <br />
        <br />
        Senha:<asp:TextBox ID="txtSenha" runat="server"></asp:TextBox>
        <br />
        <br />
        Telefone:<asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox>
        <br />
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
