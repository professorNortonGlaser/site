﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw12_correcao
{
    public partial class sessao : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
             txtNome.Text= (String)Session["nome"];
             txtEmail.Text= (String)Session["email"];
             txtTelefone.Text= (String)Session["telefone"];
             txtSenha.Text = (String)Session["senha"];
        }
    }
}