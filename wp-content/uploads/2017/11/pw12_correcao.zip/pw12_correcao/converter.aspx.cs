﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw12_correcao
{
    public partial class converter : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["nome"] = Request["nome"];
            Session["email"] = Request["email"];
            Session["senha"] = Request["senha"];
            Session["telefone"] = Request["telefone"];
            Response.Redirect("sessao.aspx");
        }
    }
}