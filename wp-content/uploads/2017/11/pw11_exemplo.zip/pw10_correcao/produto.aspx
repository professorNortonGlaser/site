﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="produto.aspx.cs" Inherits="pw10_correcao.produto" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        correção pw11&nbsp;&nbsp;&nbsp;
        <br />
        <br />
        <asp:Button ID="Button5" runat="server" OnClick="voltar" Text="voltar para a lista" />
        <br />
        <br />
        codigo:<asp:TextBox ID="txtcodigo" runat="server"></asp:TextBox>
        <asp:Button ID="Button2" runat="server" OnClick="pesquisar" Text="Pesquisar" />
        <br />
        <br />
        titulo:<asp:TextBox ID="txttitulo" runat="server"></asp:TextBox>
        <br />
        <br />
        autor:<asp:TextBox ID="txtautor" runat="server"></asp:TextBox>
        <br />
        <br />
        qtd:<asp:TextBox ID="txtQtd" runat="server"></asp:TextBox>
        <br />
        <br />
        valor:<asp:TextBox ID="txtValor" runat="server"></asp:TextBox>
        <br />
        <br />
        paginas:<asp:TextBox ID="txtPaginas" runat="server"></asp:TextBox>
        <br />
        <br />
        resumo:<asp:TextBox ID="txtResumo" runat="server" TextMode="MultiLine"></asp:TextBox>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="inserir" Text="Inserir" />
        <asp:Button ID="Button3" runat="server" OnClick="alterar" Text="Alterar" />
        <asp:Button ID="Button4" runat="server" OnClick="excluir" Text="Excluir" />
        <br />
        <br />
        <asp:Label ID="lblMensagem" runat="server"></asp:Label>
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
