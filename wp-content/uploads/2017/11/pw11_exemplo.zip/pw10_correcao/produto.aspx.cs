﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace pw10_correcao
{
    public partial class produto : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";   
        protected void Page_Load(object sender, EventArgs e)
        {
            // IsPostBack = se a pagina foi recarregada
            if (IsPostBack == false)
            {
                // request - recupera um valor enviado por outra pagina
                txtcodigo.Text = Request["codigo"];
                pesquisar();
            }
        }
        
        protected void inserir(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "insert into livro(titulo, autor, qtd, " +
                "valor, paginas, resumo) values('{0}', '{1}', {2},{3},{4}," +
                "'{5}')";
                sql = String.Format(sql, txttitulo.Text, txtautor.Text, txtQtd.Text,
                    txtValor.Text.Replace(",","."), txtPaginas.Text, txtResumo.Text);
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "registro inserido com sucesso";
            }
            catch (Exception err)
            {
                lblMensagem.Text = "ocorreu um erro " + err.Message;
            }
        }

        protected void pesquisar(object sender, EventArgs e)
        {
            pesquisar();
        }

        private void pesquisar()
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "select * from livro where codigo=" + txtcodigo.Text;
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                MySqlDataReader registro = comando.ExecuteReader();
                if (registro.Read())
                {
                    txtPaginas.Text = registro["paginas"].ToString();
                    txtautor.Text = registro["autor"].ToString();
                    txtQtd.Text = registro["qtd"].ToString();
                    txtResumo.Text = registro["resumo"].ToString();
                    txttitulo.Text = registro["titulo"].ToString();
                    txtValor.Text = registro["valor"].ToString();
                    lblMensagem.Text = "";
                }
                else
                {
                    lblMensagem.Text = "registro nao encontrado!";
                }
                conexao.Close();
            }
            catch (Exception err)
            {
                lblMensagem.Text = "ocorreu um erro " + err.Message;
            }

        }


        protected void alterar(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "update livro set titulo='{0}', autor='{1}', qtd={2}, " +
                "valor={3}, paginas={4}, resumo='{5}' where codigo={6}";
                sql = String.Format(sql, txttitulo.Text, txtautor.Text, txtQtd.Text,
                    txtValor.Text.Replace(",","."), txtPaginas.Text, txtResumo.Text, txtcodigo.Text);
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "registro alterado com sucesso";
            }
            catch (Exception err)
            {
                lblMensagem.Text = "ocorreu um erro " + err.Message;
            }
        }

        protected void excluir(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "delete from livro where codigo="+ txtcodigo.Text;
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "registro removido com sucesso";
            }
            catch (Exception err)
            {
                lblMensagem.Text = "ocorreu um erro " + err.Message;
            }
        }

        protected void voltar(object sender, EventArgs e)
        {
            Response.Redirect("bind.aspx");
        }
    }
}