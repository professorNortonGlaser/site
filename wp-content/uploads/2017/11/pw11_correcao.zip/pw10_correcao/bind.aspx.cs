﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

namespace pw10_correcao
{
    public partial class bind : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;"; 
        protected void Page_Load(object sender, EventArgs e)
        {
            carregarTela();

            DropDownList2.Items.Add("zeta");
        }

        private void carregarTela()
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            string sql = "select *  from livro order by titulo";
            //forma usando data reader
            MySqlCommand comando = new MySqlCommand(sql, conexao);            
            MySqlDataReader registros = comando.ExecuteReader();
            GridView1.DataSource = registros;
            GridView1.DataBind();
            registros.Close();

            //forma usanddo data adapter
            DataSet ds = new DataSet(); //repositorio em memoria
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql, conexao);
            conversor.Fill(ds, "todos"); // todos e o apelido da tabela dentro do ds
            conexao.Close();

            DropDownList1.DataSource = ds.Tables["todos"];
            DropDownList1.DataTextField = "autor";
            DropDownList1.DataValueField = "codigo";
            DropDownList1.DataBind();

            CheckBoxList1.DataSource = ds.Tables["todos"];
            CheckBoxList1.DataTextField = "titulo";
            CheckBoxList1.DataValueField = "codigo";
            CheckBoxList1.DataBind();
        }


    }
}