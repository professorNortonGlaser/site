﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw12_correcao
{
    public partial class cookie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                String cookie1 = Request.Cookies["login"].Value;
                String cookie2 = Request.Cookies["UltimoLivro"].Value;
                Response.Write("Ola " + cookie1 + ", vc quer comprar " + cookie2);
            }
            catch(Exception err){

            }
        }

        protected void gravarCookie(object sender, EventArgs e)
        {
            HttpCookie aCookie = new HttpCookie(TextBox1.Text);
            aCookie.Value = TextBox2.Text; 
            aCookie.Expires = DateTime.Now.AddDays(30);            
            Response.Cookies.Add(aCookie);
        }

        protected void lerCookie(object sender, EventArgs e)
        {
            String cookie = Request.Cookies[TextBox1.Text].Value;
            TextBox2.Text = cookie;
        }
    }
}