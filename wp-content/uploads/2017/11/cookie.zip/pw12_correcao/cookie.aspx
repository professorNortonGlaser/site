﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="cookie.aspx.cs" Inherits="pw12_correcao.cookie" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <br />
        nome:
        <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
        <br />
        <br />
        valor:
        <asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="gravarCookie" Text="Gravar" />
        <br />
        <br />
        <asp:Button ID="Button2" runat="server" OnClick="lerCookie" Text="Ler" />
        <br />
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
