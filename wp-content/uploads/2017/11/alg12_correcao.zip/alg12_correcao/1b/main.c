#include <stdio.h>
#include <stdlib.h>

/*
1- Crie um programa que controle uma lista de inscritos em um vestibular,
 armazene em uma matriz 10�3 os seguintes dados: 
 primeira coluna : cpf do inscrito , 
 segunda coluna: idade do inscrito, 
 terceira coluna: curso escolhido 1-ADS 2-GECOM 3-Eventos 4-RH

somente insira a linha da matriz caso o CPF n�o tenha sido cadastrado anteriormente
Exiba ao  final a quantidade de inscritos de cada curso
Mostre a media de idade dos inscritos
Caso ja exista um cpf, mostre a mensagem CPF ja cadastrado registro n�o inserido

 */

int main(int argc, char *argv[]) {
	int vestibular[10][3];
	int cursos[5];
	int x, y, existe;
	int cpf;
	float mediaIdade=0;
	
	for(x=0;x<5;x++){
		cursos[x] = 0;	
	}
	
	for(x=0;x<10;x++){
		printf("Informe o cpf candidato %d=",x);
		scanf("%d",&cpf);			
		existe = 0;
		//la�o responsavel por procurar o cpf na matriz
		for(y=0;y<x;y++){
			if(cpf == vestibular[y][0]){
				existe = 1;
				printf("O cpf=%d ja foi cadastrado! verifique\n", cpf);	
				x--;
				break; //interrompe o la�o quando achou repetido	
			}	
		}
		if(existe==0){		
			vestibular[x][0] = cpf;
			printf("Informe a idade do candidato %d=",x);
			scanf("%d",&vestibular[x][1]);
			mediaIdade = mediaIdade + vestibular[x][1];
			printf("Informe o curso 1-ADS 2-GECOM 3-Eventos 4-RH %d=",x);
			scanf("%d",&vestibular[x][2]);
			cursos[vestibular[x][2]]++;
		}		
	}
	mediaIdade = mediaIdade  / 10;
	printf("Media idade=%f, ADS=%d, GECOM=%d, Eventos=%d, RH=%d", mediaIdade, cursos[1], cursos[2],cursos[3], cursos[4]);
	

	
	return 0;
}
