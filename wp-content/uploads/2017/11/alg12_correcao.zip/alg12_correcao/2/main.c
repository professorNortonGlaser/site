#include <stdio.h>
#include <stdlib.h>

/* 
2-Crie um programa que armazene em uma matriz 10�3 
em cada uma das colunas armazene o tamanho de uma aresta de um triangulo, 
ao final exiba o percentual de tri�ngulos
isoceles, equil�teros e escalenos

 */

int main(int argc, char *argv[]) {
	int arestas[10][3];
	int i; 
	float pIso=0, pEqui=0, pEsc=0;
	 
	for(i=0; i<10; i++){
		printf("informe tam aresta A:");
		scanf("%d", &arestas[i][0]);
		printf("informe tam aresta B:");
		scanf("%d", &arestas[i][1]);	
		printf("informe tam aresta C:");
		scanf("%d", &arestas[i][2]);	
		
		if(arestas[i][0]==arestas[i][1] && arestas[i][2]==arestas[i][0]){
			pEqui++;	
		} else {
			if(arestas[i][0]==arestas[i][1] || arestas[i][1]==arestas[i][2] 
			|| arestas[i][0]==arestas[i][2]){
				pIso++;	
			} else {
				pEsc++;	
			}
		} 		
	}
	pEqui = (pEqui / 10)*100;
	pIso = (pIso / 10)*100;
	pEsc = (pEsc / 10)*100;
	
	printf("Equilatero=%.2f %, Isoceles=%.2f %, Escaleno=%.2f" %, pEqui, pIso, pEsc);
	
	
	
	return 0;
}
