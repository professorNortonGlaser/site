#include <stdio.h>
#include <stdlib.h>

/* 
1-Fa�a um algoritmo que calcule a media de 4 n�meros reais e 
mostre o resultado
*/

int main(int argc, char *argv[]) {
	float n1, n2, n3, n4, media; //FLOAT = Numeros Reais
	printf("Informe um valor para n1:");
	scanf("%f",&n1);
	printf("Informe um valor para n2:");
	scanf("%f",&n2);
	printf("Informe um valor para n3:");
	scanf("%f",&n3);
	printf("Informe um valor para n4:");
	scanf("%f",&n4);
	media = (n1+n2+n3+n4)/4; //processamento 
	printf("A media = %f ", media);
	return 0;
}
