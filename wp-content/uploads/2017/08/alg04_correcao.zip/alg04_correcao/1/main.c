#include <stdio.h>
#include <stdlib.h>

/* 
1- Fa�a um algoritmo que receba um n�mero inteiro, 
identifique se este e par ou impar, utilize o modulo 
de 2 para calcular o resto da divis�o, se o resto da 
divis�o for zero (o n�mero e par) caso o resto da divis�o 
for 1 (o n�mero e impar)
*/

int main(int argc, char *argv[]) {
	int numero, resto;
	//Entrada
	printf("Informe um numero inteiro:");
	scanf("%d", &numero);
	//modulo = resto de uma divisao inteira
	resto = numero % 2;
	if(resto==0)
	{
		printf("O numero %d e par!", numero);	
	}
	else
	{
		printf("O numero %d e impar!", numero);	
	}
	
	return 0;
}







