#include <stdio.h>
#include <stdlib.h>

/* 
2- fa�a um algoritmo em c que receba dois  n�meros, 
verifique qual o maior e qual o menor
 */

int main(int argc, char *argv[]) {
	float a, b;
	//entrada
	printf("Informe um valor para A:");
	scanf("%f",&a);
	printf("Informe um valor para B:");
	scanf("%f",&b);
	//processamento
	if(a>b)
	{
		printf("A e o maior %f \nB e o menor %f", a, b);	
	}
	else 
	{
		printf("B e o maior %f \nA e o menor %f", b, a);	
	}
	
	return 0;
}
