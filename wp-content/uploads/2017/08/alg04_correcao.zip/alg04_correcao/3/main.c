#include <stdio.h>
#include <stdlib.h>

/* 
3- Crie um  algoritmo que informe dois valores reais, 
valor em reais do litro da gasolina e 
valor em reais do litro do �lcool,  
calcule os 70% do valor da gasolina para definir na tela 
qual combust�vel e o mais vantajoso, 
sabendo que o valor do �lcool para ser mais vantajoso 
deve ser menor que 70% do valor da gasolina.
 */

int main(int argc, char *argv[]) {
	float a, g, percG;
	//entrada
	printf("Informe o valor do alcool:");
	scanf("%f",&a);
	printf("Informe o valor da gasolina:");
	scanf("%f",&g);
	//processamento
	percG = g * 0.7;
	if(percG<a){
		printf("Gasolina e mais vantajoso %f", g);	
	} 
	else {
		printf("alcool e mais vantajoso %f", a);			
	}
	
	return 0;
}
