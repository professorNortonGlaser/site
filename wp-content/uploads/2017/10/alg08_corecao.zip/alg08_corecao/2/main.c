#include <stdio.h>
#include <stdlib.h>

/*

B- Reutilizando o algoritmo do caixa eletr�nico, 
implemente um la�o fa�a enquanto 
que verifique se o usu�rio deseja continuar, 
caso a vari�vel coletada for igual 1 reinicie o la�o,
 mantendo o valor do saldo.
 */

int main(int argc, char *argv[]) {	
	float saldo = 500.00;
	float valor;
	int op;	
	
	do{				
		printf("\n1-ver saldo\n2-Saque\n3-Deposito\n4-sair\n");
		printf("Escolha a operacao acima:");
		scanf("%d",&op); 
		system("cls");	
		//Switch / escolha Variaveis do tipo inteiro ou caracter
		switch(op){
			case 1:{
				printf("O seu saldo = %.2f", saldo);
				break;
			}
			case 2:{
				printf("Informe o valor a ser sacado:");
				scanf("%f", &valor);
				if(valor > saldo){
					printf("Saldo insuficiente %.2f", saldo);	
				} 
				else{
					saldo = saldo - valor;
					printf("Saque efetuado, saldo atual= %.2f", saldo);		
				}
				break;
			}
			case 3:{
				printf("Informe o valor a ser depositado:");
				scanf("%f", &valor);
				saldo = saldo + valor;
				printf("Deposito efetuado, saldo atual= %.2f", saldo);
				break;
			}
			case 4:{
				printf("Obrigado por ser nosso cliente !");	
				break;
			}
			default:{
				printf("Operacao invalida!!!");			
			}											
		}
	} while(op!=4);
	return 0;
}
