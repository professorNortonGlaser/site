#include <stdio.h>
#include <stdlib.h>

/* 
C � Elabore um algoritmo que gere e escreva os
 n�meros �mpares dos n�meros entre 100 e 200.
*/

int main(int argc, char *argv[]) {
	int x;
	int resto;
	
	for(x=100;x<=200;x++) // x++ => x = x + 1
	{
		resto = x % 2; // modulo de 2 => resto da divisao inteira
		if(resto==1){
			printf("%d \n", x);	
		}	
	}
	
	return 0;
}
