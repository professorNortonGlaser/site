#include <stdio.h>
#include <stdlib.h>

/* 
A � Fa�a um algoritmo que implemente um la�o que leia X 
n�meros inteiros e identifique 
qual o menor o maior e a media, 
quando o n�mero informado for zero,
interrompa o la�o e exiba os valores.
*/

int main(int argc, char *argv[]) {
	int x;
	int menor, maior;
	float media = 0 ;
	int cont=0;	
	do{
		printf("Informe um numero:");
		scanf("%d", &x);
		if(x!=0){	
			if(cont==0){
				menor = x;
				maior = x;	
			} else {			
				if(x < menor){
					menor = x;	
				}	
				if(x > maior){
					maior = x;	
				}
			}
			media+=x; // media = media +x;
			cont++; // cont = cont + 1
		}
	} while(x!=0);
	media = media / cont;
	printf("Menor=%d, Maior=%d, media=%f", menor, maior, media);
	
	return 0;
}
