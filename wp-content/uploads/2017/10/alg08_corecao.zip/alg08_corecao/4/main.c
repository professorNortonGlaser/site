#include <stdio.h>
#include <stdlib.h>

/* 
D- Fa�a um algoritmo que dado valor inteiro informado,
 calcule e exiba a tabuada do numero de 1 a 10 */

int main(int argc, char *argv[]) {
	int numero, produto;
	int contador;
	
	printf("Informe a tabuada a ser calculada:");
	scanf("%d",&numero);
	
	for(contador=1; contador<=10; contador++){
		produto = numero * contador;	
		printf("%d x %d = %d \n", numero, contador, produto);
	}
	
	return 0;
}
