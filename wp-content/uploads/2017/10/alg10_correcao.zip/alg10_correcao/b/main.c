#include <stdio.h>
#include <stdlib.h>

/*
b-Crie dois vetores do tipo inteiro com a capacidade 
de 10 posi��es, 
leia n�meros que ser�o armazenados sequencialmente 
no primeiro vetor, 
fa�a um novo la�o que armazene no segundo vetor 
o valor do primeiro multiplicado por 2 quando 
o �ndice for par, 
e multiplique por 3 quando o �ndice for impar.
 */

int main(int argc, char *argv[]) {
	int vetA[10], vetB[10]; //0..9
	int x, resto;
	for(x=0; x<10; x++){
		printf("Digite um numero:");
		scanf("%d", &vetA[x]);	
	}
	for(x=0;x<10; x++){
		resto = x%2;
		if(resto==0){
			vetB[x]=vetA[x]*2;	
		} else {
			vetB[x]=vetA[x]*3;		
		}	
		printf("%d-vetA=%d,vetB=%d\n", x,vetA[x],vetB[x]);
	}
	
	return 0;
}
