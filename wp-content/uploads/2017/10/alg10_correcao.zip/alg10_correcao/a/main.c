#include <stdio.h>
#include <stdlib.h>

/*
a- Fa�a um algoritmo que armazene um vetor de inteiros de
   20 posi��es, identifique  o percentual de n�meros impares
   e de n�meros pares informados.
 */

int main(int argc, char *argv[]) {
	int numeros[20]; // 0...19
	int i, resto;
	float totalPares =0;
	float totalImpares =0;
	float percPares, percImpares;
	for(i=0;i<20;i++){
		printf("Informe um numero:");
		scanf("%d", &numeros[i]);
		resto = numeros[i] % 2; // resto da divisao inteira
		if(resto == 0){
			totalPares++;				
		} else {
			totalImpares++;
		}			
	}
	percPares = (totalPares / 20) * 100;
	percImpares = (totalImpares / 20) * 100;
	printf("Pares %.2f %, Impares %.2f %", percPares, percImpares);
	return 0;
}
