#include <stdio.h>
#include <stdlib.h>

/* 
c � fa�a um algoritmo que implemente um vetor 
de 20 posi��es, leia as 20 posi��es e identifique
em um novo la�o, qual o maior e menor numero 
informado e qual a media dos n�meros informados.
 */

int main(int argc, char *argv[]) {
	float vetor[20]; // 0..19
	int i;
	float menor, maior, media=0;
	for(i=0; i<20; i++){
		printf("Informe um valor:");
		scanf("%f", &vetor[i]);	
	}
	for(i=0; i<20; i++){
		if(i==0){ // se for a primeira repeti��o
			menor = vetor[i];
			maior = vetor[i];	
		} else {
			if(vetor[i]<menor){
				menor = vetor[i];
			}	
			if(vetor[i]>maior){
				maior = vetor[i];
			}
		}	
		media += vetor[i]; // media = media + vetor[i];
	}
	media = media / 20;
	printf("Menor=%f, Maior=%f, Media=%f",menor, maior, media);
	return 0;
}
