#include <stdio.h>
#include <stdlib.h>

/* 
4- fa�a um la�o �fa�a at� com 10 intera��es, 
verifique quantas vezes n�meros m�ltiplos de 2 e de 3 
s�o informados
 */

int main(int argc, char *argv[]) {
	int c, numero;
	int qtd = 0;
	for(c=0;c<10;c++){
		printf("Informe um numero:");
		scanf("%d",&numero);
		if((numero%2)==0 && (numero%3)==0){
			printf("Numero %d e multiplo de 2 e 3 \n", numero);		
		}		
	}	
	
	
	return 0;
}
