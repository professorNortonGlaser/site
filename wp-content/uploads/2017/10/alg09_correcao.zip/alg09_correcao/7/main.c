#include <stdio.h>
#include <stdlib.h>

/* 
7- Fa�a um algoritmo que conte de 1 a 100 
e a cada m�ltiplo de 3 e 5 simultaneamente emita uma mensagem: 
 �M�ltiplo de 3 e 5�.
*/

int main(int argc, char *argv[]) {
	int x;
	for(x=1;x<=100;x++){
		if((x%3)==0 && (x%5)==0){
			printf("%d e multiplo de 3 e 5 \n", x);	
		}					
	}	
	return 0;
}
