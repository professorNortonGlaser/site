#include <stdio.h>
#include <stdlib.h>

/*
3- Fa�a um la�o que calcule a media de todos os n�meros informados, 
a condi��o de termino do la�o e quando for digitado ZERO
 */

int main(int argc, char *argv[]) {
	float numero;
	float qtd = 0;
	float media = 0;
	
	do{
		printf("Informe um numero !");
		scanf("%f", &numero);
		if(numero != 0){
			qtd++; // qtd = qtd + 1;
			media+=numero; // media = media + numero;	 
		}					
	} while(numero != 0);
	media = media / qtd;
	printf("A media dos numeros informados= %f", media);
	
	return 0;
}
