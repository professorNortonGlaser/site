#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float total=0;
	float graos=1;
	int x;
	
	for(x=1;x<=64;x++){
		total+=graos; // total = total + graos;
		graos*=2;	// graos = graos * 2;	
	} 
	total = total;
	printf("Total de graos do pagamento %f", total);
	
	
	return 0;
}
