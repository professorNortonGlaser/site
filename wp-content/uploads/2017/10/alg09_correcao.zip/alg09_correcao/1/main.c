#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int i, a, b, r;
	for(i=0; i<20; i++)
	{
   		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("%d\n", r);
	}
	//Enquanto fa�a 
	i=0;
	while(i<20){
		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("%d\n", r);		
		i++; // i = i + 1
	}
	//Fa�a enquanto
	i=0;
	do{
		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("%d\n", r);		
		i++; // i = i + 1		
	} while(i<20);
	
	
	
	
	return 0;
}
