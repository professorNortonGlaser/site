#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int x = 10;
	while(x>0)
	{
	  printf("%d \n",x);
	  x--;
	}
	// Fa�a at� FOR
	for(x=10;x>0;x--){
		printf("%d \n",x);
	}
	// Fa�a Enquanto
	x = 10;
	do{
	  printf("%d \n",x);
	  x--;
	}while(x>0);
	
	return 0;
}
