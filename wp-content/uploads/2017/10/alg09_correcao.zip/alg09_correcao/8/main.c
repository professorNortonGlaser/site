#include <stdio.h>
#include <stdlib.h>

/*
8- Crie um algoritmo onde ser� informado um valor inteiro inicial, 
e um la�o o usu�rio devera informar outro numero inteiro,
o programa dever� responder se o numero atual e menor ou maior 
que o numero inicial informado,
o la�o somente ser� interrompido quando 
o numero atual for igual ao n�mero anterior informado.
Exiba quantas tentativas foram necess�rias 
para que o numero fosse descoberto.
*/

int main(int argc, char *argv[]) {
	int cont=0;
	int numero, chute;
	
	printf("Informe um numero:");
	scanf("%d", &numero);
	system("cls");
	
	do{
		cont++;
		printf("Chute um numero:");
		scanf("%d", &chute);
		if(chute == numero)
		{
		 	printf("Parabens vc acertou %d \n", cont);		
		} else {
			if(chute > numero){
				printf("E menor \n");	
			} else {
				printf("E maior \n");	
			}		
		}						
	} while(chute!=numero);
	
	
	return 0;
}
