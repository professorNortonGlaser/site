#include <stdio.h>
#include <stdlib.h>

/* 

5- Crie um la�o e verifique qual a maior sequencia de n�meros 
pares informados, o la�o fara 10 itera��es.

Exe:  1, 2,3,4,6,8,5,3,2,5,8,4,0   
Sequencia :4,6,8   O programa vai retornar: 3

 */

int main(int argc, char *argv[]) {
	int i, numero, resto;
	int maior = 0;
	int sequencia = 0;
	
	for(i=0; i<10; i++){
		printf("Informe um numero:");
		scanf("%d", &numero);
		resto = numero % 2;
		if(resto==0){
			sequencia++;	
		} else {
			sequencia = 0;
		}	
		if(sequencia > maior){
			maior = sequencia;	
		}		
	}
	printf("A maior sequencia de pares foi %d", maior);
	return 0;
}
