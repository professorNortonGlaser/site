#include <stdio.h>
#include <stdlib.h>

/* 
3 � Crie uma tabela de um campeonato de futebol, com 10 times e 4 colunas

Na coluna 0 e o total de vitorias (multiplique por 3 pontos)
Na coluna 1 o total de empates (multiplique por 1 ponto)
Na coluna 2 o total de derrotas (multiplique por 0 pontos)
Na coluna 3 , calcule o total de pontos
Mostre ao final, o tr�s primeiros colocados da tabela

 */

int main(int argc, char *argv[]) {
	int tabela[10][4];
	int i, maior, ultimo=0, q, cont, time;
	int v=0, e=1, d=2, p=3;
		
	for(i=0; i<10; i++){
		printf("Total Vitorias time %d \n", i);
		scanf("%d", &tabela[i][v]);	
		printf("Total Empates time %d \n", i);
		scanf("%d", &tabela[i][e]);
		printf("Total Derrotas time %d \n", i);
		scanf("%d", &tabela[i][d]);
		tabela[i][p]=(tabela[i][v]*3) + tabela[i][e];
	}
	
	for(q=1; q<=3; q++){
		cont = 0;
		for(i=0; i<10; i++){
			if(q==1 || tabela[i][p]<ultimo){			
				if(cont==0){
					maior = tabela[i][p];	
					time  = i;
				} else {
					if(tabela[i][p] > maior){
						maior = tabela[i][p]; 
						time  = i;
					}					
				}	
				cont++;				
			}
		}
		ultimo = maior;			
		printf("Time %d = %d \n",time, maior);
	}
	
	for(i=0; i<10; i++){
		printf("Time %d = %d \n", i, tabela[i][p]);	
	}
	
	return 0;
}
