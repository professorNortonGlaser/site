#include <stdio.h>
#include <stdlib.h>

/*
1 � Construa um programa em C que utiliza uma matriz 10�3 
que armazene as  temperaturas m�xima e minima do dia, 
assim como a media de temperatura na ultima coluna.  
Crie um menu de escolha que ofere�a as seguintes informa��es:

1-temperatura minima de todos os dias.
2-temperatura m�xima de todos os dias.
3-maior varia��o de temperatura de todos os dias.
4-sair do programa.
 */

int main(int argc, char *argv[]) {
	float temp[10][3]; //[0..9][0..2]
	int i, op;
	float menor, maior, amplitude;
	for(i=0;i<10;i++){
		printf("Informe a temp. Min. do dia %d=", i);
		scanf("%f", &temp[i][0]);
		printf("Informe a temp. Max. do dia %d=", i);
		scanf("%f", &temp[i][1]);	
		temp[i][2] = (temp[i][0]+temp[i][1])/2;
	}
	system("cls");
	do{ //la�o fa�a enquanto 1 a N
		printf("1-temperatura minima entre todos os dias.\n");
		printf("2-temperatura maxima entre todos os dias.\n");
		printf("3-maior variacao de temperatura entre todos os dias.\n");
		printf("4-sair do programa.\n");
		scanf("%d", &op);
		switch(op){
			case 1:{
				menor = temp[0][0]; //coluna 0 menor temp. do dia
				for(i=0;i<10;i++){
					if(temp[i][0] < menor){
						menor=temp[i][0]; 	
					}		
				}
				printf("A menor temp. Min. %f \n", menor);
				break;
			}	
			case 2:{
				maior = temp[0][1]; //coluna 1 maior temp. do dia
				for(i=0;i<10;i++){
					if(temp[i][1] > maior){
						maior=temp[i][1]; 	
					}		
				}
				printf("A maior temp. Max. %f \n", maior);
				break;
			}
			case 3:{
				amplitude = temp[0][1] - temp[0][0]; 
				for(i=0;i<10;i++){
					if((temp[i][1]-temp[i][0])> amplitude){
						amplitude=temp[i][1]-temp[i][0]; 	
					}		
				}
				printf("A maior amplitude %f \n", amplitude);
				break;
			}
			default: {
				break;
			}
		}		
	} while(op!=4); 
	
	
	return 0;
}
