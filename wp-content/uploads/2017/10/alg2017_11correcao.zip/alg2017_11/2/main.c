#include <stdio.h>
#include <stdlib.h>

/* 
2 � Armazene em uma matriz 10�5 o resultado de uma prova de alternativas:

a � coluna 0
b � coluna 1
c � coluna 2
d � coluna 3
e � coluna 4
Exemplo da resposta da primeira quest�o com a alternativa C:

prova[0][0]=0 ; prova[0][1]=0; prova[0][2]=1;prova[0][3]=0;prova[0][4]=0;

Com um gabarito j� definido e armazenado em uma matriz, 
verifique a nota obtida pelo aluno
*/

int main(int argc, char *argv[]) {
	int gab[10][5];
	int pro[10][5];
	int x,y, nota=0, alternativa;
	int a=0, b=1, c=2, d=3, e=4;
	
	//Zerando as matrizes gabarito e a prova;
	for(x=0;x<10;x++){ //x = Linhas
		for(y=0;y<5;y++){
			gab[x][y]=0;
			pro[x][y]=0;	
		}	
	}
	//definindo gabarito
	gab[0][b] = 1;
	gab[1][a] = 1;
	gab[2][d] = 1;
	gab[3][e] = 1;
	gab[4][a] = 1;
	gab[5][b] = 1;
	gab[6][c] = 1;
	gab[7][e] = 1;
	gab[8][e] = 1;
	gab[9][a] = 1;
	
	for(x=0;x<10;x++){
		printf("Informe a alternativa correta para a questao %d \n",x);
		printf("Onde: A=0, B=1, C=2, D=3, E=4 :");
		scanf("%d", &alternativa);		
		pro[x][alternativa] = 1 ;		
		
		if(gab[x][alternativa]==pro[x][alternativa]){
			nota++;		
		}
	}
	printf("A sua nota foi %d", nota);
	
	
	return 0;
}
