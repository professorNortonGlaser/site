#include <stdio.h>
#include <stdlib.h>

/* Informe dois n�meros reais e um n�mero inteiro que represente a
 opera��o matem�tica a ser realizada (1-soma, 2-subtra��o, 
 3- multiplica��o, 4-divis�o, 5-resto) utilize o comando sele��o
  aninhado e exiba o resultado da opera��o matem�tica escolhida.
   */

int main(int argc, char *argv[]) {
	int op;
	float n1, n2, resultado;
	
	printf("1-Soma\n2-subtracao\n3-multiplicacao\n4-divisao\n5-resto");
	printf("\nEscolha uma op��o:");
	scanf("%d", &op);
	printf("Informe um valor para N1:");
	scanf("%f",&n1);
	printf("Informe um valor para N2:");
	scanf("%f",&n2);
	switch(op){
		case 1:{
			resultado = n1 + n2;
			break;
		}
		case 2:{
			resultado = n1 - n2;
			break;
		}
		case 3:{
			resultado = n1 * n2;
			break;
		}
		case 4:{
			resultado = n1 / n2;
			break;
		}
		case 5:{
			//modulo e o resto da divisao inteira
			resultado = (int)n1 % (int)n2;
			break;
		}
		default:{
			resultado = 0;
		}	
	}
	printf("O resultado e: %f", resultado);
		
	return 0;
}
