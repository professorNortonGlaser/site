#include <stdio.h>
#include <stdlib.h>

/* Assunto: ALG2015-05
Informe as duas notas de um aluno (P1 e P2) 
e a quantidade de faltas no semestre, 
calcule a media das notas e o percentual de faltas 
sobre 20 aulas.  
Caso o percentual de faltas for maior que 30% o 
aluno esta automaticamente reprovado, 
caso ao contrario verifique se a media e maior igual
 a 6,  se afirmativo o aluno esta aprovado, 
 sen�o informe uma nota P3 para recalcular a media, 
 se a nova media for maior igual a 6, 
 escreva aprovado no exame, 
 caso negativo exiba reprovado por nota.
*/

int main(int argc, char *argv[]) {
	float p1, p2, p3, media;
	float totalFaltas, percentualFaltas;
	printf("Informa a nota P1:");
	scanf("%f",&p1);
	printf("Informa a nota P2:");
	scanf("%f",&p2);
	printf("Informe o total de faltas:");
	scanf("%f",&totalFaltas);
	media = (p1+p2)/2;
	percentualFaltas = totalFaltas / 20;
	if(percentualFaltas > 0.3)
	{
		printf("aluno reprovado por faltas !");	
	} 
	else 
	{
		if(media >= 6)
		{
			printf("aluno aprovado !");	
		} 
		else 
		{
			printf("Informa a nota P3:");
			scanf("%f",&p3);	
			media = (p1+p2+p3)/3;
			if(media >=6 )
			{
				printf("Aprovado no exame");
			} 
			else
			{
				printf("Reprovado no exame");
			}
		}
	}
	
	return 0;
}
