#include <stdio.h>
#include <stdlib.h>

/* Informe tr�s n�meros inteiros, utilizando comandos de sele��o encadeados, 
defina qual o menor, do meio e o maior n�mero. */

int main(int argc, char *argv[]) {
	int a,b,c;
	
	printf("informe a: ");
	scanf("%d", &a);
	printf("informe b: ");
	scanf("%d", &b);
	printf("informe c: ");
	scanf("%d", &c);
	
	if(a>b && a>c){
		printf("A e maior %d\n", a);
		if(b>c){
			printf("B=%d e o do meio e C=%d e o menor \n", b, c);
		} else {
			printf("C=%d e o do meio e B=%d e o menor \n", c, b);
		}
	} else {
		if(b>c && b>a){
			printf("B e maior %d\n", b);
			if(a>c){
				printf("A=%d e o do meio e C=%d e o menor \n", a, c);
			} else {
				printf("C=%d e o do meio e A=%d e o menor \n", c, a);
			}	
		} else {
			printf("C e maior %d\n", c);
			if(a>b){
				printf("A=%d e o do meio e B=%d e o menor \n", a, b);
			} else {
				printf("B=%d e o do meio e A=%d e o menor \n", b, a);
			}
		}
		
	}
	
	
	return 0;
}
