#include <stdio.h>
#include <stdlib.h>

/* Fa�a um algoritmo que receba um n�mero inteiro, 
identifique se este e par ou impar, 
utilize o modulo de 2 
para calcular o resto da divis�o, 
se o resto da divis�o for zero (o n�mero e par) 
caso o resto da divis�o for 1 (o n�mero e impar)
 */

int main(int argc, char *argv[]) {
	int numero, resto;
	printf("Informe um numero: ");
	scanf("%d", &numero);
	//modulo = resto da divisao inteira
	resto = numero % 2; 
	if(resto==0)
	{
		printf("%d e par ! \n", numero);				
	} 
	else {
		printf("%d e impar ! \n", numero);				
    }
	
	return 0;
}
