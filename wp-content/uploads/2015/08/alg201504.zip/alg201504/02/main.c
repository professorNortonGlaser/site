#include <stdio.h>
#include <stdlib.h>

/* fa�a um algoritmo em c que receba dois 
 n�meros, 
 verifique qual o maior e qual o menor 
*/

int main(int argc, char *argv[]) {
	float a, b;
	
	printf("Informe o primeiro numero:");
	scanf("%f", &a);
	printf("Informe o segundo numero:");
	scanf("%f", &b);
	if(a > b)
	{
		printf("primeiro maior que segundo!\n");	
	}
	else {
		printf("segundo maior que primeiro!\n");
	}	
	
	
	
	
	return 0;
}
