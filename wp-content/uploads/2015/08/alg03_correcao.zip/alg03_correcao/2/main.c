#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que leia a temperatura em graus 
Celsius e converta
para fahrenheit F = (9 * C + 160) / 5
 */

int main(int argc, char *argv[]) {
	float c, f;
	printf("Informe temperatura em Celsius: ");
	scanf("%f", &c);
	f = (9 * c + 160) / 5;
	//exibindo resultado
	printf("%.2f celsius em fareheith = %.2f \n", c, f);
	//podemos ter quantos escapes forem nescessarios
	//criando a lista de valores separado por virgulas 
	return 0;
}
