#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que calcule a media 
de 4 n�meros reais e mostre o 
resultado
*/

int main(int argc, char *argv[]) {	
	float n1, n2, n3, n4, resultado;
	
	printf("Informe um valor para n1: ");
	//scanf coleta dados do teclado
	scanf("%f",&n1);
	
	printf("Informe um valor para n2: ");	
	scanf("%f",&n2);
	
	printf("Informe um valor para n3: ");	
	scanf("%f",&n3);
	
	printf("Informe um valor para n4: ");	
	scanf("%f",&n4);
	
	//processamento
	resultado = (n1+n2+n3+n4)/4; 
	
	//saida
	printf("Media = %.2f \n", resultado);
	// \n e utilizado para pular uma linha
	// %.2f escape para imprimir um numero decimal com duas casas
	
	return 0;
}
