﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="email.aspx.cs" Inherits="pw2015_11.email" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <asp:ScriptManager ID="ScriptManager1" runat="server">
        </asp:ScriptManager>
        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
<br />
                Envio de Email<br />
                <br />
                email:<asp:TextBox ID="txtPara" runat="server"></asp:TextBox>
                <br />
                <br />
                titulo:<asp:TextBox ID="txtTitulo" runat="server"></asp:TextBox>
                <br />
                <br />
                mensagem:
                <asp:TextBox ID="txtMensagem" runat="server"></asp:TextBox>
                <br />
                <br />
                <asp:Button ID="Button1" runat="server" OnClick="enviarEmail" Text="Button" />
                <br />
                <br />
                <asp:Label ID="lblMensagem" runat="server"></asp:Label>
                <br />
<br />
            </ContentTemplate>
        </asp:UpdatePanel>
        <br />
        <asp:UpdateProgress ID="UpdateProgress1" runat="server">
            <ProgressTemplate>
                Enviando Email....
            </ProgressTemplate>
        </asp:UpdateProgress>
        <br />
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
