﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw2015_11
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void testar(object sender, EventArgs e)
        {
            long j = 0;
            for (long i = 0; i < 9999999900; i++)
            {
                j = i;
            }
            Label1.Text = j.ToString();
            Label2.Text = j.ToString();

        }
    }
}