﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Net;

namespace pw2015_11
{
    public partial class email : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void enviarEmail(object sender, EventArgs e)
        {
            MailAddress para = new MailAddress(txtPara.Text);
            MailAddress de = new MailAddress("fatec20152pw@outlook.com");

            MailMessage mensagem = new MailMessage();
            mensagem.To.Add(para);
            mensagem.From = de;
            mensagem.Subject = txtTitulo.Text;
            mensagem.Body = txtMensagem.Text;

            SmtpClient conta = new SmtpClient("smtp.outlook.com");
            try
            {
                conta.EnableSsl = true;
                conta.Port = 587;
                conta.Credentials = new NetworkCredential("fatec20152pw@outlook.com", 
                            "123455");
                conta.Send(mensagem);
                lblMensagem.Text = "Mensagem enviada com sucesso!";
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Ocorreu um erro " + err.Message;
            }


        }
    }
}