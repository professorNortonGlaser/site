#include <stdio.h>
#include <stdlib.h>

/* 2) Elabore um programa em C que leia as vari�veis C e N, 
respectivamente c�digo e n�mero de horas trabalhadas de um oper�rio. 
E calcule o sal�rio sabendo-se que ele ganha R$ 10,00 por hora. 
Quando o n�mero de horas exceder a 50 calcule o excesso de pagamento 
armazenando-o na vari�vel E, caso contr�rio zerar tal vari�vel. 
A hora excedente de trabalho vale R$ 20,00. 
No final do processamento imprimir o sal�rio total e o
 sal�rio excedente. */

int main(int argc, char *argv[]) {
	int C;
	float ST, SE, N, E;
	
	printf("Inform o seu codigo:");
	scanf("%d", &C);
	
	printf("Informe o numero de horas:");
	scanf("%f", &N);
	
	if(N > 50) 
	{
		E = N - 50;
		SE = (E*20);	
		ST = SE + (50*10) ;
	} else {
		E = 0;
		SE = 0;
		ST = N*10;		
	}
	printf("Horas Trabalhadas=%f \nSalario Excedentes=%f\n", N, SE);
	printf("Salario Total=%f \n", ST);
	
	
	
	return 0;
}
