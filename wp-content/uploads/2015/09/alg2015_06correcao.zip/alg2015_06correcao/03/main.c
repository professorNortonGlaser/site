#include <stdio.h>
#include <stdlib.h>

/* Desenvolva um programa em C que:

Leia 4 (quatro) n�meros;
Calcule o quadrado de cada um;
Se o valor resultante do 
quadrado do terceiro for >= 1000, imprima-o e finalize;
Caso contr�rio, 
imprima os valores lidos e seus respectivos quadrados. */

int main(int argc, char *argv[]) {
	float A, B, C, D, quadrado;
	
	printf("Informe um valor para A:");
	scanf("%f", &A);
	
	printf("Informe um valor para B:");
	scanf("%f", &B);
	
	printf("Informe um valor para C:");
	scanf("%f", &C);
	
	printf("Informe um valor para D:");
	scanf("%f", &D);
	
	quadrado = C * C;
	if(quadrado >= 1000)
	{
		printf("Quadrado de %f = %f \n", C, quadrado);
	} 
	else {
		quadrado = A * A;
		printf("Quadrado de %f = %f \n", A, quadrado);
		quadrado = B * B;
		printf("Quadrado de %f = %f \n", B, quadrado);
		quadrado = C * C;
		printf("Quadrado de %f = %f \n", C, quadrado);
		quadrado = D * D;
		printf("Quadrado de %f = %f \n", D, quadrado);				
	}
	
	
	return 0;
}
