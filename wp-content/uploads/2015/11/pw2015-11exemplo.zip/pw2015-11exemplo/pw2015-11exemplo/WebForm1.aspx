﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw2015_11exemplo.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <asp:DropDownList ID="cboLivro" runat="server">
        </asp:DropDownList>
        <br />
        <br />
        <asp:CheckBoxList ID="CheckBoxList1" runat="server">
        </asp:CheckBoxList>
        <br />
        <asp:BulletedList ID="BulletedList1" runat="server">
        </asp:BulletedList>
        <asp:GridView ID="GridView1" runat="server">
        </asp:GridView>
        <br />

        <asp:ListView ID="ListView1" runat="server"  >
            <itemTemplate>
                <h2><%#Eval("titulo")%></h2>
                <img src="<%#Eval("codigo") %>.jpg" width="50px" /><br />
                <i><%#Eval("autor") %></i><br />
                <font color="red"><%#Eval("valor") %> </font>
            </itemTemplate>    
        </asp:ListView>


        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="Carregar" Text="Button" />
    
    </div>
    </form>
</body>
</html>
