﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;

namespace pw2015_11exemplo
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string sc = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\basedados\\basedados.accdb;Persist Security Info=False;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Carregar(object sender, EventArgs e)
        {
            OleDbConnection conexao = new OleDbConnection(sc);
            conexao.Open();
            string sql = "select * from livro order by titulo";
            DataSet ds = new DataSet();
            OleDbDataAdapter conversor = new OleDbDataAdapter(sql, conexao);
            conversor.Fill(ds);
            conexao.Close();
            //carimbando
            cboLivro.DataSource = ds;
            cboLivro.DataValueField = "codigo";
            cboLivro.DataTextField = "titulo";
            cboLivro.DataBind();

            CheckBoxList1.DataSource = ds;
            CheckBoxList1.DataTextField = "autor";
            CheckBoxList1.DataValueField = "codigo";
            CheckBoxList1.DataBind();

            BulletedList1.DataSource = ds;
            BulletedList1.DataTextField = "valor";
            BulletedList1.DataBind();

            GridView1.DataSource = ds;
            GridView1.DataBind();

            ListView1.DataSource = ds;
            ListView1.DataBind();
        }
    }
}