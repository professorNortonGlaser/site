﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace pw201511_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string sc = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\basedados\\basedados.accdb;Persist Security Info=False;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void carregar(object sender, EventArgs e)
        {

            OleDbConnection conexao = new OleDbConnection(sc);
            conexao.Open();
            DataSet ds = new DataSet();
            OleDbDataAdapter adap1 = new OleDbDataAdapter(
                "select * from cliente order by nome", conexao);
            adap1.Fill(ds, "cliente");
            OleDbDataAdapter adap2 = new OleDbDataAdapter(
                "select * from livro where valor<=50", conexao);
            adap2.Fill(ds, "produto");
            conexao.Close();
            GridView1.DataSource = ds.Tables["cliente"];
            GridView1.DataBind();
            DropDownList1.DataSource = ds.Tables["produto"];
            DropDownList1.DataTextField = "titulo";
            DropDownList1.DataValueField = "codigo";
            DropDownList1.DataBind();
        }
    }
}