<?php

	$codigo	= 	$_POST["codigo"]; 
	$nome	=	$_POST["nome"];
	$valor	=	$_POST["valor"];
	$qtd	=	$_POST["qtd"];
	
	$conn	= 
	new mysqli("localhost","root","","fw");	

	if(isset($_POST["btnInserir"]))
	{
		$sql = "insert into produto(nome,
				valor,qtd)
		values('". $nome ."',". $valor. ",".
				$qtd . ")";
		mysqli_query($conn,$sql);		
		echo "Registro Inserido!";
	}
	
	if(isset($_POST["btnAlterar"]))
	{
		$sql = "update produto set  
				nome='". $nome ."',
				qtd=". $qtd .",
				valor=". $valor . 
				" where codigo=". $codigo;
		mysqli_query($conn,$sql);		
		echo "Registro Alterado!";		
	}
	
	if(isset($_POST["btnExcluir"]))
	{
		$sql = "delete from produto where
					codigo=". $codigo;
		mysqli_query($conn,$sql);		
		echo "Registro Removido!";					
	}
	
	if(isset($_POST["btnPesquisar"])){
		$sql = "select * from produto where
				codigo=". $codigo;
		$consulta = mysqli_query($conn,$sql);
		if($registro = 
			mysqli_fetch_array($consulta)) {		
		echo "Cod=". $registro["codigo"] ."<br>";
		echo "Nome=". $registro["nome"] ."<br>";
		echo "Qtd=". $registro["qtd"] ."<br>";		
		echo "Valor=". $registro["valor"] ."<br>";		
		} else {
			echo "registro nao encontrado";
		}
	}
	
	
	$conn->close();



?>