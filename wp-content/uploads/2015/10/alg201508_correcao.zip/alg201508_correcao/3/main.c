#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int cont = 1;
	int resto3;
	int resto5;
	
	do
	{
		resto3 = cont % 3; //modulo de 3
		resto5 = cont % 5; //modulo de 3
		if(resto3==0 && resto5==0){
			printf("%d multiplo de 3 e 5 \n", cont);	
		}	
		cont++;		
	}while(cont<=100);
	
	
	
	return 0;
}
