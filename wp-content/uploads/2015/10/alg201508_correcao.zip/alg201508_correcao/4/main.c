#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int num, x, produto,continua;

do{
	printf("informe um numero:");
	scanf("%d",&num);
	for(x=1; x<=10;x++){
		produto = x * num;
		printf("%d X %d = %d\n",x, num, produto);		
	}
	printf("deseja continuar 1-Sim, 0-n�o");	
	scanf("%d",&continua);
}while(continua==1);
	
	return 0;
}
