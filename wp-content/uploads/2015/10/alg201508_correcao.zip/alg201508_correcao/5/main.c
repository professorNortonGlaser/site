#include <stdio.h>
#include <stdlib.h>

/* 
 Crie um algoritmo onde ser� informado um valor inteiro 
 inicial, 
 e um la�o o usu�rio devera informar outro numero inteiro,
 o programa dever� responder se o numero atual e menor ou maior
 que o numero inicial informado, 
 o la�o somente ser� interrompido quando o numero 
 atual for igual ao n�mero anterior informado.
 Exiba quantas tentativas foram necess�rias
 para que o numero fosse descoberto. */

int main(int argc, char *argv[]) {
	int num	;
	int numAtual;
	int tot = 0;
	
	printf("Informe o num a ser descoberto:");
	scanf("%d",&num);	
	do{
		printf("Informe o num a ser descoberto:");
		scanf("%d",&numAtual);			
		if(numAtual>num){
			printf("%d e maior \n", numAtual);
		} 
		if(numAtual<num){
			printf("%d e menor \n", numAtual);				
		}		
		tot++;
	}while(numAtual!=num);
	printf("Voce precisou de %d tentativas",tot);
	
	return 0;
}
