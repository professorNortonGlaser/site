#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int casas=1;
	double graos=1;
	
	while(casas<=64){		
		casas++; // e igual a casas=casas+1;
		graos = graos *2;
	}
	printf("Total de Graos %f", graos);
			
	return 0;
}
