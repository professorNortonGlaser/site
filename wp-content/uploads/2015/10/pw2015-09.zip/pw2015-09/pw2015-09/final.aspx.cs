﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw2015_09
{
    public partial class final : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMensagem.Text =
            (string)Session["nome"] + "<BR><BR>" + (string)Session["telefone"] +
                (string)Session["cidade"];

            Application["mensagem"] = "bem vindos";
        }
    }
}