﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="destino.aspx.cs" Inherits="pw2015_09.destino" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        Nome:<asp:TextBox ID="txtNome" runat="server"></asp:TextBox>
        <br />
        <br />
        Telefone:<asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox>
        <br />
        <br />
        Cidade:
        <asp:TextBox ID="txtCidade" runat="server"></asp:TextBox>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="redirecionar" Text="Button" />
    
    </div>
    </form>
</body>
</html>
