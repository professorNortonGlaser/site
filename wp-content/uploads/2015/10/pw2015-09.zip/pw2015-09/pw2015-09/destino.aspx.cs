﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw2015_09
{
    public partial class destino : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false) { 
                txtNome.Text = Request["nome"];
                txtCidade.Text = Request["cidade"];
                txtTelefone.Text = Request["telefone"];

                Session["nome"] = txtNome.Text;
                Session["cidade"] = txtCidade.Text;
                Session["telefone"] = txtTelefone.Text;
            }
        }

        protected void redirecionar(object sender, EventArgs e)
        {
            Response.Redirect("final.aspx");
        }
    }
}