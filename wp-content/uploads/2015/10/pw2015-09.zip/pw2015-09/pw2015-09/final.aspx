﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="final.aspx.cs" Inherits="pw2015_09.final" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:Label ID="lblMensagem" runat="server" Text="Label"></asp:Label>
    </div>
    </form>
</body>
</html>
