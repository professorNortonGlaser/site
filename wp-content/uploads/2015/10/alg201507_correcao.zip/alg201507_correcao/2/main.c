#include <stdio.h>
#include <stdlib.h>

/* 
Reutilizando o algoritmo do caixa eletr�nico, implemente um
 la�o fa�a enquanto que verifique se o usu�rio deseja continuar,
  caso a vari�vel coletada for igual 1 reinicie o la�o, mantendo
   o valor do saldo
 */

int main(int argc, char *argv[]) {
	int continua;
	int op;
	float saldo, valor;
	
	saldo = 0;
	
	do{		
		printf("1-Saldo\n2-Saque\n3-Deposito\nEscolha a op:");
		scanf("%d", &op);
		switch(op){
			case 1:{
				printf("Saldo = %f\n", saldo);	
				break;
			}	
			case 2:{
				printf("Informe o valor de saque:");
				scanf("%f",&valor);
				if(valor <= saldo){
					saldo = saldo - valor;
					printf("Saque realizado! Saldo Atual = %f \n ", saldo);
				} 
				else {
					printf("Saque nao permitido! Saldo Atual = %f \n ", saldo);
				}
				break;
			}
			case 3:{
				printf("Informe o valor do deposito:");
				scanf("%f",&valor);
				saldo = saldo + valor;
				printf("Saldo Atual= %.2f\n", saldo);	
				break;
			}
			default:{
				printf("opcao errada !\n");	
			}		
		}
	
	
	
		
		printf("Deseja continua 1-sim 0-nao");
		scanf("%d",&continua);	
	} while(continua==1);
	
	
	return 0;
}
