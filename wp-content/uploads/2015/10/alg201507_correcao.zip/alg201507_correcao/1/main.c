#include <stdio.h>
#include <stdlib.h>

/* Fa�a um algoritmo que implemente um la�o que
  leia X n�meros inteiros e identifique qual o menor
   o maior e a media, quando o n�mero informado for zero,
   interrompa o la�o e exiba os valores. */

int main(int argc, char *argv[]) {
	int x, cont, soma, menor, maior;
	
	cont = 0;
	soma = 0;
	do{
		printf("Digite um numero inteiro:");
		scanf("%d",&x);
		if(x!=0){		
			if(cont==0){
				maior = x;
				menor = x;	
			} else {
				if(x>maior){
					maior = x;
				}
				if(x<menor){
					menor = x;
				}
			}		
			soma = soma + x;	
			cont = cont + 1;
		}
	} while(x != 0);
	float media = (float)soma / (float)cont;
	printf("Menor=%d , Maior=%d, Media=%f", menor, maior, media);
	return 0;
}
