#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que implemente o calculo de 
fatorial (iterativo) de um n�mero utilizando o la�o fa�a ate.
 */

int main(int argc, char *argv[]) {
	int numero, resultado, cont;
	
	printf("Informe um numero inteiro maior que zero:");
	scanf("%d",&numero);
	resultado = 1;
	for(cont=1; cont<=numero; cont++)
	{
		resultado = cont*resultado;
	}
	printf("Fatorial de %d = %d", numero, resultado);
	
	return 0;
}
