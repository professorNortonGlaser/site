#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a[10], b[10];
	int resto, x;
	
	for(x=0; x<10; x++){
		printf("informe um numero:");
		scanf("%d", &a[x]);				
	}
	for(x=0; x<10; x++){
		resto = x % 2;
		if(resto==0){
			b[x] = a[x] * 2;	
		} else {
			b[x] = a[x] * 3;
		} 	
		printf("A=%d, B=%d \n", a[x], b[x]);
	}
	return 0;
}
