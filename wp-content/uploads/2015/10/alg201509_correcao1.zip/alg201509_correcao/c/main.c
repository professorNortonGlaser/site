#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int vetor[20];
	int x, maior, menor;
	float media = 0;
	
	for(x=0; x<20; x++){
		printf("informe um numero:");
		scanf("%d", &vetor[x]);			
	}
	for(x=0; x<20; x++){
		if(x==0){
			menor = vetor[0];
			maior = vetor[0];	
		} else {
			if(vetor[x]<menor){
				menor = vetor[x];
			} 	
			if(vetor[x]>maior){
				maior = vetor[x];
			} 
		}
		media = media + vetor[x];
	}
	media = media /20;
	printf("Menor=%d, Maior%d, Media=%f", menor, maior, media);
	return 0;
}
