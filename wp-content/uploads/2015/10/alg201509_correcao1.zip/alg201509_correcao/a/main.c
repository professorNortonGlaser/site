#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int vetor[20];
	float contPar, contImpar, percPar, percImpar;
	int i,resto;
	
	for(i=0; i<20;i++){
		printf("informe um numero para:");
		scanf("%d",&vetor[i]);
		resto = vetor[i] % 2;
		if(resto==0){
			contPar++;
		} else {
			contImpar++;
		}				
	}
	percPar = (contPar / 20) * 100;
	percImpar = (contImpar / 20) * 100;
	printf("Perc Par %f, Perc Impar %f",percPar, percImpar);	
	
	return 0;
}
