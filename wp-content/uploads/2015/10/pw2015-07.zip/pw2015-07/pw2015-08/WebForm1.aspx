﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw2015_08.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
crie uma página em ASP.NET que utilize os objetos de validação, seguindo as seguintes regras:<br />
» Data de Inscrição – Período de 01/01/2015 ate 30/06/2015<br />
» Email – validação de e-mail valido<br />
» Senha – campo obrigatório<br />
» Confirmação de senha – verificar se esta igual ao campo senha<br />
» cep  – código numérico de 8 dígitos<br /><br />

        <br />
        Data de Inscrição
        <asp:TextBox ID="txtData" runat="server"></asp:TextBox>
        <asp:RangeValidator ID="RangeValidator1" runat="server" ControlToValidate="txtData" ErrorMessage=" Período de 01/01/2015 ate 30/06/2015" MaximumValue="30/06/2015" MinimumValue="01/01/2015" Type="Date"></asp:RangeValidator>
        <br />
        Email
        <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
        <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" ControlToValidate="txtEmail" ErrorMessage="Informe um email valido" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
        <br />
        Senha<asp:TextBox ID="txtSenha" runat="server" TextMode="Password"></asp:TextBox>
        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtSenha" ErrorMessage="Informe uma senha !"></asp:RequiredFieldValidator>
        <br />
        Confirmação de senha<asp:TextBox ID="txtSenha2" runat="server" TextMode="Password"></asp:TextBox>
        <asp:CompareValidator ID="CompareValidator1" runat="server" ControlToCompare="txtSenha" ControlToValidate="txtSenha2" ErrorMessage="Email e senha devem ser iguais"></asp:CompareValidator>
        <br />
        cep<asp:TextBox ID="txtCep" runat="server"></asp:TextBox>
        <asp:RegularExpressionValidator ID="RegularExpressionValidator2" runat="server" ControlToValidate="txtCep" ErrorMessage="Informe um cep correto" ValidationExpression="\d{5}(-\d{3})?"></asp:RegularExpressionValidator>
        <br />
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" Text="Button" />
        <br />

    </div>
    </form>
</body>
</html>
