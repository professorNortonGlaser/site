﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="calculadora.aspx.cs" Inherits="pw2015_07.calculadora" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        Calculadora<br />
        <br />
        n1:
        <asp:TextBox ID="txtN1" runat="server"></asp:TextBox>
        <br />
        <br />
        n2:<asp:TextBox ID="txtN2" runat="server"></asp:TextBox>
        <br />
        <br />
        <asp:Label ID="lblMensagem" runat="server"></asp:Label>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="somar" Text="Somar" />
&nbsp;<asp:Button ID="Button2" runat="server" OnClick="subtrair" Text="Subtrair" />
&nbsp;<asp:Button ID="Button3" runat="server" OnClick="multiplicar" Text="Multiplicar" />
&nbsp;<asp:Button ID="Button4" runat="server" OnClick="dividir" Text="Dividir" />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
