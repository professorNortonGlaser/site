﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw2015_07
{
    public partial class calculadora : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void somar(object sender, EventArgs e)
        {
            try { 
                decimal a, b, r;
                a = Convert.ToDecimal(txtN1.Text);
                b = Convert.ToDecimal(txtN2.Text);
                r = a + b;
                lblMensagem.Text = Convert.ToString(r);
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Digite corretamente!";
            }  
        }

        protected void subtrair(object sender, EventArgs e)
        {
            try
            {
                decimal a, b, r;
                a = Convert.ToDecimal(txtN1.Text);
                b = Convert.ToDecimal(txtN2.Text);
                r = a - b;
                lblMensagem.Text = Convert.ToString(r);
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Digite corretamente!";
            }  
        }

        protected void multiplicar(object sender, EventArgs e)
        {
            try
            {
                decimal a, b, r;
                a = Convert.ToDecimal(txtN1.Text);
                b = Convert.ToDecimal(txtN2.Text);
                r = a * b;
                lblMensagem.Text = Convert.ToString(r);
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Digite corretamente!";
            }  
        }

        protected void dividir(object sender, EventArgs e)
        {
            try
            {
                decimal a, b, r;
                a = Convert.ToDecimal(txtN1.Text);
                b = Convert.ToDecimal(txtN2.Text);
                r = a / b;
                lblMensagem.Text = Convert.ToString(r);
            }
            catch(DivideByZeroException err1){
                lblMensagem.Text = "Divisão por zero, verifique !";
            }
            catch (Exception err2)
            {
                lblMensagem.Text = "Digite corretamente!";
            }  
        }
    }
}