#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float a,b,c;
	printf("Informe um valor para a:");
	scanf("%f", &a);
	printf("Informe um valor para b:");
	scanf("%f", &b);
	printf("Informe um valor para a:");
	scanf("%f", &c);
	
	if(a<(b+c) && b<(a+c) && c<(a+b))
	{
		if(a==b && a==c){
			printf("Equilatero !");	
		} 
		else {
			if(a==b || b==c || a==c){
				printf("Isoceles !");		
			}
			else {
				printf("Escaleno !");		
			}	
			
		}
	} 
	else
	{
		printf("Nao e um triangulo");	
	}
	
	
	return 0;
}
