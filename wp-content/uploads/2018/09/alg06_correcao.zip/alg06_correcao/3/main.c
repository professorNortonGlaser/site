#include <stdio.h>
#include <stdlib.h>

/* 
 A Secretaria de Meio Ambiente que controla o �ndice de polui��o mant�m 
 3 grupos de ind�strias que s�o altamente poluentes do meio ambiente. 
 O �ndice de polui��o aceit�vel varia de 0,05 at� 0,25. 
 Se o �ndice sobe para 0,3 as nd�strias do 1� grupo s�o intimadas a 
 suspenderem suas atividades, se o �ndice crescer para 0,4 
 as industrias do 1� e 2� grupo s�o intimadas a suspenderem suas atividades, 
 se o �ndice atingir 0,5 todos os grupos devem ser notificados 
 a paralisarem suas atividades. Fa�a um algoritmo em C 
 que leia o �ndice de polui��o medido e emita a notifica��o adequada 
 aos diferentes grupos de empresas.
 */

int main(int argc, char *argv[]) {
	float indice;
	printf("Informe o indice:");
	scanf("%f", &indice);
	
	if(indice >= 0.3){
		printf("Industrias do A grupo suspenderem suas atividades\n");				
		if(indice >= 0.4){
			printf("Industrias do B grupo suspenderem suas atividades\n");							
			if(indice >= 0.5){
				printf("Industrias do C grupo suspenderem suas atividades\n");							
			}
		}
	} 
	else {
		printf("Indice de poluicao aceitavel");	
	}
	
	return 0;
}
