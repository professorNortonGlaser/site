#include <stdio.h>
#include <stdlib.h>

/* 
Informe dois n�meros reais e um n�mero inteiro que represente a opera��o 
matem�tica a ser realizada (1-soma, 2-subtra��o, 3- multiplica��o, 4-divis�o) 
utilize o comando sele��o aninhado e exiba o resultado da opera��o matem�tica
escolhida.
 */

int main(int argc, char *argv[]) {
	float n1, n2, res;
	int op;
	
	printf("Informe um valor para n1:");
	scanf("%f", &n1);
	printf("Informe um valor para n2:");
	scanf("%f", &n2);
	printf("Informe a operacao: 1-somar 2-subtrair 3-multiplicar 4-dividir");
	scanf("%d", &op);
	
	if(op==1){
		res = n1+n2;
	} 
	else {
		if(op==2){
			res=n1-n2;
		}
		else{
			if(op==3){
				res=n1*n2;
			} 
			else{
				res=n1/n2;
			}
		}		
	}
	printf("O resultado = %f \n", res);
	
	return 0;
}
