#include <stdio.h>
#include <stdlib.h>

/* 
Desenvolva um programa em C que: Leia 4 (quatro) n�meros; 
Calcule o quadrado de cada um; 
Se o valor resultante do quadrado do terceiro for >= 1000,
 imprima-o e finalize; 
 Caso contr�rio, imprima os valores lidos e seus respectivos quadrados.
*/

int main(int argc, char *argv[]) {
	float a,b,c,d, qA, qB, qC, qD;
	
	printf("Informe o valor de A:");
	scanf("%f", &a);
	printf("Informe o valor de B:");
	scanf("%f", &b);
	printf("Informe o valor de C:");
	scanf("%f", &c);
	printf("Informe o valor de D:");
	scanf("%f", &d);
	qA = a*a;
	qB = b*b;
	qC = c*c;
	qD = d*d;
	if(qC >= 1000){
		printf("O terceiro %f", qC);
	} 
	else {
		printf("a=%f, b=%f, c=%f, d=%f", qA, qB, qC, qD);
	}
	
	
	return 0;
}
