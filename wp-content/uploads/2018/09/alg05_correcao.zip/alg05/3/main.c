#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que calcule a media ponderada das notas 
de 3 provas. 
A primeira e a segunda prova tem peso 1 e a terceira 
tem peso 2. 
Ao final, mostrar a media do aluno e indicar
se o aluno foi aprovado ou reprovado. 
A nota para aprova��o deve ser igual ou superior a 
60 pontos.
 */

int main(int argc, char *argv[]) {
	float nota1, nota2, nota3, media;
	printf("Informe um valor para nota 1 :");
	scanf("%f", &nota1);
	printf("Informe um valor para nota 2 :");
	scanf("%f", &nota2);
	printf("Informe um valor para nota 3 :");
	scanf("%f", &nota3);
	
	media = (nota1+nota2+(nota3*2))/4;
	
	if(media >=60){
		printf("Aluno aprovado %f ", media);	
	}
	else {
		printf("Aluno reprovado %f ", media);	
	}	
	
	return 0;
}
