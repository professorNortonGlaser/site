#include <stdio.h>
#include <stdlib.h>

/* 
Crie um  algoritmo que informe dois valores reais, 
valor em reais do litro da gasolina e 
valor em reais do litro do �lcool,  
calcule os 70% do valor da gasolina para definir na tela qual
combust�vel e o mais vantajoso, sabendo que o
valor do �lcool para ser mais vantajoso deve ser
 menor que 70% do valor da gasolina.
*/

int main(int argc, char *argv[]) {
	float gasolina, alcool, percGasolina;
	printf("Informe o valor da gasolina:");
	scanf("%f", &gasolina);
	printf("Informe o valor do alcool:");
	scanf("%f", &alcool);
	
	percGasolina = gasolina * 0.7;
	if(percGasolina <= alcool)
	{
		printf("A gasolina e melhor");	
	}
	else 
	{
		printf("O Alcool e melhor");	
	}
	
	return 0;
}
