#include <stdio.h>
#include <stdlib.h>

/* 
Leia o salario de um trabalhador e o valor da presta��o de 
um empr�stimo. 
Se a presta��o for maior que 20% do salario imprima:  
Empr�stimo n�o concedido, 
caso contrario imprima:  Empr�stimo concedido.
 */

int main(int argc, char *argv[]) {
	float salario, emprestimo, percSalario;
	printf("Informe o salario");
	scanf("%f", &salario);
	printf("Informe o emprestimo");
	scanf("%f", &emprestimo);
	
	percSalario = salario * 0.2; // 0.2 => 20/100 => 20%
	if(percSalario >= emprestimo){
		printf("Emprestimo concedido !");
	}
	else {
		printf("Emprestimo nao concedido !");
	}	
	
	return 0;
}
