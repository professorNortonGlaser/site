#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo em C que receba um numero inteiro e
verifique se este e positivo ou negativo, 
exiba uma mensagem
*/

int main(int argc, char *argv[]) {
	int numero;
	printf("Informe um numero:");
	scanf("%d", &numero);
	if(numero <0){
		printf("O numero informado e negativo");	
	} 
	else {
		printf("O numero informado e positivo");			
	}
	
	return 0;
}
