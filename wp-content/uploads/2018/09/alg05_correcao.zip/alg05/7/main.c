#include <stdio.h>
#include <stdlib.h>

/* 
Elabore um programa em C que leia as vari�veis C e N, 
respectivamente c�digo e n�mero de horas trabalhadas 
de um oper�rio. 
E calcule o sal�rio sabendo-se que ele ganha R$ 10,00 
por hora.
Quando o n�mero de horas exceder a 50 calcule o excesso 
de pagamento armazenando-o na vari�vel E, 
caso contr�rio zerar tal vari�vel. 
A hora excedente de trabalho vale R$ 20,00. 
No final do processamento imprimir o sal�rio total e 
o sal�rio excedente.
*/

int main(int argc, char *argv[]) {
	char c;
	float n, salTotal, salExtra, e, salNormal;
	
	printf("Informe o total de horas trabalhadas:");
	scanf("%f", &n);
	
	if(n>50){		
		e = (n -50);		
	} else {
		e = 0;
	} 
	salNormal = 50 * 10;	
	salExtra = e * 20;
	salTotal = salNormal + salExtra;
	printf("Sal. Normal=%f, Sal. Extra=%f, Sal. Total=%f", salNormal, salExtra, salTotal);
	
	return 0;
}
