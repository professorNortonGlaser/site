#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um programa em C que dada uma distancia em km converta e exiba em milhas,
onde 1Milha = 1,60934km
*/

int main(int argc, char *argv[]) {
	float m, k;
	char x;
	
	printf("Informe o valor em km:");
	scanf("%c", &x);
	
	
	printf("Informe o valor em km:");
	scanf("%f", &k);
	m = k / 1.60934;
	printf("O valor de %f km e igual a %f milhas", k, m);
	
	return 0;
}
