#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um programa em C que leia Tr�s valores: 
Distancia em km, Velocidade Media e consumo de Combust�vel de um carro, 
calcule o tempo de viagem e 
quantos litros de combust�vel ser�o necess�rios para completar a viagem.
 */

int main(int argc, char *argv[]) {
	float distancia, velocidade, consumo;
	float tempo, litros;
	
	printf("Informe a distancia em km:");
	scanf("%f", &distancia);
	
	printf("Informe a velocidade media:");
	scanf("%f", &velocidade);
	
	printf("Informe o consumo:");
	scanf("%f", &consumo);
	
	tempo = distancia/velocidade;
	litros = distancia/consumo;
	
	printf("Chegara em %f horas, e gastara %f litros", tempo, litros);
	
	return 0;
}
