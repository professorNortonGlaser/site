#include <stdio.h>
#include <stdlib.h>

/* 
3-Fa�a um programa em C que calcule a media ponderada de 3 n�meros reais (A,B e C)  
mostre o resultado onde os pesos ser�o (2,3,5)
*/

int main(int argc, char *argv[]) {
	float A, B, C;
	float media;
	printf("Informe um valor para A:");
	scanf("%f", &A);
	printf("Informe um valor para B:");
	scanf("%f", &B);
	printf("Informe um valor para C:");
	scanf("%f", &C);
	media = ((A*2)+(B*3)+(C*5))/10;
	printf("O resultado da media = %f", media);
	return 0;
}
