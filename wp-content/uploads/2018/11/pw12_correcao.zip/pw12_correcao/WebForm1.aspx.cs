﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

namespace pw12_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pwebt;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {
            carregar();
        }

        private void carregar()
        {
            DataSet ds = new DataSet();
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from livro order by titulo";
            MySqlDataAdapter conversor1 = new MySqlDataAdapter(sql, conexao);
            conversor1.Fill(ds, "todos");
            sql = "select codigo, titulo from livro where valor <=50 order by titulo";
            MySqlDataAdapter conversor2 = new MySqlDataAdapter(sql, conexao);
            conversor2.Fill(ds, "promo");
            conexao.Close();
            GridView1.DataSource = ds.Tables["todos"];
            GridView1.DataBind();
            DropDownList1.DataSource = ds.Tables["promo"];
            DropDownList1.DataValueField = "codigo";
            DropDownList1.DataTextField = "titulo";
            DropDownList1.DataBind();
        }
    }
}