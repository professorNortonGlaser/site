<html>
<body>
usuarios: <select id="usu" name="usu">
			<?php comboUsuarios(); ?>
		  </select><br>
		  <table border="1">
		  <tr><td>Codigo</td><td>Nome</td><td>Email</td></tr>
		  <?php montaTabela(); ?>
		  </table>
</body>
</html>
<?php
function comboUsuarios(){
$con = new mysqli("localhost","root","root","pweb");
$sql = "select codigo, nome from usuario ";
$retorno = mysqli_query($con, $sql);
while($reg = mysqli_fetch_array($retorno))
{
	echo "<option value='". $reg["codigo"] ."'>". $reg["nome"] ."</option>";
}
$con->close();
}
function montaTabela(){
$con = new mysqli("localhost","root","root","pweb");
$sql = "select * from usuario order by nome";
$retorno = mysqli_query($con, $sql);
while($reg = mysqli_fetch_array($retorno))
{
	echo "<tr><td>". $reg["codigo"] . "</td>";
	echo "<td>". $reg["nome"] . "</td>";
	echo "<td>". $reg["email"] . "</td>";
	echo "</tr>";
}
$con->close();
}
?>

		  
