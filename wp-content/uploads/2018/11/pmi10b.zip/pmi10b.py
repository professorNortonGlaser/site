#2- Utilize o Script da atividade PMI08 e grave
#as entradas de dados e a saida  da mensagem
#(Aprovado e Reprovado) em um arquivo CSV,
#com cada dado em uma coluna do arquivo
import csv

def mediaAluno():
    p1 = float(input("Informe a nota p1:"))
    p2 = float(input("Informe a nota p2:"))
    p3 = 0
    faltas = float(input("Quantidade de faltas:"))
    percFaltas = faltas / 20
    media = (p1+p2)/2
    conteudo = str(p1) +","+ str(p2) +","+ str(media)
    if percFaltas > 0.3 :
        print("Aluno reprovado por faltas")
    else :
        if media >= 6 :
            print("Aluno aprovado :", media)
            conteudo= conteudo+",Aprovado"
        else :
            p3 = float(input("Informe a nota p3 :"))
            conteudo= conteudo+","+ str(p3) + ","+ str(media)
            media = (p1+p2+p3)/3
            if media >= 6:
                print("Aprovado no exame :", media)
                conteudo= conteudo+",Aprovado no exame"
            else :
                print("Reprovado no exame :", media)
                conteudo= conteudo+",Reprovado no exame"
    conteudo = [str(p1), str(p2), str(p3), str(media)]
    gravarCSV(conteudo)
    print("Arquivo Gravado!")


def gravarCSV(vetor):
    arq = open("pmi10b.csv",'w')
    c = csv.writer(arq, delimiter=';')
    c.writerow(vetor)    
    arq.close()

mediaAluno();
