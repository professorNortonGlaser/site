#correção atividade 10 item 1
#1- Utilize o Script da atividade PMI08
#e grave as entradas de dados e a saida
#da mensagem (Aprovado e Reprovado)
#em um arquivo texto

def gravarArquivo(conteudo, nome):
    arq = open(nome, 'a')
    arq.write(conteudo)
    arq.close()

def mediaAluno():
    p1 = float(input("Informe a nota p1:"))
    p2 = float(input("Informe a nota p2:"))
    faltas = float(input("Quantidade de faltas:"))
    percFaltas = faltas / 20
    media = (p1+p2)/2
    conteudo = str(p1) +","+ str(p2) +","+ str(media)
    if percFaltas > 0.3 :
        print("Aluno reprovado por faltas")
    else :
        if media >= 6 :
            print("Aluno aprovado :", media)
            conteudo= conteudo+",Aprovado"
        else :
            p3 = float(input("Informe a nota p3 :"))
            conteudo= conteudo+","+ str(p3) + ","+ str(media)
            media = (p1+p2+p3)/3
            if media >= 6:
                print("Aprovado no exame :", media)
                conteudo= conteudo+",Aprovado no exame"
            else :
                print("Reprovado no exame :", media)
                conteudo= conteudo+",Reprovado no exame"
    gravarArquivo(conteudo, "notas2.txt")
    print("Arquivo Gravado!")

            
mediaAluno()
