import subprocess
saida1 = subprocess.check_output(["notepad.exe"])
print(saida1)

saida2 = subprocess.check_output(["cmd.exe", "/C", "dir"]) 
print(saida2)
