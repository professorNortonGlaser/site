import os
#os.system('python teste12d.py')
os.system('notepad.exe')
os.system('calc.exe')
d = os.getcwd()      
print(d)
# Executa o comando mkdir no shell do sistema
os.system('mkdir today')  
# Altera o diretório de trabalho atual
os.chdir('today')   
d = os.getcwd()      
print(d)
