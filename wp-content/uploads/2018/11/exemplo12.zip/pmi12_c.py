import os
import subprocess
#devolve uma lista com todas as funções do módulo
x = dir(os)
print(x)
y = dir(subprocess)
print(y)

#devolve uma extensa página de manual criada a partir das docstrings do módulo
#y = help(os)
#print(y)
