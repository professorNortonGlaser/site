import smtplib
smtp = smtplib.SMTP('smtp-mail.outlook.com', 587) 
smtp.starttls()
smtp.login('fatecpwAds2016@outlook.com', 'FreiJoao59') 
de = 'fatecpwAds2016@outlook.com'
para = ['norton.glaser@fatec.sp.gov.br'] 
msg = """From: %s
To: %s 
Subject: TESTE PYTHON
Email de teste .""" % (de, ', '.join(para)) 
smtp.sendmail(de, para, msg)
smtp.quit()
print("EMAIL ENVIADO !!!")
