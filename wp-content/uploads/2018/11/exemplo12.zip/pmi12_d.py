import os
import shutil

shutil.copyfile('lista.txt', 'today\\lista2.txt')
shutil.move('today\\lista2.txt', 'today\\l.txt')

