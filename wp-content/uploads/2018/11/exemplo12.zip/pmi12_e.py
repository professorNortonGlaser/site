from urllib.request import urlopen
for line in urlopen("http://professor.norton.net.br"):
    if str("PMI") in str(line):
        print(line)
