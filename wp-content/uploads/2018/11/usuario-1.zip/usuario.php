﻿<html>
<body>
<h1>Usuário</h1>
<form method="post" action="usuario.php">
codigo:
<input type="text" name="codigo" id="c" /><br/>
Nome:
<input type="text" name="nome" id="n" /><br/>
Email:
<input type="text" name="email" id="e" /><br/>
Senha:
<input type="password" name="senha" id="s" /><br/>
<input type="submit" name="b1" value="inserir" />
<input type="submit" name="b2" value="pesquisar" />
<input type="submit" name="b3" value="alterar" />
<input type="submit" name="b4" value="excluir" />
</form>
<?php
	if(isset($_POST["b1"])) inserir();
	if(isset($_POST["b2"])) pesquisar();
	if(isset($_POST["b3"])) alterar();
	if(isset($_POST["b4"])) excluir();
?> </body></html>
<?php
function inserir(){
	$con = new mysqli("localhost","root","","jogos");
	$nome  = $_POST["nome"];
	$email = $_POST["email"];
	$senha = $_POST["senha"];
	$sql = "insert into usuario(nome,email,senha) values('$nome', '$email', '$senha')";
	mysqli_query($con, $sql);
	echo "Registro inserido com sucesso !";
	$con->close();
}
function pesquisar(){
	$con = new mysqli("localhost","root","","jogos");
	$cod = $_POST["codigo"];
	$sql = "select * from usuario where codigo=$cod";
	$retorno = mysqli_query($con, $sql);
	if($reg = mysqli_fetch_array($retorno)){
		echo "<script lang='javascript'>";
		echo "c.value='". $reg["codigo"]."';";
		echo "n.value='". $reg["nome"]  ."';";
		echo "e.value='". $reg["email"] ."';";
		echo "</script>";		
	} else {
		echo "Registro não encontrado";
	}
	$con->close();
}
function alterar(){
	$con = new mysqli("localhost","root","","jogos");
	$nome  = $_POST["nome"];
	$email = $_POST["email"];
	$senha = $_POST["senha"];
	$cod   = $_POST["codigo"];
	$sql = "update usuario set nome='$nome',email='$email',senha='$senha' where codigo=$cod";
	mysqli_query($con, $sql);
	echo "Registro alterado com sucesso !";
	$con->close();
}
function excluir(){
	$con = new mysqli("localhost","root","","jogos");	
	$cod   = $_POST["codigo"];
	$sql = "delete from usuario where codigo=$cod";
	mysqli_query($con, $sql);
	echo "Registro removido com sucesso !";
	$con->close();
}
?>	
