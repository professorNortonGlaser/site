﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw13_correcao
{
    public partial class converter : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["senha"] = Request["senha"];
            Session["nome"]   = Request["nome"];
            Session["email"]  = Request["email"];
            Response.Redirect("sessao.aspx");
        }
    }
}