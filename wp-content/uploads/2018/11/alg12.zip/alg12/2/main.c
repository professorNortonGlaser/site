#include <stdio.h>
#include <stdlib.h>

/* 
Crie uma tabela de um campeonato de futebol, com 10 times e 4 colunas
Na coluna 0 e o total de vitorias (multiplique por 3 pontos)
Na coluna 1 o total de empates (multiplique por 1 ponto)
Na coluna 2 o total de derrotas (multiplique por 0 pontos)
Na coluna 3 , calcule o total de pontos
Mostre ao final, o tr�s primeiros colocados da tabela
*/

int main(int argc, char *argv[]) {
	int campeonato[10][4];
	int x,r, pontos, maior, maximoPontos;
	
	for(x=0; x<10; x++){
		printf("Informe o total de vitorias do time[%d]:",x);	
		scanf("%d", &campeonato[x][0]);
		printf("Informe o total de empates do time[%d]:",x);	
		scanf("%d", &campeonato[x][1]);
		printf("Informe o total de derrotas do time[%d]:",x);	
		scanf("%d", &campeonato[x][2]);
		pontos = (campeonato[x][0]*3)+campeonato[x][1];
		campeonato[x][3] = pontos;		
	}
	maximoPontos = 0;
	for(r=0; r<10; r++){
		maior = 0;
		for(x=0;x<10;x++){
			if(maximoPontos==0 || maximoPontos>campeonato[x][3]){		
				if(campeonato[x][3] > maior){
					maior = campeonato[x][3];	
				}	
			}
		}
		printf("[%d] Colocado = %d\n", r, maior);		
		maximoPontos = maior;
	}
	
	
	
	return 0;
}
