#Gravando um arquivo texto
import csv
import xlrd
import xlwt

def gravarExcel():
    arq = xlrd.open_workbook("teste.xlsx")
    plan = arq.sheet_by_index(0)    
    nome = input("Informe o seu nome:")
    telefone = input("Informe o seu telefone:")
    email = input("Informe o seu email:")
    plan['A1'] = nome    
    plan['B1'] = telefone
    plan['C1'] = email
    arq.save()


def gravarArquivo(conteudo, nome):
    arq = open(nome, 'a')
    arq.write(conteudo)
    arq.close()

def lerArquivo():
    nome = input("Informe o nome do arquivo:")
    arq = open(nome,'r')
    t = arq.read()
    arq.close()
    print(t)

def mediaDoArquivo():    
    arq = open('lista.txt','r')
    media = float(0)
    cont = 0
    for line in arq.readlines():
        media = media + float(line)
        cont=cont+1
    media = media / cont
    print("A media do arquivo = %f"% media)
    arq.close()

def calculaMediaCSV():
    arq = open('teste.csv','r')
    lines = csv.reader(arq)
    
    for line in lines:
        p1 = float(line[0])
        p2 = float(line[1])
        m = (p1+p2) /2
        if m>=6:
            print("Aprovado %f"% m)
        else:
            print("Reprovado %f"% m)


#c = input("Informe a sua msg:")
#n = input("Informe o nome do arquivo")
#gravarArquivo(c, n)

#lerArquivo()
#mediaDoArquivo()
#calculaMediaCSV()
gravarExcel()
