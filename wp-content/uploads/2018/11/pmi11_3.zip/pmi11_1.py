import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 2, 100)
x2 = np.linspace(8, 14, 100)
y = np.linspace(6, 12, 100)
y2 = np.linspace(15, 22, 100)
z = np.linspace(-4, 8, 100)

plt.plot(x, x2, label='linha1')
plt.plot(y, y2, label='linha2')
plt.plot(z, z**1.75, label='linha3')

plt.xlabel('x label')
plt.ylabel('y label')

plt.title("Simple Plot")

plt.legend()

plt.show()
