<html>
<body>
<form method="post" action="produto.php">
codigo:
<input type="text" id="cod" name="cod" /><br/>
nome:
<input type="text" id="nom" name="nom" /><br/>
valor:
<input type="text" id="val" name="val" /><br/>
qtd:
<input type="text" id="qtd" name="qtd" /><br/> 
<input type="submit" value="Inserir" name="b1"/>
<input type="submit" value="Consultar" name="b2"/>
<input type="submit" value="Alterar" name="b3"/>
<input type="submit" value="Excluir" name="b4"/>
</form>
<?php
if(isset($_POST["b1"])) inserir();
if(isset($_POST["b2"])) consultar();
if(isset($_POST["b3"])) alterar();
if(isset($_POST["b4"])) excluir();
?>
</body></html>
<?php
function inserir(){
$con=new mysqli("localhost","root","","jogos");	
$nom = $_POST["nom"];
$val = $_POST["val"];
$qtd = $_POST["qtd"];
$sql = "insert into produto(nome, valor, qtd) values('$nom', '$val', '$qtd')";
mysqli_query($con, $sql);
$con->close();
echo "Registro inserido com sucesso !";
}

function alterar(){
	$con=new mysqli("localhost","root","","jogos");	
	$nom = $_POST["nom"];
	$val = $_POST["val"];
	$qtd = $_POST["qtd"];
	$cod = $_POST["cod"];
	$sql = "update produto set nome='$nom', valor='$val', qtd='$qtd' where codigo='$cod'";
	mysqli_query($con, $sql);
	$con->close();
	echo "Registro alterado com sucesso !";
}

function excluir(){
	$con=new mysqli("localhost","root","","jogos");	
	$cod = $_POST["cod"];
	$sql = "delete from produto where codigo='$cod'";
	mysqli_query($con, $sql);
	$con->close();
	echo "Registro removido com sucesso !";
}

function consultar(){
	$con=new mysqli("localhost","root","","jogos");	
	$cod = $_POST["cod"];
	$sql = "select * from produto where codigo=$cod";
	$retorno = mysqli_query($con, $sql);
	if($reg = mysqli_fetch_array($retorno)){
		echo "<script lang='javascript'>";
		echo "cod.value='". $reg["codigo"] ."';";
		echo "nom.value='". $reg["nome"]   ."';";
		echo "val.value='". $reg["valor"]  ."';";
		echo "qtd.value='". $reg["qtd"]    ."';";
		echo "</script>";
	} else {
		echo "O registro nao existe";
	}
	$con->close();	
}
?>

