#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Col0=Nota P1, col1=nota p2, col2=nota p3
int main(int argc, char *argv[]) {
	float notas[10][3]; //10 linhas e 4 colunas
	float tx[10];
	//int aux = sizeof(notas[0]);
	//printf("linha=%d\n",  aux);
	int len = sizeof(notas)/sizeof(notas[0]);
	
	printf("teste=%d\n", len );
/*	int x;
	int p1=0, p2=1, m=2;
	for(x=0;x<10;x++){
		printf("Informe a nota p1 do aluno[%d]:",x);		
		scanf("%f", &notas[x][p1]); //nota p1
		printf("Informe a nota p2 do aluno[%d]:",x);		
		scanf("%f", &notas[x][p2]); //nota p2
		notas[x][m] = (notas[x][p1]+notas[x][p2])/2; //media								
	}
	float percApr=0, percRep=0, media=0;
	for(x=0;x<10;x++){
		if(notas[x][m]>=6){
			percApr++;	
		} else {
			percRep++;	
		}
		media+=notas[x][m];
	}
	percApr=(percApr/10)*100;
	percRep=(percRep/10)*100; 
	media=media/10;
	printf("Aprovados=%.2f,Reprovados=%.2f,media=%.2f",percApr,percRep,media);*/
	return 0;
}

