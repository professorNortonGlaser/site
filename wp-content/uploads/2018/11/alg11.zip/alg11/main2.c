#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


	// Col0=Nota P1, col1=nota p2, col2=nota p3
int main(int argc, char *argv[]) {
	float notas[10][3]; //10 linhas e 4 colunas
	float tx[10];
	int aux = sizeof(notas[0]);
	printf("linha=%d\n",  aux);
	int aux2 = sizeof(notas[0][0]);
	printf("linha=%d\n",  aux2);
	int aux3 = aux/aux2; 
	printf("colunas=%d\n",  aux3);
	int len = sizeof(notas)/sizeof(notas[0]);
	
	printf("teste=%d\n", len );
	return 0;
}
