#Gravando um arquivo texto
import csv
import xlrd
import xlwt
import xlutils

def gravarExcel():
    arq = xlrd.open_workbook("teste.xlsx")
    wb = copy(arq) 
    plan = wb.get_sheet(0)
    plan.title = 'Teste Python'

    nome = input("Informe o seu nome:")
    telefone = input("Informe o seu telefone:")
    email = input("Informe o seu email:")

    plan.write(0, 1, nome)
   
    
    wb.save('teste.xlsx')


def gravarArquivo(conteudo, nome):
    arq = open(nome, 'a')
    arq.write(conteudo)
    arq.close()

def lerArquivo():
    nome = input("Informe o nome do arquivo:")
    arq = open(nome,'r')
    t = arq.read()
    arq.close()
    print(t)

def mediaDoArquivo():    
    arq = open('lista.txt','r')
    media = float(0)
    cont = 0
    for line in arq.readlines():
        media = media + float(line)
        cont=cont+1
    media = media / cont
    print("A media do arquivo = %f"% media)
    arq.close()

def calculaMediaCSV():
    arq = open('teste.csv','r')
    lines = csv.reader(arq)
    
    for line in lines:
        p1 = float(line[0])
        p2 = float(line[1])
        m = (p1+p2) /2
        if m>=6:
            print("Aprovado %f"% m)
        else:
            print("Reprovado %f"% m)

def gravarCSV(vetor):
    arq = open('teste2.csv','w')
    c = csv.writer(arq, delimiter=';')
    c.writerow(vetor)    
    arq.close()




x = print("Escolha a funcao: \n 0-gravarArquivo 1-lerArquivo 2-mediaDoArquivo 3-calculaMediaCSV 4-gravarCSV")
if x == 0:
    c = input("Informe a sua msg:")
    n = input("Informe o nome do arquivo")
    gravarArquivo(c, n)
elif x == 1:
    lerArquivo()
elif x == 2:
    mediaDoArquivo()
elif x == 3:
    calculaMediaCSV()
elif x == 4:
    vetor = ['2','3','4']  
    gravarCSV(vetor)    
else:
   print("imprime outra coisa")

#gravarExcel()
