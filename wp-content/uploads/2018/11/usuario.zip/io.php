<html>
<body>
<form action="usuario.php" method="post">
Codigo:<input type="text" name="codigo" id="c"><br/>
Nome:<input type="text" name="nome" id="n"><br/>
Email:<input type="text" name="email" id="e"><br/>
Senha<input type="password" name="senha" id="s"><br/>
<input type="submit" name="b1" value="Inserir">
<input type="submit" name="b2" value="Pesquisar">
<input type="submit" name="b3" value="Alterar">
<input type="submit" name="b4" value="Excluir">
</form>
<?php
	if(isset($_POST["b1"])) inserir();
	if(isset($_POST["b2"])) pesquisar();
	if(isset($_POST["b3"])) alterar();
	if(isset($_POST["b4"])) excluir();
?>
</body></html>
<?php
function inserir(){
	$nome  = $_POST["nome"];
	$email = $_POST["email"];
	$senha = $_POST["senha"];
	$con   = new mysqli("localhost","root","", "segna");
	$sql = "insert into usuario(nome, email, senha) value('$nome','$email',md5('$senha'))";
	mysqli_query($con, $sql);
	echo "registro inserido com sucesso !!";
	$con->close();	
}
function pesquisar(){
	$codigo = $_POST["codigo"];
	$con   = new mysqli("localhost","root","", "segna");
	$sql = "select * from usuario where codigo=$codigo";
	$retorno = mysqli_query($con,$sql);
	if($reg = mysqli_fetch_array($retorno)){
		echo "<script lang='javascript'>";
		echo "n.value='". $reg["nome"] ."';";
		echo "c.value='". $reg["codigo"] ."';";
		echo "e.value='". $reg["email"] ."';";
		echo "</script>";
	} else {
		echo "registro não encontrado !";
	}	
	$con->close();
}
function alterar(){
	$nome  = $_POST["nome"];
	$email = $_POST["email"];
	$senha = $_POST["senha"];
	$codigo= $_POST["codigo"];
	$con   = new mysqli("localhost","root","", "segna");
	$sql = "update usuario set nome='$nome', email='$email', senha=md5('$senha') where codigo=$codigo";
	mysqli_query($con, $sql);
	echo "registro alterado com sucesso !!";
	$con->close();	
}
function excluir(){
	$codigo= $_POST["codigo"];
	$con   = new mysqli("localhost","root","", "segna");
	$sql = "delete from usuario where codigo=$codigo";
	mysqli_query($con, $sql);
	echo "registro removido com sucesso !!";
	$con->close();	
}
?>