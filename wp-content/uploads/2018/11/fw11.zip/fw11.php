<html>
<body>
<form action="fw11.php" method="post">
codigo:<input type="text" id="c" name="codigo" />
<br/>
titulo:<input type="text" id="t" name="titulo" />
<br/>
descritivo:<textarea id="d" name="descritivo"></textarea><br/>
prioridade:<select id="p" name="prioridade">
			<option>1</option>
			<option>2</option>
			<option>3</option>
			<option>4</option></select><br>
status:<select id="s" name="status">
			<option value="1">Aberto</option>
			<option value="2">Fechado</option>
			<option value="3">Cancelado</option>
		</select><br>
<input type="submit" value="Inserir" name="b1" >
<input type="submit" value="Pesquisar" name="b2" >
<input type="submit" value="Alterar" name="b3" >
<input type="submit" value="Excluir" name="b4" ></form> 
<?php
if(isset($_POST["b1"])) inserir();
if(isset($_POST["b2"])) pesquisar();
if(isset($_POST["b3"])) alterar();
if(isset($_POST["b4"])) Excluir();
?>
</body>
</html>
<?php
function inserir(){
	$con = new mysqli("localhost","root","","pweb");
	$tit = $_POST["titulo"];
	$des = $_POST["descritivo"];
	$pri = $_POST["prioridade"];
	$sta = $_POST["status"];
	
	$sql = "insert into chamado(titulo, descritivo, prioridade,status) values('$tit', '$des', $pri, $sta)";
	mysqli_query($con, $sql);
	echo "Chamado gravado com sucesso";
	$con->close();
}

function alterar(){
	$con = new mysqli("localhost","root","","pweb");
	$tit = $_POST["titulo"];
	$des = $_POST["descritivo"];
	$pri = $_POST["prioridade"];
	$sta = $_POST["status"];
	$cod = $_POST["codigo"];
	$sql = "update chamado set titulo='$tit', descritivo='$des', prioridade=$pri,status=$sta where codigo=$cod";
	mysqli_query($con, $sql);
	echo "Chamado alterado com sucesso";
	$con->close();
}

function excluir(){
	$con = new mysqli("localhost","root","","pweb");
	$cod = $_POST["codigo"];
	$sql = "delete from chamado where codigo=$cod";
	mysqli_query($con, $sql);
	echo "Chamado removido com sucesso";
	$con->close();
}

function pesquisar(){
$con = new mysqli("localhost","root","","pweb");
	$cod = $_POST["codigo"];
	$sql = "select * from chamado where codigo=$cod";
	$retorno = mysqli_query($con, $sql);
	if($reg = mysqli_fetch_array($retorno)){
		echo "<script lang='javascript'>";
		echo "c.value=". $reg["codigo"] .";";
		echo "t.value='". $reg["titulo"] ."';";
		echo "d.value='". $reg["descritivo"] ."';";
		echo "p.value=". $reg["prioridade"] .";";
		echo "s.value=". $reg["status"] .";";
		echo "</Script>";
	} else {
		echo "registro não existe";	
	}
	$con->close();
}
?>
