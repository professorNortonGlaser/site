<html>
<body>
<?php
session_start();
if(isset($_SESSION["codigo"])){
	echo "ola ". $_SESSION["nome"] ." boa noite";	
} else {
	header("location: login.php");
}
?>
<table border="1">
<tr><td>codigo</td><td>nome</td><td>email</td></tr>
<?php listaTabela() ?>
</table></body></html>
<?php
function listaTabela(){
$con = new mysqli("localhost","root","","pweb");
$sql = "select * from usuario order by nome";
$retorno = mysqli_query($con, $sql);
while($reg = mysqli_fetch_array($retorno)){
	echo "<tr><td>". $reg["codigo"] ."</td><td>". $reg["nome"] . "</td><td>". $reg["email"] ."</td></tr>";	
}	
$con->close();
}
?>
