<html>
<body>
<form method="post" action="login.php">
email:<input type="text" name="email" id="e" />
<br/>
senha:<input type="password" name="senha" id="s" />
<br/>
<input type="submit" name="b1" value="Entrar" />
</form>
<?php
if(isset($_POST["b1"])) login();	
?>
</body></html>
<?php
function login(){
$con = new mysqli("localhost","root","","pweb");
$email = $_POST["email"];	
$senha = $_POST["senha"];
$sql = "select * from usuario where email='$email' and senha=md5('$senha')";
$retorno = mysqli_query($con, $sql);
if($reg = mysqli_fetch_array($retorno)){
	echo "Usuario Valido !!!";
	session_start();
	$_SESSION["codigo"] = $reg["codigo"];
	$_SESSION["nome"] = $reg["nome"];
	header('location: lista.php');
} else {
	echo "Email ou senha invalidos !";
}
$con->close();
}
?>
