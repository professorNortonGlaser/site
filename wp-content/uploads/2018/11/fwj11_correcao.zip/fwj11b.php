<html>
<body>
<form action="fwj11b.php" method="post">
email:<input type="text" id="e" name="email"/><br>
Senha:<input type="password" id="s" name="senha"/><br>
<input type="submit" value="entrar" name="b1" />
</form>
<?php
if(isset($_POST["b1"])) fazerLogin();
?></body></html>
<?php
function fazerLogin(){
$con = new mysqli("localhost","root","","jogos");
$email = $_POST["email"];
$senha = $_POST["senha"];
$sql = "select * from usuario where email='$email' and senha='$senha'";
	$retorno = mysqli_query($con, $sql);	
	if($reg = mysqli_fetch_array($retorno)){
		echo "Acesso Liberado";
		header("location: fwj11.php");
	} else {
		echo "email ou senha invalidos";
	}
$con->close();	
}
?>
