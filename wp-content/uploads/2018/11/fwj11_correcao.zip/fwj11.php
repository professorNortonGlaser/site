<html>
<body>
	<table border="1">
	<tr><td>Codigo</td><td>Nome</td>
	<td>Email</td><td>Senha</td></tr>
	<?php 
		montaLista();
	?>
	</table>
</body></html>
<?php
function montaLista(){
	$con = new mysqli("localhost","root","","jogos");
	$sql = "select * from usuario order by nome";
	$retorno = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($retorno))
	{
		echo "<tr><td>". $reg["codigo"] ."</td>";
		echo "<td>". $reg["nome"] ."</td>";
		echo "<td>". $reg["email"] ."</tr>";
			
	}
	$con->close();
}
?>
	
	


  
	  