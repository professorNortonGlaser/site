﻿<html>
<body>
	Promoção:
	<select id="promo" name="promo">
	<?php carregaPromo(); ?>			
	</select>
	<br />
	<table border="1">
	<tr><td>Codigo</td><td>nome</td><td>valor</td><td>qtd</td></tr>
	<?php montaLista(); ?>
	</table>
</body>
</html>
<?php 
function carregaPromo(){
$con = new mysqli("localhost","root","","jogos");
$sql = "select * from produto where valor < 100";
$retorno = mysqli_query($con, $sql);
while($reg = mysqli_fetch_array($retorno))
{
	echo "<option value='". $reg["codigo"] ."'>". $reg["nome"] ." R$ ".	$reg["valor"] ."</option>";
}
$con->close();
}

function montaLista(){
$con = new mysqli("localhost","root","","jogos");
$sql = "select * from produto order by nome";
$retorno = mysqli_query($con, $sql);
while($reg = mysqli_fetch_array($retorno))
{
	echo "<tr><td>". $reg["codigo"] ."</td>";
	echo "<td>". $reg["nome"] ."</td>";
	echo "<td>". $reg["valor"] ."</td>";
	echo "<td>". $reg["qtd"] ."</td></tr>";
}
$con->close();
}
?>	
	

