#include <stdio.h>
#include <stdlib.h>

/* 
Reutilizando o algoritmo do caixa eletr�nico, 
implemente um la�o fa�a enquanto que verifique se o usu�rio deseja continuar, 
caso a vari�vel coletada for igual 1 reinicie o la�o, mantendo o valor do saldo.
*/

int main(int argc, char *argv[]) {
	float saldo = 1000;
	float valor;
	int op; //1-saldo 2-Saque 3-deposito
	int continua;
	
	do {
		system("cls");
		printf("Informe 1-saldo 2-Saque 3-deposito:");
		scanf("%d", &op);
		
		switch(op){
			case 1:{
				printf("O valor do saldo= %f", saldo);
				break;
			}	
			case 2:{
				printf("Informe o valor do saque:");
				scanf("%f", &valor);
				if(valor > saldo){
					printf("Saldo insuficiente !");	
				} else {
					saldo = saldo - valor;
					printf("Saque realizado ! saldo atual:%f", saldo);	
				}
				break;
			}
			case 3:{			
				printf("Informe o valor do deposito !");
				scanf("%f", &valor);
				saldo = saldo + valor;
				printf("deposito efetuado ! saldo atual:%f", saldo);	
				break;
			}
			default :{
				printf("Opcao invalida !");
				break;
			}		
		}
		
		printf("\nDeseja Continuar 1-Sim, 0-Nao");
		scanf("%d", &continua);
	} while (continua==1);
	
	
	return 0;
}
