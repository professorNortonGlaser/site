<!--Caminho fisico= gravar .php c:\xampp\htdocs -->
<!--Caminho Virtual= testar http://localhost/ -->
<html>
<body>
<h1>Tabuada</h1>
<!-- 
POST=> Form 
GET=> URL 
-->
<form method="post" action="fw09.php">
	Numero:<input type="text" id="num" name="num" /><br/>
	<input type="submit" name="bt1" value="tabuada" />
	<input type="submit" name="bt2" value="fatorial" />
</form>
<a href="fw09.php?a=4&b=6">calcula media</a>
<table border="1" >
<?php
	//isset verifica se variavel preenchida
	if(isset($_POST["bt1"])){
		tabuada();
	}
	if(isset($_POST["bt2"])){
		fatorial();	
	}
	if(isset($_GET["a"])){
		$c = ($_GET["a"] + $_GET["b"])/2;
		echo "<tr><td>media=$c</td></tr>";
	}
?>
</table>
</body>
</html>

<?php
function tabuada(){
	$num = $_POST["num"];
	$pro = 1;
	$con = 1;
	while($con <= 10){
		$pro = $con * $num;		
		echo "<tr><td>$num</td><td>$con</td><td>$pro</td></tr>";
		$con = $con  +1;
	}
}
function fatorial(){
	$num = $_POST["num"];
	$fat = 1;
	$con = 1;
	while($con <= $num){
		$fat = $fat * $con;		
		echo "<tr><td>$con</td><td>$fat</td></tr>";
		$con = $con  +1;
	}
}

?>