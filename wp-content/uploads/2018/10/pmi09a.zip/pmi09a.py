#Correção atividade pmi09
#Crie uma função em python que receba dois valores:
#Distancia em km, e consumo de Combustível de um carro,
#calcule quantos litros de combustível serão
#necessários para completar a viagem.

def quantidadeLitros(km, consumo):
    litros = km / consumo
    return litros

#Crie uma função em python que dada uma
#distancia em km converta e exiba em milhas,
#onde 1Milha = 1.60934km
def kmMilhas(km):
    milhas = km / 1.60934
    return milhas

k = float(input("Informe quantos km:"))
c = float(input("Informe o consumo do seu carro:"))
print("Vc gastar %f litros "% quantidadeLitros(k, c))
print("Total em milhas %f "% kmMilhas(k))
