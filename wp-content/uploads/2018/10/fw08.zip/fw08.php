<!--Caminho fisico= gravar .php c:\xampp\htdocs -->
<!--Caminho Virtual= testar http://localhost/ -->
<html>
<body>
<h1>Tabuada</h1>
<table border="1" >
<?php
	$num = 8;
	$pro = 1;
	$con = 1;
	while($con <= 10){
		$pro = $con * $num;		
		echo "<tr><td>$num</td><td>$con</td><td>$pro</td></tr>";
		$con = $con  +1;
	}
?>
</table>
</body>
</html>