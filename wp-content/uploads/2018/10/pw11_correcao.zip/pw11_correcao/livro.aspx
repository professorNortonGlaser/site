﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="livro.aspx.cs" Inherits="pw11_correcao.livro" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <br />
        <h1>LIVRO<br />
        </h1>
        codigo:<asp:TextBox ID="txtCodigo" runat="server"></asp:TextBox>
&nbsp;<asp:Button ID="Button2" runat="server" Text="Carregar" OnClick="pesquisar" /><br />
        titulo: <asp:TextBox ID="txtTitulo" runat="server"></asp:TextBox>      <br />
        autor:  <asp:TextBox ID="txtAutor" runat="server"></asp:TextBox><br />
        qtd:<asp:TextBox ID="txtQtd" runat="server" TextMode="Number"></asp:TextBox><br />
        valor:<asp:TextBox ID="txtValor" runat="server"></asp:TextBox><br />
        paginas:<asp:TextBox ID="txtPagina" runat="server" TextMode="Number"></asp:TextBox><br />
        resumo:<asp:TextBox ID="txtResumo" runat="server" TextMode="MultiLine"></asp:TextBox><br /><br />
        <asp:Button ID="Button1" runat="server" Text="Inserir" OnClick="inserir" />
        <asp:Button ID="Button3" runat="server" Text="Alterar" OnClick="alterar" />
        <asp:Button ID="Button4" runat="server" Text="Excluir" OnClick="excluir" /><br /><br />
        <asp:Label ID="lblMensagem" runat="server" Text=""></asp:Label>
        </span>
    
    </div>
    </form>
</body>
</html>
