﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace pw11_correcao
{
    public partial class livro : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pwebt;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void inserir(object sender, EventArgs e)
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "insert into livro(titulo, autor, qtd, valor, paginas, resumo)" +
                "values('{0}','{1}',{2},{3},{4},'{5}')";
            sql = String.Format(sql, txtTitulo.Text, txtAutor.Text, txtQtd.Text,
                txtValor.Text, txtPagina.Text, txtResumo.Text);
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.ExecuteNonQuery();
            conexao.Close();
            lblMensagem.Text = "Livro Cadastrado com sucesso !";
            limpar();
        }

        protected void pesquisar(object sender, EventArgs e)
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from livro where codigo=" + txtCodigo.Text;
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            MySqlDataReader registro = comando.ExecuteReader();
            if (registro.Read())
            {
                txtAutor.Text = registro["autor"].ToString();
                txtPagina.Text = registro["paginas"].ToString();
                txtQtd.Text = registro["qtd"].ToString();
                txtResumo.Text = registro["resumo"].ToString();
                txtTitulo.Text = registro["titulo"].ToString();
                txtValor.Text = registro["valor"].ToString();
                lblMensagem.Text = "";
            }
            else
            {
                lblMensagem.Text = "Livro não existe !";
                limpar();
            }
            conexao.Close();
        }
        protected void alterar(object sender, EventArgs e)
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "update livro set titulo='{0}', autor='{1}', qtd={2}, valor={3}, " +
                "paginas={4}, resumo='{5}' where codigo={6}";                
            sql = String.Format(sql, txtTitulo.Text, txtAutor.Text, txtQtd.Text,
                txtValor.Text, txtPagina.Text, txtResumo.Text, txtCodigo.Text);
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.ExecuteNonQuery();
            conexao.Close();
            lblMensagem.Text = "Livro alterado com sucesso !";
            limpar();
        }

        protected void excluir(object sender, EventArgs e)
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "delete from livro where codigo="+ txtCodigo.Text;            
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.ExecuteNonQuery();
            conexao.Close();
            lblMensagem.Text = "Livro removido com sucesso !";
            limpar();
        }

        private void limpar(){
             txtAutor.Text = "";
             txtPagina.Text = "";
             txtQtd.Text = "";
             txtResumo.Text = "";
             txtTitulo.Text = "";
             txtValor.Text = "";
        }
    }
}