dim filesys 
Set filesys = CreateObject("Scripting.FileSystemObject") 
If filesys.FileExists("p:\temp\teste2.txt") Then 
	filesys.DeleteFile "p:\temp\teste2.txt" 
	msgbox("File deleted") 
end if	

If filesys.FolderExists("p:\temp\testePmi2") Then 
	filesys.DeleteFolder "p:\temp\testePmi2" 
	msgbox("Folder deleted") 
end if	
