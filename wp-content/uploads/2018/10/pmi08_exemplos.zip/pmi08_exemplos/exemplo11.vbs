Dim oFSO
Set oFSO = CreateObject("Scripting.FileSystemObject")
oFSO.CopyFile "p:\temp\somefile.txt", "p:\temp\teste2.txt"
msgbox("arquivo copiado")