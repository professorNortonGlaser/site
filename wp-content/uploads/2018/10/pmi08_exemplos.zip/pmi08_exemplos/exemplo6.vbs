dim strComputerName

set obj2 = Wscript.CreateObject("Wscript.Network")
strComputerName = obj2.ComputerName
msgbox(strComputerName)
