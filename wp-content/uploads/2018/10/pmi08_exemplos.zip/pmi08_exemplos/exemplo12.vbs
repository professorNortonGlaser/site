Set oFs = CreateObject("Scripting.FileSystemObject") 
Set file = oFs.OpenTextFile ("p:\temp\somefile.txt", 1)
Do Until file.AtEndOfStream
  line = line + file.Readline  + vbCrlf
Loop
msgbox(line)
file.Close
