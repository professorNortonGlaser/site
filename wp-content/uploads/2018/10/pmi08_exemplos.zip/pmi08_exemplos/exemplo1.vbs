Set objShell = CreateObject("Shell.Application")
objShell.ShellExecute "calc.exe"
