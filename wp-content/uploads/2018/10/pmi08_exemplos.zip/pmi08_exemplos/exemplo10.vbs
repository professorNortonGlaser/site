dim oFs, filetxt 
Const ForReading = 1, ForWriting = 2, ForAppending = 8 
Set oFs = CreateObject("Scripting.FileSystemObject") 
Set objNet = WScript.CreateObject("WScript.Network")

fileName = objNet.ComputerName & ".txt"

'verificar se o diretorio existe
if not oFs.folderExists("p:\temp\") then
	'criar um novo diretorio
	oFs.CreateFolder("p:\temp\")
	msgbox("diretorio criado")
end if
'abrir um novo arquivo se o arquivo nao existir ele cria
Set filetxt = oFs.OpenTextFile("p:\temp\"& fileName, ForAppending, True) 
filetxt.WriteLine(now() &" - teste de appending") 
filetxt.Close 
msgbox("arquivo atualizado")
