Dim Text, Title
Dim objNet         ' Object variable

Text = "Networking information" & vbCrLf & vbCrLf
Set objNet = WScript.CreateObject("WScript.Network")

Text = Text & "Computer name : " & objNet.ComputerName & vbCrLf
Text = Text & "Domain : " & objNet.UserDomain & vbCrLf
Text = Text & "User name : " & objNet.UserName & vbCrLf
MsgBox Text, vbOKOnly + vbInformation
