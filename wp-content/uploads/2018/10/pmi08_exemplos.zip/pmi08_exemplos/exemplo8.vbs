Set obj = WScript.CreateObject("WScript.Network")
obj.MapNetworkDrive "P:", "\\l3mp\Users\professor\Prova"

