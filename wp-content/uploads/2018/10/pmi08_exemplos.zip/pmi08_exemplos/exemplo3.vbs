Dim obj
Set obj = WScript.CreateObject ("WScript.shell")
obj.run "cmd /K CD C:\ & Dir"
Set obj = Nothing
