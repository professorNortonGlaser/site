Set obj = WScript.CreateObject("WScript.Network")
Set oPrinters = obj.EnumPrinterConnections

For i = 0 to oPrinters.Count - 1 Step 2
   msgbox("Port " & oPrinters.Item(i) & " = " & oPrinters.Item(i+1))
Next

'https://blogs.technet.microsoft.com/notesfromthefield/2008/02/26/wscript-network/