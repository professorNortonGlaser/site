Dim obj,oExec
Set obj = wscript.createobject("wscript.shell")
Set oExec = obj.Exec("C:\Program Files\Microsoft Office\Office16\excel.exe")
msgbox(oExec.Status)
msgbox(oExec.ProcessID)
msgbox(oExec.ExitCode) 