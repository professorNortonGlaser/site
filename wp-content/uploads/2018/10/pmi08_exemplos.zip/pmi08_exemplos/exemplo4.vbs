set obj = wscript.createobject("Wscript.shell")
obj.run "notepad",1
wscript.sleep 1000
obj.SendKeys "Aula de PMI" 'escreve technet
wscript.sleep 500
obj.sendkeys "{BACKSPACE}" 'ops! escrevi errado, volta
obj.SendKeys "t" 'e corrige
obj.SendKeys "%s" 'Agora ctrl+s para visualizar o menu ajuda
