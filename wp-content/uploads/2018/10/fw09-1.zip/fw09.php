﻿<!-- 
Path Fisico c:\xampp\htdocs  criação do arquivos
Path Virtual http://localhost/ testar 
-->
<html>
<body>
<h1>Assunto: FWJ09</h1>
<form method="post" action="fw09.php">
Numero:<input type="text" id="n1" name="num"/>
<br/>
<input type="submit" value="Tabuada" name="b1" />
<input type="submit" value="Fatorial" name="b2" />
</form>
<a href="fw09.php?a=56&b=52">Calculo Media</a>
<table border="1">
<?php 
//isset => identifica se variavel tem valor
if(isset($_POST["b1"])) {
	tabuada();
}
if(isset($_POST["b2"])) {
	fatorial();
}
if(isset($_GET["a"])){
	$m = ($_GET["a"]+$_GET["b"])/2;
	echo "<tr><td>Media=$m</td></tr>";
}
?>
</table>
</body>
</html>
<?php
function tabuada(){
	$c = 1;
	$n = $_POST["num"];
	while($c <=10)
	{
		$p = $c * $n;
		echo "<tr><td>$n</td><td>$c</td><td>$p</td></tr>";
		$c = $c + 1;
	}
}	

function fatorial(){
	$c = 1;
	$n = $_POST["num"];
	$f = 1;
	while($c <= $n)
	{
		$f = $c * $f;
		echo "<tr><td>$c</td><td>$f</td></tr>";
		$c = $c + 1;
	}
}	

?>
<!--
POST => Utiliza um formulario para trocar dados
entre a pagina local e o Webserver

GET => link para enviar parametros atraves de uma URL
-->

