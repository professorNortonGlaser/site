on error resume next 
dim nomeComputador, nomeUsuario, nomeDominio,nomeArquivo
Const ForReading = 1, ForWriting = 2, ForAppending = 8 

set objNet = Wscript.CreateObject("Wscript.Network")
objNet.MapNetworkDrive "P:", "\\l3mp\Users\professor\Prova"
nomeComputador = objNet.ComputerName
nomeUsuario	   = objNet.UserName
nomeDominio    = objNet.UserDomain 
nomeArquivo	   = "p:\"& objNet.ComputerName & ".txt"

Set oFs = CreateObject("Scripting.FileSystemObject")
Set file = oFs.OpenTextFile(nomeArquivo, ForAppending, True) 
file.WriteLine(now() &" - "& nomeUsuario &", "& nomeDominio) 
file.Close 

msgbox("Arquivo foi salvo")

