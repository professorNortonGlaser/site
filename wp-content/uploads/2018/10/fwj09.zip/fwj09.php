<html>
<body>
<form method="post" action="fwj09.php">
N1:<input type="text" name="n1" /><br/>
N2:<input type="text" name="n2" /><br/>
<input type="submit" value="+" name="b1" />
<input type="submit" value="-" name="b2" />
<input type="submit" value="*" name="b3" />
<input type="submit" value="/" name="b4" />
<input type="submit" value="T" name="b5" />
</form>
<?php
	if(isset($_POST["b1"])) somar();
	if(isset($_POST["b2"])) subtrair();
	if(isset($_POST["b3"])) multiplicar();
	if(isset($_POST["b4"])) dividir();
	if(isset($_POST["b5"])) tabuada();
?>
</body></html>
<?php
function somar(){
	$a = $_POST["n1"];
	$b = $_POST["n2"];
	$r = $a + $b;
	echo "$a + $b = $r";
}	
function subtrair(){
	$a = $_POST["n1"];
	$b = $_POST["n2"];
	$r = $a - $b;
	echo "$a - $b = $r";
}	
function multiplicar(){
	$a = $_POST["n1"];
	$b = $_POST["n2"];
	$r = $a * $b;
	echo "$a x $b = $r";
}	
function dividir(){
	$a = $_POST["n1"];
	$b = $_POST["n2"];
	$r = $a / $b;
	echo "$a / $b = $r";
}	
function tabuada(){
	$a = $_POST["n1"];
	for($n=1;$n<=10;$n++){ 
		$r = $a * $n;
		echo "$a x $n = $r<br>";
	}
}	
?>	
 