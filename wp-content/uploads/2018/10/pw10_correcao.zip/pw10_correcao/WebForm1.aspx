﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw10_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <br />
        <ul style="box-sizing: border-box; -webkit-tap-highlight-color: transparent; margin-top: 0px; margin-bottom: 30px; font-size: 18px; line-height: 1.618; color: rgb(60, 72, 88); font-family: Roboto, Helvetica, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 300; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;">
            <li style="box-sizing: border-box; -webkit-tap-highlight-color: transparent;">Data de Inscrição
                 <asp:TextBox ID="txtData" runat="server"></asp:TextBox>
                <asp:RangeValidator ID="RangeValidator1" runat="server" ControlToValidate="txtData" ErrorMessage="– Período de 01/07/2017 ate 31/12/2017" MaximumValue="31/12/2017" MinimumValue="01/07/2017" Type="Date"></asp:RangeValidator>
            </li>
            <li style="box-sizing: border-box; -webkit-tap-highlight-color: transparent;">Email
                <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
                <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" ControlToValidate="txtEmail" ErrorMessage="– validação de e-mail valido" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
            </li>
            <li style="box-sizing: border-box; -webkit-tap-highlight-color: transparent;">Senha
                <asp:TextBox ID="txtSenha" runat="server"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtSenha" ErrorMessage="– campo obrigatório"></asp:RequiredFieldValidator>
            </li>
            <li style="box-sizing: border-box; -webkit-tap-highlight-color: transparent;">Confirmação de senha&nbsp;<asp:TextBox ID="txtConfirma" runat="server"></asp:TextBox>
                <asp:CompareValidator ID="CompareValidator1" runat="server" ControlToCompare="txtSenha" ControlToValidate="txtConfirma" ErrorMessage="– verificar se esta igual ao campo&nbsp;senha"></asp:CompareValidator>
            </li>
            <li style="box-sizing: border-box; -webkit-tap-highlight-color: transparent;">cep&nbsp;<asp:TextBox ID="txtCep" runat="server"></asp:TextBox>
                &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator2" runat="server" ControlToValidate="txtCep" ErrorMessage="– código numérico de 8 dígitos" ValidationExpression="\d{5}(-\d{3})?"></asp:RegularExpressionValidator>
            </li>
            <li style="box-sizing: border-box; -webkit-tap-highlight-color: transparent;">Valor de compra&nbsp;
                <asp:TextBox ID="txtCompra" runat="server"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ControlToValidate="txtCompra" ErrorMessage="Informe um valor de compra"></asp:RequiredFieldValidator>
            </li>
            <li style="box-sizing: border-box; -webkit-tap-highlight-color: transparent;">Valor de Venda
                <asp:TextBox ID="txtVenda" runat="server"></asp:TextBox>
                <asp:CompareValidator ID="CompareValidator2" runat="server" ControlToCompare="txtCompra" ControlToValidate="txtVenda" ErrorMessage="– Valor de Venda não pode ser menor que valor de compra" Operator="GreaterThanEqual" Type="Double"></asp:CompareValidator>
            </li>
        </ul>
        <p style="box-sizing: border-box; -webkit-tap-highlight-color: transparent; margin: 0px 0px 15px; font-size: 18px; line-height: 1.618; color: rgb(60, 72, 88); font-family: Roboto, Helvetica, Arial, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 300; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;">
            <asp:Button ID="Button1" runat="server" Text="Button" />
        </p>
        <br />
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
