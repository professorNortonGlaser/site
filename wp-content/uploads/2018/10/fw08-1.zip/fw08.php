﻿<!-- 
Path Fisico c:\xamp\htdocs  criação do arquivos
Path Virtual http://localhost/ testar 
-->
<html>
<body>
<h1>Assunto: FWJ08</h1>
<p>
Faça um laço em php que imprima uma tabela de 10 linhas que simule a tabuada de um numero informado e imprima em  3 colunas
Coluna A = Indice
Coluna B = valor lido
Coluna C = Indice * valor lido
</p>
<table border="1">
<?php 
$c = 1;
$n = 8;
while($c <=10)
{
	$p = $c * $n;
	echo "<tr><td>$n</td><td>$c</td><td>$p</td></tr>";
	$c = $c + 1;
}
?>
</table>
</body>
</html>