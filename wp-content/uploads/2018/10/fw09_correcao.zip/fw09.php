﻿<!--
assunto: fwj09

Utitlizando o exemplo dado em aula, crie um formulário em PHP

deverá contar com duas caixas de texto n1 e n2
deverá contar com 5 botões (somar, multiplicar, subtrair, dividir,taboada)
coletar os dados do formulário
realizar a operação matemática especifica
-->
<html>
<body>
<form method="post" action="fw09.php">
N1:<input type="text" id="n1" name="n1" /><br/>	
N2:<input type="text" id="n2" name="n2" /><br/>
<input type="submit" name="b1" value="+" />
<input type="submit" name="b2" value="-" />
<input type="submit" name="b3" value="*" />
<input type="submit" name="b4" value="/" />
<input type="submit" name="b5" value="T" />
</form>
<?php
	if(isset($_POST["b1"])) somar(); 
	if(isset($_POST["b2"])) subtrair();
	if(isset($_POST["b3"])) multiplicar();
	if(isset($_POST["b4"])) dividir();
	if(isset($_POST["b5"])) tabuada();
?>
</body>
</html>
<?php
function somar(){
	$a 	= $_POST["n1"];
	$b	= $_POST["n2"];
	$r  = $a + $b;
	echo "O Resultado da soma=<b>$r</b>";	
}
function subtrair(){
	$a 	= $_POST["n1"];
	$b	= $_POST["n2"];
	$r  = $a - $b;
	echo "O Resultado da subtação=<b>$r</b>";	
}
function multiplicar(){
	$a 	= $_POST["n1"];
	$b	= $_POST["n2"];
	$r  = $a * $b;
	echo "O Resultado da multiplicação=<b>$r</b>";	
}
function dividir(){
	$a 	= $_POST["n1"];
	$b	= $_POST["n2"];
	$r  = $a / $b;
	echo "O Resultado da divisão=<b>$r</b>";	
}
function tabuada(){
	$a 	= $_POST["n1"];
	for($x=1; $x <= 10; $x++){
		$r  = $a * $x;
		echo "$a X $x = <b>$r</b></br>";
	}	
}
?>

