<html>
<body>
<h1>Teste 1 PHP</h1>
<?php 
$a = 7;
$b = 6.78;
$nome = "maria";
$c = ($a + $b) /2;
echo "Ola $nome , sua media= $c";
if($c >= 6) //comentario padrao
{
	echo "<br><b>Aprovado</b>";
} else {
	echo "<br><b>Precisa Fazer a P3</b>";
}
echo "<table border='1'>";
$fat = 1;
$numero = 8;
$cont = 1;
while($cont <= $numero)
{
	$fat = $fat * $cont;
	echo "<tr><td>$cont</td><td>$fat</td></tr>";
	$cont = $cont + 1;
}
echo "</table>";
?>
</body>
</html>