#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int cont;
	float graos=1;
	for(cont=1;cont<64;cont++){
		graos = graos + (graos*2);	
	}
	printf("Total = %f \n", graos);
	float t = graos / (100000*1000);
	printf("Toneladas = %f \n", t);	
	
	return 0;
}
