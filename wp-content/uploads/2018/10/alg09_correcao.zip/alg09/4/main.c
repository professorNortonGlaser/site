#include <stdio.h>
#include <stdlib.h>

/* 
 fa�a um la�o �fa�a at� com 10 intera��es, 
 verifique quantas vezes n�meros m�ltiplos 
 de 2 e de 3 s�o informados
 */

int main(int argc, char *argv[]) {
	int numero, resto2, resto3, cont=0, x;
	for(x=0;x<10;x++){
		printf("Informe um numero:");
		scanf("%d",&numero);
		resto2 = numero %2;
		resto3 = numero %3;
		if(resto2==0 && resto3==0){
			printf("Multiplo de 2 e 3 =%d\n", numero);
			cont++;		
		}		
	}
	printf("Total=%d", cont);
	
	return 0;
}
