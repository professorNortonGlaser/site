#include <stdio.h>
#include <stdlib.h>
/* 
int i, a, b;
for(i=0; i<20; i++)
{
   scanf("%d",&a);
   scanf("%d",&b);
   r = a + b;
   printf("%d\n", r);
}
a- reescreva com o la�o enquanto fa�a (while)
b- reescreva com o la�o fa�a enquanto (do while)
*/
int main(int argc, char *argv[]) {
	int i, a, b,r;
	
	i=0;
	while(i<20){
		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("soma=%d\n", r);	
		i++; // i = i + 1
	}
	
	i = 0;
	do{
		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("soma=%d\n", r);	
		i++; // i = i + 1
	} while(i<20);
	
	return 0;
}
