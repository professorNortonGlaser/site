﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw09_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void somar(object sender, EventArgs e)
        {
            try
            {
                double a, b, c;
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                c = a + b;
                Label1.Text = c.ToString();
            }
            catch (Exception err)
            {
                Label1.Text = "Digite somente numeros !"; 
            }
        }

        protected void subtrair(object sender, EventArgs e)
        {
            try
            {
                double a, b, c;
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                c = a - b;
                Label1.Text = c.ToString();
            }
            catch (Exception err)
            {
                Label1.Text = "Digite somente numeros !";
            }
        }


        protected void multiplicar(object sender, EventArgs e)
        {
            try
            {
                double a, b, c;
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                c = a * b;
                Label1.Text = c.ToString();
            }
            catch (Exception err)
            {
                Label1.Text = "Digite somente numeros !";
            }
        }

        protected void dividir(object sender, EventArgs e)
        {
            try
            {
                double a, b, c;
                a = Convert.ToDouble(TextBox1.Text);
                b = Convert.ToDouble(TextBox2.Text);
                c = a / b;
                Label1.Text = c.ToString();
            }
            catch (Exception err)
            {
                Label1.Text = "Digite somente numeros !";
            }
        }
    }
}