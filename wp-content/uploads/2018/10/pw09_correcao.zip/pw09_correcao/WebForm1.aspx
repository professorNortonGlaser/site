﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw09_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>    
        <h1>Calculadora</h1>        
        Numero 1:<asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
        <br /><br />
        Numero 2:<asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>
        <br /><br />
        <asp:Button ID="Button1" runat="server" Text="+" OnClick="somar" />
        <asp:Button ID="Button2" runat="server" Text="-" OnClick="subtrair" />
        <asp:Button ID="Button3" runat="server" Text="*" OnClick="multiplicar"  />
        <asp:Button ID="Button4" runat="server" Text="/" OnClick="dividir" />
        <br /><br />
        <asp:Label ID="Label1" runat="server" Text=""></asp:Label>
        <br /><br />    
    </div>
    </form>
</body>
</html>
