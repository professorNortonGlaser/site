'3-Crie um arquivo VBSCRIPT que leia um valor, calcule o fatorial do mesmo usando um comando de laço

dim numero, contador, resultado

numero = inputbox("Informe o numero:")
numero = cdbl(numero)

resultado = 1

for contador = 1 to numero
	resultado = resultado * contador
next

msgbox("O fatorial de "& numero &" = "& resultado)
