rem Crie um Batch File que grave em um arquivo maquina.txt as configuração da maquina, configurações de rede e a arvore de diretorios

del maquina.txt
systeminfo >> maquina.txt
ipconfig >> maquina.txt
tree C:\Users\professor\Desktop >> maquina.txt
