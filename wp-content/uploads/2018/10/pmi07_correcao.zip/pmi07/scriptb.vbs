dim a, b, c

a = inputbox("Informe um valor para A")
b = inputbox("Informe um valor para b")
c = (cdbl(a) + cdbl(b))/2
msgbox("A media ="& c)


