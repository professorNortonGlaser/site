import math

def multiplica(x, y):
    r = x * y
    return r

def qualSeuNome(p):
    print("Seu nome =", p)
    
numero = float(input("Informe um numero:"))
print("fatorial=", math.factorial(8))
print("trunc=", math.trunc(5.5436))
print("arredondar=", math.floor(6.3223))
print("PI=", math.pi)
print("Raiz quadrada=", math.sqrt(numero))
print("Potencia=", math.pow(6, 3))

#lista de funçoes de string

s = "lista de funçoes de string"
print(s)
print("Conta a qtd de caracteres:", len(s))
print("Pegar a 3 letra:", s[3])
print("Pegar um substring:", s[0:5])
lista = s.split(" ")
print(lista)
s = s.replace("lista", "Conjunto")
print(s)
print(s.upper())
print(s.lower())
print(s.capitalize())
print(s.title())

t = "Aulas de python"
print(t.ljust(50))
print(t.center(50))
print(t.rjust(50))

print(t.ljust(50,"*"))
print(t.center(50,"="))
print(t.rjust(50,"_"))

#import biblioteca de data
from datetime import date
from datetime import datetime

data = date.today()
print(data)

data2 =  datetime.now()
print(data2)
print(multiplica(34,65))
print(multiplica(44,15))
print(qualSeuNome("Maria"))




      



