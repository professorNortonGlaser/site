#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float a, b, r;
	int op;
	
	printf("Informe um valor para a:");
	scanf("%f", &a);
	
	printf("Informe um valor para b:");
	scanf("%f", &b);
	
	printf("1-somar, 2-subtrair, 3- multiplicar, 4-dividir, 5-resto :");
	scanf("%d", &op);
	
	//Switch somente aceita int ou caracter
	switch(op){
		case 1 :{
			r = a + b;
			break;
		}
		case 2:{
			r = a - b;
			break;
		}
		case 3:{
			r = a *b;
			break;
		}
		case 4:{
			r = a / b;
			break;
		}
		case 5:{
			r = (int)a % (int)b;
			break;
		}
		default :{
			printf("Escolha ERRADA !!!!");
		}
	}
	printf("Resultado = %f", r);
	return 0;
}
