#include <stdio.h>
#include <stdlib.h>

/* Fa�a um algoritmo que implemente um la�o que leia X n�meros
 inteiros e identifique qual o menor o maior e a media, quando o
  n�mero informado for zero, interrompa o la�o e exiba os valores. */

int main(int argc, char *argv[]) {
	int numero=-1;
	int menor=0;
	int maior=0;
	int cont=0;
	float media=0;
	
	while(numero != 0){
		printf("Informe um numero:");
		scanf("%d", &numero);
		
		if(numero !=0){
			cont = cont + 1;
			media = media + numero;
					
			if(numero>maior || cont==1){
				maior = numero;		
			}
			
			if(numero<menor || cont==1){
				menor = numero;	
			}				
		}								
	}
	media = media / cont;
	printf("Menor=%d , Maior=%d , Media=%f", menor, maior, media);
	
	
	return 0;
}
