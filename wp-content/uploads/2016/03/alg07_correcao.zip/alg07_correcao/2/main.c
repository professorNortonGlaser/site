#include <stdio.h>
#include <stdlib.h>

/* Reutilizando o algoritmo do caixa eletr�nico, 
implemente um la�o fa�a enquanto que verifique se o usu�rio deseja continuar, 
caso a vari�vel coletada for igual 1 reinicie o la�o, mantendo o valor do saldo. */

int main(int argc, char *argv[]) {
	int op;
	float saldo = 500;
	float valor;
	int continua;

do{
	printf("Escolha: 1-Saldo 2-saque 3-Deposito :");
	scanf("%d", &op);	
	switch(op){
		case 1: {
			printf("o saldo = %f", saldo);
			break;		}	
		case 2:{
			printf("Qual o valor do saque: ");
			scanf("%f", &valor);
			if(valor <= saldo){
				saldo = saldo -valor;
				printf("Saque realizado %f", valor);	
			} else {
				printf("Saldo insuficiente!");
			}
			break;		}
		case 3:{
			printf("Qual o valor do deposito: ");
			scanf("%f", &valor);
			saldo = saldo + valor;
			printf("Deposito efetuado %f", valor);
			break;		}
		default:{
			printf("Opcao invalida!!!");		}
	}
	printf("\nDeseja Continua 1-sim 0-nao");
	scanf("%d",&continua);	
} while(continua==1);


	return 0;
}
