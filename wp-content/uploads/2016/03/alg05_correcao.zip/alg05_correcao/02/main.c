#include <stdio.h>
#include <stdlib.h>

/* Informe dois n�meros reais e um n�mero inteiro que represente a 
opera��o matem�tica a ser realizada (1-soma, 2-subtra��o, 
3- multiplica��o, 4-divis�o, 5-resto) utilize o comando sele��o
 aninhado e exiba o resultado da opera��o matem�tica escolhida. */

int main(int argc, char *argv[]) {
	float a, b, r;
	int op;
	
	printf("Informe um valor para a:");
	scanf("%f", &a);
	
	printf("Informe um valor para b:");
	scanf("%f", &b);
	
	printf("1-soma, 2-subtrair, 3- multiplicar, 4-dividir, 5-resto :");
	scanf("%d", &op);
	
	if(op==1){
		r = a + b;			
	} else {
		if(op==2){
			r = a - b;	
		} 
		else 
		{
			if(op==3){
				r = a * b;	
			} else {
				if(op==4){
					r= a / b;	
				} else {
					r = (int)a % (int)b;
				}	
			}	
		}			
	}
	printf("O resultado = %f", r);
	
	
	
	
	return 0;
}
