#include <stdio.h>
#include <stdlib.h>

/* Crie um  algoritmo que informe dois valores 
reais, valor em reais do litro da gasolina e 
valor em reais do litro do �lcool,  calcule os 
70% do valor da gasolina para definir na tela qual
combust�vel e o mais vantajoso, sabendo que o valor
do �lcool para ser mais vantajoso deve ser 
menor que 70% do valor da gasolina. */

int main(int argc, char *argv[]) {
	float alcool, gasolina, percentual;
	printf("Informe o valor do alcool: ");
	scanf("%f", &alcool);
	printf("Informe o valor da gasolina: ");
	scanf("%f", &gasolina);
	
	percentual = gasolina * 0.7;
	if(alcool <= percentual)
	{
		printf("Alcool e mais vantajoso");	
	} 
	else 
	{
		printf("Gasolina e mais vantajosa");	
	}
	
	
	return 0;
}
