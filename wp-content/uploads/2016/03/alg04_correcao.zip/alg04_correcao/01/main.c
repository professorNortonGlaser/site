#include <stdio.h>
#include <stdlib.h>

/*
1- Fa�a um algoritmo que receba um n�mero 
inteiro, identifique se este e par ou impar, 
utilize o modulo de 2 para calcular o resto da 
divis�o, se o resto da divis�o for zero 
(o n�mero e par) caso o resto da divis�o for
 1 (o n�mero e impar)

Exemplo:
int numero = 5;
resto = numero % 2;
resto = 1  // impar
int numero2 = 6;
resto = numero % 2;
resto = 0  // par
*/

int main(int argc, char *argv[]) {
	int numero;
	int resto;
	
	printf("Digite um numero: ");
	scanf("%d", &numero);
	// Modulo ( % ) Resto da divisao inteira
	resto = numero % 2;
	if(resto == 1)
	{
		printf("O numero %d e impar !", numero);	
	} 
	else 
	{
		printf("O numero %d e par !", numero);
	}
	
	return 0;
}
