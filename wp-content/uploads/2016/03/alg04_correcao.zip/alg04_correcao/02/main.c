#include <stdio.h>
#include <stdlib.h>

/* fa�a um algoritmo em c que receba dois 
 n�meros, verifique qual o maior e qual o menor */

int main(int argc, char *argv[]) {
	float n1, n2;
	printf("informe um valor para n1:");
	scanf("%f", &n1);
	printf("informe um valor para n2:");
	scanf("%f", &n2);
	
	if(n1>n2)
	{
		printf("N1 e maior que N2 !");	
	}
	else 
	{
		printf("N2 e maior ou igual a N1 !");
	}
	
	return 0;
}
