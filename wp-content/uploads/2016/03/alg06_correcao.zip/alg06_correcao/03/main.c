#include <stdio.h>
#include <stdlib.h>

/* Desenvolva um programa em C que:
� Leia 4 (quatro) n�meros;
� Calcule o quadrado de cada um;
� Se o valor resultante do quadrado do terceiro for >= 1000, imprima-o e finalize;
� Caso contr�rio, imprima os valores lidos e seus respectivos quadrados
 */

int main(int argc, char *argv[]) {
	float a,b,c,d, qa, qb, qc, qd;
	
	printf("Informe um valor para a:");
	scanf("%f", &a);
	
	printf("Informe um valor para b:");
	scanf("%f", &b);
		
	printf("Informe um valor para c:");
	scanf("%f", &c);
	
	printf("Informe um valor para d:");
	scanf("%f", &d);
	
	qa = a*a;
	qb = b*b;
	qc = c*c;
	qd = d*d;
	
	if(qc >= 1000) {
		printf("qc = %f", qc);	
	} 
	else {
		printf("a = %f e qa= %f \n", a, qa);
		printf("b = %f e qb= %f \n", b, qb);
		printf("c = %f e qc= %f \n", c, qc);
		printf("d = %f e qd= %f \n", d, qd);
	}
	
	
	
	
	return 0;
}
