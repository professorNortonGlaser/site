#include <stdio.h>
#include <stdlib.h>

/* 1) Jo�o, comprou um microcomputador para controlar o rendimento di�rio de seu trabalho. 
Toda vez que ele traz um peso de peixes maior que o estabelecido pelo regulamento de pesca 
do estado de S�o Paulo (50 quilos) deve pagar um multa de R$ 4,00 por quilo excedente. 
Jo�o precisa que voc� fa�a um programa em C  que leia a vari�vel P (peso de peixes) e 
verifique se h� excesso. Se houver, gravar na vari�vel E (Excesso) e na vari�vel M o valor
 da multa que Jo�o dever� pagar. Caso contr�rio mostrar tais vari�veis com o conte�do ZERO. 
 */

int main(int argc, char *argv[]) {
	float p, e, m;
	
	printf("Informe o peso :");
	scanf("%f", &p);
	
	if(p>50){
		e = p - 50;
		m = e * 4;
	} 
	else {
		e = 0;
		m = 0;	
	}
	printf("peso=%f , excedente=%f, multa=%f", p, e, m);
		
	return 0;
}
