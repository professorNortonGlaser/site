#include <stdio.h>
#include <stdlib.h>

/* fa�a um algoritmo que simule o funcionamento de um caixa eletr�nico, 
onde ser� apresentado uma lista de opera��es:

1-Saldo
 2-Saque
 3-Deposito
 Ao iniciar o programa determine um valor inicio para a vari�vel saldo, 
 se o cliente escolher a op��o 1 mostre o valor do saldo,
  caso escolha o valor 2 leia o valor a ser sacado e verifique se existe saldo suficiente,
   se o saldo for maior ou igual , deduza da vari�vel saldo o valor solicitado, 
   caso n�o haja saldo suficiente mostre a mensagem �Saldo Insuficiente�,
    caso a op��o 3 seja escolhida adicione o valor informado de deposito ao saldo.

*/

int main(int argc, char *argv[]) {
	int op;
	float saldo = 500;
	float valor;
	
	printf("Escolha: 1-Saldo 2-saque 3-Deposito :");
	scanf("%d", &op);
	
	switch(op){
		case 1: {
			printf("o saldo = %f", saldo);
			break;
		}	
		case 2:{
			printf("Qual o valor do saque: ");
			scanf("%f", &valor);
			if(valor <= saldo){
				saldo = saldo -valor;
				printf("Saque realizado %f", valor);	
			} else {
				printf("Saldo insuficiente!");
			}
			break;
		}
		case 3:{
			printf("Qual o valor do deposito: ");
			scanf("%f", &valor);
			saldo = saldo + valor;
			printf("Deposito efetuado %f", valor);
			break;
		}
		default:{
			printf("Opcao invalida!!!");
		}
	}
	
	
	return 0;
}
