#include <stdio.h>
#include <stdlib.h>

/* Elabore um programa em C que leia as vari�veis  N 
n�mero de horas trabalhadas de um oper�rio. E calcule o sal�rio 
sabendo-se que ele ganha R$ 10,00 por hora. Quando o n�mero de horas exceder 
a 50 calcule o excesso de pagamento armazenando-o na vari�vel E, caso contr�rio zerar
 tal vari�vel. A hora excedente de trabalho vale R$ 20,00. No final do processamento 
 imprimir o sal�rio total e o sal�rio excedente. */

int main(int argc, char *argv[]) {
	float horas, e, salarioT, salarioE;
	
	printf("Informe a qtd de horas trabalhadas: ");
	scanf("%f", &horas);
	
	if(horas>50){
		e = horas - 50;
		salarioE = 	e * 20;
		salarioT = (50 * 10) + salarioE;		
	} else {
		e = 0;
		salarioE = 0;
		salarioT = horas * 10;			
	}
	printf("Salario Total %f e Salario Excedente=%f", salarioT, salarioE);
		
	return 0;
}
