#include <stdio.h>
#include <stdlib.h>

/* Elabore um algoritmo que dada a idade de um nadador 
classifique-o em uma das seguintes categorias:
� Infantil A = 5 a 7 anos
� Infantil B = 8 a 11 anos
� Juvenil A = 12 a 13 anos
� Juvenil B = 14 a 17 anos
� Adultos = Maiores de 18 anos
 */

int main(int argc, char *argv[]) {
	int idade;
	printf("Informe a idade :");
	scanf("%d", &idade);
	
	if(idade>=5 && idade<=7){
		printf("Infantil A %d", idade);	
	} 
	else {
		if(idade>=8 && idade <=11){
			printf("Infantil B %d", idade);	
		} 
		else {
			if(idade>=12 && idade<=13){
				printf("juvenil A %d", idade);		
			} 
			else {
				if(idade>=14 && idade<=17){
					printf("juvenil B %d", idade);	
				} else {
					if(idade >=18){
						printf("Adulto %d", idade);		
					} else {
						printf("N�o pode competir %d", idade);		
					}
				}	
			}			
		}		
	}


	return 0;
}
