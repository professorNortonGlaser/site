﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw09_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <br />
        <strong>CALCULADORA</strong><br />
        <br />
        N1:<asp:TextBox ID="txtN1" runat="server"></asp:TextBox>
        <br />
        <br />
        N2:<asp:TextBox ID="txtN2" runat="server"></asp:TextBox>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="somar" Text="Somar" />
        <asp:Button ID="Button2" runat="server" OnClick="subtrair" Text="Subtrair" />
        <asp:Button ID="Button3" runat="server" OnClick="multiplicar" Text="Multiplicar" />
        <asp:Button ID="Button4" runat="server" OnClick="dividir" Text="Dividir" />
        <br />
        <br />
        <br />
        <asp:Label ID="lblMensagem" runat="server"></asp:Label>
        <br />
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
