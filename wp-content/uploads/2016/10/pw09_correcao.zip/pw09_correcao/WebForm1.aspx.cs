﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw09_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void somar(object sender, EventArgs e)
        {
            try
            {
                decimal a, b, r;
                a = Convert.ToDecimal(txtN1.Text);
                b = Convert.ToDecimal(txtN2.Text);
                r = a + b;
                lblMensagem.Text = r.ToString();
            }
            catch
            {
                lblMensagem.Text = "Digite somente numeros";
            }
        }

        protected void subtrair(object sender, EventArgs e)
        {
            try
            {
                decimal a, b, r;
                a = Convert.ToDecimal(txtN1.Text);
                b = Convert.ToDecimal(txtN2.Text);
                r = a - b;
                lblMensagem.Text = r.ToString();
            }
            catch
            {
                lblMensagem.Text = "Digite somente numeros";
            }
        }

        protected void multiplicar(object sender, EventArgs e)
        {
            try
            {
                decimal a, b, r;
                a = Convert.ToDecimal(txtN1.Text);
                b = Convert.ToDecimal(txtN2.Text);
                r = a * b;
                lblMensagem.Text = r.ToString();
            }
            catch
            {
                lblMensagem.Text = "Digite somente numeros";
            }
        }

        protected void dividir(object sender, EventArgs e)
        {
            try
            {
                decimal a, b, r;
                a = Convert.ToDecimal(txtN1.Text);
                b = Convert.ToDecimal(txtN2.Text);
                if (b == 0)
                {
                    lblMensagem.Text = "Divisão por zero";
                }
                else
                {
                    r = a / b;
                    lblMensagem.Text = r.ToString();
                }
            }
            catch
            {
                lblMensagem.Text = "Digite somente numeros";
            }            
        }
    }
}