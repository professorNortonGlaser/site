#include <stdio.h>
#include <stdlib.h>

/* Fa�a um algoritmo que dado valor inteiro informado,
 calcule e exiba a tabuada do numero de 1 a 10 */

int main(int argc, char *argv[]) {
	int numero;
	int cont;
	int produto;
	
	printf("Digite o numero da tabuada:");
	scanf("%d", &numero);	
	
	for(cont=1; cont<=10; cont++){
		produto = cont * numero;
		printf("%d x %d = %d \n", cont, numero, produto);			
	}
	
	
	return 0;
}
