#include <stdio.h>
#include <stdlib.h>

/*  Elabore um algoritmo que gere e escreva os n�meros �mpares 
dos n�meros entre 100 e 200. */

int main(int argc, char *argv[]) {
	//repeti�oes com numeros determinados fa�a ate
	int cont;
	int resto;
	
	for(cont=100; cont<=200; cont++){
		resto = cont % 2;
		if(resto==1){
			printf("%d \n", cont);
		}					
	}
	
	
	
	
	return 0;
}
