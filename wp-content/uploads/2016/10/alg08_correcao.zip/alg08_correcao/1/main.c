#include <stdio.h>
#include <stdlib.h>

/* A � Fa�a um algoritmo que implemente um la�o que leia X n�meros inteiros 
e identifique qual o menor o maior e a media, 
quando o n�mero informado for zero, interrompa o la�o e exiba os valores. */

int main(int argc, char *argv[]) {
	//fa�a enquanto 1 a n
	//enquanto fa�a e 0 a n
	
	int cont = 0;
	int num  = 0;
	int maior = 0;
	int menor = 0;
	float media = 0;
	
	do 
	{
		printf("Informe um numero:");
		scanf("%d", &num);		
		if(num != 0){
			//quando for a primeira itera��o do la�o
			if(cont==0){
				menor=num;
				maior=num;	
			} else {			
				//maior			
				if(num > maior){
					maior =num;	
				}	
				//menor
				if(num < menor){
					menor = num;	
				}
			}
			//media
			media = media + num;
			cont++;		
		}
		
	} while(num != 0);
	media = media/cont;
	printf("O maior = %d o menor = %d e a media=%f", maior,menor, media);
	
	
	return 0;
}
