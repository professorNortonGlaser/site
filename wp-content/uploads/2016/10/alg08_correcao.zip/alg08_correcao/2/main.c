#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int op;
	float saldo = 500;
	float valor = 0;
	int continua;
	
	//fa�a enquanto 1 a N
	do {
		
		printf("Informe a operacao: \n1-Saldo\n2-Saque\n3-Deposito \n");
		scanf("%d", &op);
		
		switch(op){
			case 1: {
				printf("O saldo = %f \n", saldo);
				break;
			}	
			case 2:{
				printf("Qual o valor a ser sacado:");
				scanf("%f", &valor);
				if(saldo >= valor){
					saldo = saldo - valor;
					printf("Saque de %f efetuado, saldo = %f\n", valor,saldo);	
				} else {
					printf("Saldo insuficiente\n");	
				}
				break;
			}
			case 3: {
				printf("Qual o valor a ser depositado:");
				scanf("%f", &valor);
				saldo = saldo + valor;
				printf("Deposito de %f efetuado, saldo = %f\n", valor,saldo);	
				break;
			}
			default : {
				printf("Operacao invalida !!!!\n");
			}
			
		}
	
		printf("Deseja executar uma nova operacao ? 1-Sim 0-Nao");
		scanf("%d", &continua);
	} while(continua ==1);
	
	return 0;
	return 0;
}
