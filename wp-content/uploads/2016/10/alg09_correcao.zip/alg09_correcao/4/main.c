#include <stdio.h>
#include <stdlib.h>

/* 
fa�a um la�o �fa�a at� com 10 intera��es, 
verifique quantas vezes n�meros m�ltiplos de 2 e de 3
 s�o informados
 */

int main(int argc, char *argv[]) {
	int x;
	int num;
	int restoDois, restoTres;
	int total=0;
	
	for(x=0;x<10;x++){
		printf("Informe um numero:");
		scanf("%d", &num);	
		
		restoDois = num % 2;
		restoTres = num % 3;
		if(restoDois==0 && restoTres==0){
			total++;	
		}				
	}
	printf("Total de multiplos de 2 e 3 : %d", total);
	
	return 0;
}
