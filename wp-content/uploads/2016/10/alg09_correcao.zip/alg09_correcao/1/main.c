#include <stdio.h>
#include <stdlib.h>

/* 
1- Dado o algoritmo abaixo escrito em C :
int i, a, b;
for(i=0; i<20; i++)
{
   scanf("&d",&a);
   scanf("&d",&b);
   r = a + b;
   printf("%d\n", r);
}
a- reescreva com o la�o enquanto fa�a (while)
b- reescreva com o la�o fa�a enquanto (do while)
 */

int main(int argc, char *argv[]) {		
	// 0 a N 
	int i, a , b, r;
	i = 0;
	while(i<20)
	{
	 	scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("%d\n", r);
		i++;
	}
	
	// 1 a N
	i = 0;
	do{
		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("%d\n", r);
		i++;	
	}while(i<20);		
	return 0;
}
