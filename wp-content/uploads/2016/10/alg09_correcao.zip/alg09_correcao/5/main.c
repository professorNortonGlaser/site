#include <stdio.h>
#include <stdlib.h>

/* Crie um la�o e verifique qual a maior sequencia de n�meros pares 
informados, o la�o fara 10 itera��es. */

int main(int argc, char *argv[]) {
	int cont, num;
	int restoDois;
	int maiorSeq = 0;
	int seq 	 = 0;
	
	for(cont=0; cont<10; cont ++){
		printf("Informe um numero: ");
		scanf("%d",&num);
		
		restoDois = num % 2;
		if(restoDois == 0){
			seq++;	
		} 
		else {
			if(seq > maiorSeq)
			{
				maiorSeq = seq;
			}	
			seq = 0;
		}				
	}
	printf("A maior Sequencia foi = %d \n", maiorSeq);
	
	
	
	return 0;
}
