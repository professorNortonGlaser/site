#include <stdio.h>
#include <stdlib.h>

/* rie um algoritmo onde ser� informado um valor inteiro inicial,  
e um la�o o usu�rio devera informar outro numero inteiro, o programa
 dever� responder se o numero atual e menor ou maior que o numero 
 inicial informado, o la�o somente ser� interrompido quando o numero 
 atual for igual ao n�mero anterior informado. Exiba quantas tentativas
  foram necess�rias para que o numero fosse descoberto. */

int main(int argc, char *argv[]) {
	int numero = 78;
	int chute;
	int tentativas=0;
	
	do{
		printf("Informe um numero:");
		scanf("%d",&chute);
		if(chute>numero)
		{
			printf("O numero e menor que %d \n", chute);		
		}
		if(chute<numero)
		{
			printf("O numero e maior que %d \n", chute);		
		}
		tentativas++;				
	}while(chute != numero);
	printf("Voce acertou, precisou de %d tentativas", tentativas);
	
	return 0;
}
