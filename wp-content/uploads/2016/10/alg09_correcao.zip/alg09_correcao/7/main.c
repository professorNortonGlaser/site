#include <stdio.h>
#include <stdlib.h>

/* Fa�a um algoritmo que conte de 1 a 100 e
 a cada m�ltiplo de 3 e 5 simultaneamente emita 
 uma mensagem:  �M�ltiplo de 3 e 5�. */

int main(int argc, char *argv[]) {
	int cont=1;
	int resto3, resto5;
	
	do{
		resto3 = cont %3;
		resto5 = cont %5;
		if(resto3==0 && resto5==0){
			printf("Numero %d, multiplo de 3 e 5 \n", cont);	
		}	
				
		cont++;	
	}while(cont <= 100);
	
	
	return 0;
}
