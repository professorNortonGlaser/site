#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um la�o que calcule a media de todos os n�meros informados, 
a condi��o de termino do la�o e quando for digitado ZERO
 */

int main(int argc, char *argv[]) {
	int cont=0;
	int acum=0;
	int num;
	
	// 1 a N
	do {
	  printf("Informe um numero: ");	
	  scanf("%d",&num);
	  if(num!=0){
	  	cont++;
		acum=acum + num;	
	  } 			
	} while(num != 0);
	float media = acum / cont;
	printf("Media = %f\n", media);	
	
	return 0;
}
