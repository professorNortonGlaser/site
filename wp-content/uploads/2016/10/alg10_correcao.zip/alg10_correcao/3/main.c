#include <stdio.h>
#include <stdlib.h>

/* c � fa�a um algoritmo que implemente um vetor de 20 posi��es,
 leia as 20 posi��es e identifique em um novo la�o,
  qual o maior e menor numero informado e 
  qual a media dos n�meros informados. */

int main(int argc, char *argv[]) {
	float numeros[20];
	int cont;
	float maior, menor, media;
	
	
	for(cont=0; cont<20; cont++){
		printf("informe um valor: ");
		scanf("%f", &numeros[cont]);			
	}
	for(cont=0; cont<20; cont++){	
		//se e a primeira itera��o, ja assume o valor com maior e menor
		if(cont==0)
		{
			maior = numeros[cont];	
			menor = numeros[cont];	
			media = numeros[cont];	
		} else {
			if(numeros[cont] > maior){
				maior = numeros[cont];			
			}	
			if(numeros[cont] < menor){
				menor = numeros[cont];			
			}	
			media = media + numeros[cont];						
		}
	}
	media = media / 20;
	printf("Maior = %f, menor=%f, media=%f \n",maior,menor,media);
	
	
	return 0;
}
