#include <stdio.h>
#include <stdlib.h>

/* 
a- Fa�a um algoritmo que armazene um vetor de inteiros de 20 posi��es,
identifique  o percentual de n�meros impares e de n�meros pares informados.
*/

int main(int argc, char *argv[]) {
	int numeros[20];
	int resto;
	float totalPar	 =	0;
	float totalImpar = 	0;
	int	cont;
	
	for(cont=0;cont<20;cont++){
		printf("Informe um numero:");
		scanf("%d", &numeros[cont]);
		resto = numeros[cont] % 2;
		if(resto==0){
			totalPar++;
			printf("numeros[%d] = %d => PAR \n", cont, numeros[cont]);	
		} else {
			printf("numeros[%d] = %d => IMPAR \n", cont, numeros[cont]);	
			totalImpar++;	
		}		
	}
	totalPar = (totalPar / 20) * 100;
	totalImpar = (totalImpar / 20) * 100;
	printf("Pares %f \n", totalPar);
	printf("Impares %f \n", totalImpar);
	
	
	return 0;
}
