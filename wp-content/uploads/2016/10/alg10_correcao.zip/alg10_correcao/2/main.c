#include <stdio.h>
#include <stdlib.h>

/* Crie dois vetores do tipo inteiro com a capacidade de 10 posi��es, 
leia n�meros que ser�o armazenados sequencialmente no primeiro vetor,
 fa�a um novo la�o que armazene no segundo vetor o valor 
 do primeiro multiplicado por 2 quando o �ndice for par, 
 e multiplique por 3 quando o �ndice for impar. */

int main(int argc, char *argv[]) {
	int vetA[10];
	int vetB[10];
	int resto;
	int cont;
	
	for(cont=0; cont <10; cont++){
		printf("Informe um numero :");
		scanf("%d", &vetA[cont]);
		resto = cont % 2; //verificando se o indice e par ou impar
		if(resto == 0){
			vetB[cont] = vetA[cont] * 2;	
		} else {
			vetB[cont] = vetA[cont] * 3;	
		}
	}
	for(cont=0;cont<10;cont++){
		printf("vetA[%d]=%d, vetB[%d]=%d \n", cont, vetA[cont], cont, vetB[cont]);				
	}
	
	
	
	return 0;
}
