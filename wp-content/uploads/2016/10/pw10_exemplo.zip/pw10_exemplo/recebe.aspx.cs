﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw10_exemplo
{
    public partial class recebe : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // isPostBack - True quando a pagina for reload
            if (!IsPostBack)
            {
                Label1.Text = Request["nome"];
                Label2.Text = Request["idade"];
                //Session e uma variavel global q e compartilhada
                //na sessão do usuario
                Session["nome"] = Label1.Text;
                Session["idade"] = Label2.Text;
                Response.Write(Session.SessionID);
            }

            //Application["mensagem"] = "manutenção hj as 18:00";
        }

        protected void redirecionar(object sender, EventArgs e)
        {
            Response.Redirect("final.aspx");
        }
    }
}