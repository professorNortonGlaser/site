﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="recebe.aspx.cs" Inherits="pw10_exemplo.recebe" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <strong>RECEBE.ASPX<br />
        </strong>
        <br />
        <br />
        <asp:Label ID="Label1" runat="server" Text="Label"></asp:Label>
        <br />
        <br />
        <asp:Label ID="Label2" runat="server" Text="Label"></asp:Label>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="redirecionar" Text="Button" />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
