create database pweb;

use pweb;

create table cliente(
codigo Integer 
NOT NULL PRIMARY KEY AUTO_INCREMENT,
nome varchar(100),
email varchar(100),
telefone varchar(20),
senha varchar(20)
);

create table livro(
codigo Integer 
NOT NULL PRIMARY KEY AUTO_INCREMENT,
titulo varchar(100),
autor varchar(100),
qtd  Integer ,
valor decimal(18,2),
paginas integer,
resumo text
);
