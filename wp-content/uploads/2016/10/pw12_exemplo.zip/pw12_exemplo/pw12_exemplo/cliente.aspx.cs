﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data; //adicionado
using MySql.Data.MySqlClient;

namespace pw12_exemplo
{
    public partial class cliente : System.Web.UI.Page
    {
        private String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Create(object sender, EventArgs e)
        {
            try  {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                String sql = "insert into client(nome, email, telefone, senha) " +
                                " values('{0}','{1}','{2}','{3}')";

                sql = String.Format(sql, txtNome.Text, txtEmail.Text, txtTelefone.Text,
                                txtSenha.Text);

                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery(); //executar o comando no banco de dados nao vai ter retorno
                conexao.Close();
                lblMensagem.Text = "Registro inserido com sucesso";
            }
            catch(Exception err) {
                lblMensagem.Text = "Ocorreu um erro verifique !!! "+ err.Message;
            } 

        }
    }
}