﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="cliente.aspx.cs" Inherits="pw12_exemplo.cliente" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <style type="text/css">
        .auto-style1 {
            font-size: x-large;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <strong><span class="auto-style1">Cliente </span></strong>
        <br />
        <br />
        codigo:<asp:TextBox ID="txtCodigo" runat="server"></asp:TextBox>
        <asp:Button ID="Button2" runat="server" Text="READ" /><br /><br />
        nome:<asp:TextBox ID="txtNome" runat="server"></asp:TextBox><br /><br />
        email:<asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>        <br />        <br />
        telefone:<asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox>       <br />        <br />
        senha:<asp:TextBox ID="txtSenha" runat="server" TextMode="Password"></asp:TextBox>        <br />       <br />
        <asp:Button ID="Button1" runat="server" Text="CREATE" OnClick="Create" />
        <asp:Button ID="Button3" runat="server" Text="UPDATE" />
        <asp:Button ID="Button4" runat="server" Text="DELETE" />   <br /><br />
        <asp:Label ID="lblMensagem" runat="server"></asp:Label>
        <br />
        <br />
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
