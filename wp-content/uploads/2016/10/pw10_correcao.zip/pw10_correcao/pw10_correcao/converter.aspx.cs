﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw10_correcao
{
    public partial class converter : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["nome"]     = Request["nome"];
            Session["email"]    = Request["email"];
            Session["telefone"] = Request["telefone"];
            Session["senha"]    = Request["senha"];
            Response.Redirect("sessao.aspx");
        }
    }
}