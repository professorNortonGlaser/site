﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="sessao.aspx.cs" Inherits="pw10_correcao.sessao" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        Nome:<asp:TextBox ID="txtNome" runat="server"></asp:TextBox><br />
        Email:<asp:TextBox ID="txtEmail" runat="server"></asp:TextBox><br />
        Telefone:<asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox><br />
        Senha: <asp:TextBox ID="txtSenha" runat="server"></asp:TextBox><br />
    </div>
    </form>
</body>
</html>
