#include <stdio.h>
#include <stdlib.h>

/* 
Crie uma tabela de um campeonato de futebol, com 10 times e 5 colunas

Na coluna 0 e o total de vitorias (multiplique por 3 pontos)
Na coluna 1 o total de empates (multiplique por 1 ponto)
Na coluna 2 o total de derrotas (multiplique por 0 pontos)
Na coluna 3 , calcule o total de pontos
Na coluna 4, o saldo de gols
Mostre ao final, o tr�s primeiros colocados da tabela, 
caso haja empate na pontua��o o maior saldo de gols e o crit�rio de desempate

 */

int main(int argc, char *argv[]) {
	int tabela[10][5];	
	int cont, x, maior, anterior, saldo, time;
	int vit = 0;
	int emp = 1;
	int der = 2;
	int pon = 3;
	int gol = 4;
	
	for(cont=0; cont<5; cont++){
		printf("t%d Informe o Total de Vitorias :", cont);
		scanf("%d", &tabela[cont][vit]);	
		printf("t%d Informe o Total de Empates :", cont);
		scanf("%d", &tabela[cont][emp]);
		printf("t%d Informe o Total de Derrotas :", cont);
		scanf("%d", &tabela[cont][der]);
		printf("t%d Informe o saldo de gols :", cont);
		scanf("%d", &tabela[cont][gol]);
		
		tabela[cont][pon] = (tabela[cont][vit]*3) + tabela[cont][emp];
	}
	
	anterior = 999;
	
	for(x=0; x<10; x++){		
		for(cont=0; cont<10; cont++)
		{
			if(tabela[cont][pon] < anterior) {			
				if(cont==0){			
					maior = tabela[cont][pon];   
					saldo = tabela[cont][gol];
					time = cont; 	
				} else {
					if(tabela[cont][pon] > maior){
						maior = tabela[cont][pon]; 	
						saldo = tabela[cont][gol]; 	
						time = cont; 	
					} else {
						if(tabela[cont][pon] == maior && 
							tabela[cont][gol] > saldo){		
							maior = tabela[cont][pon]; 	
							saldo = tabela[cont][gol]; 	
							time = cont; 	
						}
					} 					
				}				
			}
		}
		printf("%d pontos=%d gols=%d \n", time, maior, saldo);
		anterior = maior;			
	}
	
	
	
	return 0;
}
