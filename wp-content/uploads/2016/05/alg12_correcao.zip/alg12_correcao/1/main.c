#include <stdio.h>
#include <stdlib.h>

/* 
1- Armazene em uma matriz 10�5 o resultado de uma prova de alternativas:
a � coluna 0
b � coluna 1
c � coluna 2
d � coluna 3
e � coluna 4
Com um gabarito j� definido e armazenado em uma matriz, 
verifique a nota obtida pelo aluno */

int main(int argc, char *argv[]) {
	int gabarito[10][5];
	int prova[10][5];
	int nota = 0;
	int q, a;
	int alternativa;
	int altA =0;
	int altB =1;
	int altC =2;
	int altD =3;
	int altE =4;
	
	for(q = 0; q<10; q++)
	{
		for(a=0; a<5; a++){
			gabarito[q][a] = 0;
			prova[q][a]	= 0;
		}				
	}
	gabarito[0][altB] = 1;
	gabarito[1][altE] = 1;
	gabarito[2][altC] = 1;
	gabarito[3][altE] = 1;
	gabarito[4][altB] = 1;
	gabarito[5][altA] = 1;
	gabarito[6][altD] = 1;
	gabarito[7][altB] = 1;
	gabarito[8][altC] = 1;
	gabarito[9][altD] = 1;
	
	for(q = 0; q<10; q++)
	{
		printf("Q%d - Escolha a alternativa A-0 B-1 C-2 D-3 E-4 :", q);	
		scanf("%d", &alternativa);
		prova[q][alternativa] = 1;

		if(prova[q][alternativa] == gabarito[q][alternativa]){
			printf("q%d = OK \n", q);
			nota++;	
		}		
	}
	printf("Sua nota = %d \n", nota);
	
	return 0;
}
