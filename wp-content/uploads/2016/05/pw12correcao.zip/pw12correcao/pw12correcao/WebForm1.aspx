﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw12correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        Livro<br />
        <br />
        codigo:<asp:TextBox ID="txtCodigo" runat="server"></asp:TextBox>
        <asp:Button ID="Button1" runat="server" OnClick="Pesquisar" Text="Pesquisar" />
        <br />
        <br />
        titulo: <asp:TextBox ID="txtTitulo" runat="server"></asp:TextBox>
        <br />
        <br />
        autor:
        <asp:TextBox ID="txtAutor" runat="server"></asp:TextBox>
        <br />
        <br />
        qtd:<asp:TextBox ID="txtQtd" runat="server"></asp:TextBox>
        <br />
        <br />
        valor:<asp:TextBox ID="txtValor" runat="server"></asp:TextBox>
        <br />
        <br />
        paginas:<asp:TextBox ID="txtPaginas" runat="server"></asp:TextBox>
        <br />
        <br />
        resumo:<asp:TextBox ID="txtResumo" runat="server" TextMode="MultiLine"></asp:TextBox>
        <br />
        <br />
        <asp:Button ID="Button2" runat="server" OnClick="inserir" Text="Inserir" />
        <asp:Button ID="Button3" runat="server" OnClick="Alterar" Text="Alterar" />
        <asp:Button ID="Button4" runat="server" OnClick="excluir" Text="Excluir" />
        <br />
        <br />
        <asp:Label ID="lblMensagem" runat="server"></asp:Label>
    
    </div>
    </form>
</body>
</html>
