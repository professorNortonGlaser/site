﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace pw12correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string sc = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=C:\\basedados\\basedados.accdb;Persist Security Info=False;";
            protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void inserir(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();
                string sql = "insert into livro(titulo, autor, qtd, valor, " +
                    " paginas, resumo) values('{0}','{1}',{2},{3},{4},'{5}')";

                sql = String.Format(sql, txtTitulo.Text, txtAutor.Text,
                    txtQtd.Text, txtValor.Text, txtPaginas.Text, txtResumo);

                OleDbCommand comando = new OleDbCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "Registro Inserido com sucesso!";
                limpar();
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro !";
            }
            
        }

        protected void Pesquisar(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();
                string sql = "select * from livro where codigo="+ txtCodigo.Text;
                               
                OleDbCommand comando = new OleDbCommand(sql, conexao);

                OleDbDataReader linhas = comando.ExecuteReader();
                if(linhas.Read())
                {
                    txtAutor.Text   = linhas["autor"].ToString();
                    txtPaginas.Text = linhas["paginas"].ToString();
                    txtQtd.Text     = linhas["qtd"].ToString();
                    txtResumo.Text  = linhas["resumo"].ToString();
                    txtTitulo.Text  = linhas["titulo"].ToString();
                    txtValor.Text   = linhas["valor"].ToString();
                }
                else
                {
                    lblMensagem.Text = "Registro não encontrado !";
                    limpar();
                }
                conexao.Close();
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro !";
            }
        }

        protected void Alterar(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();
                string sql = "update livro set titulo='{0}', autor='{1}', qtd={2}" +
                    ", valor={3}, paginas={4}, resumo='{5}' where codigo={6}";

                sql = String.Format(sql, txtTitulo.Text, txtAutor.Text,
                    txtQtd.Text, txtValor.Text, txtPaginas.Text, 
                    txtResumo,txtCodigo.Text);

                OleDbCommand comando = new OleDbCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "Registro Alterado com sucesso!";
                limpar();
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro !";
            }
        }

        protected void excluir(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();
                string sql = "delete from livro where codigo="+ txtCodigo.Text;

                OleDbCommand comando = new OleDbCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "Registro Removido com sucesso!";
                limpar();
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro !";
            }
        }

        public void limpar()
        {
            txtAutor.Text = "";
            txtPaginas.Text = "";
            txtQtd.Text = "";
            txtResumo.Text = "";
            txtTitulo.Text = "";
            txtValor.Text = "";
        }
    }
}