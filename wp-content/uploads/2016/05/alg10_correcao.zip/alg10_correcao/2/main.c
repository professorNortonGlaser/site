#include <stdio.h>
#include <stdlib.h>

/* crie dois vetores de 10 posi��es de n�meros inteiros, colete os valores 
atrav�s das itera��es de um la�o, e outro la�o armazene no segundo la�o 
os valores em ordem inversa do �ndice. */

int main(int argc, char *argv[]) {
	int vet[10];
	int rev[10];
	int c;
	
	for(c=0; c<10; c++){
		printf("Informe um numero :");
		scanf("%d", &vet[c]);			
	}
	
	for(c=0; c<10; c++){
		rev[9-c] = vet[c];			
	}
	
	for(c=0; c<10; c++){
		printf("vet[%d]= %d => rev[%d]= %d \n", c, vet[c], c, rev[c]); 			
	}
	
	return 0;
}
