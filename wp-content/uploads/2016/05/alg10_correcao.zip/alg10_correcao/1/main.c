#include <stdio.h>
#include <stdlib.h>

/* 
1-crie um vetor de 10 posi��es de n�meros inteiros, 
colete os valores atrav�s das itera��es, conte a maior 
sequencia ordenada de numeros. */

int main(int argc, char *argv[]) {
	int vet[10];
	int x;
	int seq = 1;
	int maiorSeq = 0;
	
	for(x=0; x<10; x++){
		printf("Informe um numero:");
		scanf("%d", &vet[x]);		
	}
	
	x=0;
	do{
		if(vet[x] <= vet[x+1]){
			seq++;	
		} else {
			if(seq >= maiorSeq){
				maiorSeq = seq;	
			}
			seq = 1;
		}
				
		x++;	
	}while(x<10);
	printf("A maior sequencia foi %d", maiorSeq);
		
	return 0;
}
