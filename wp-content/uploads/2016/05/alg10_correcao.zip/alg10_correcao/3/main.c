#include <stdio.h>
#include <stdlib.h>

/* crie um vetor do tipo real , que armazene 24  temperaturas uma
 para cada hora do dia, em um primeiro la�o o usu�rio vai informar as 
 temperaturas, em um segunda la�o identifique a media da temperatura do dia, 
 a maior temperatura e a menor temperatura */

int main(int argc, char *argv[]) {
	float temp[24];
	float media=0;
	float menor, maior;
	int i;
	
	for(i=0; i<24; i++){
		printf("Informe a temperatura das %dh:", i);
		scanf("%f",&temp[i]);	
	}
	
	for(i=0; i<24; i++){
		if(i==0){
			maior = temp[i];
			menor = temp[i];
		} else {
			if(temp[i]> maior){
				maior = temp[i];	
			}
			if(temp[i]< menor){
				menor = temp[i];	
			}			
		}	
		media = media + temp[i];	
	}
	media = media /24;
	printf("Media: %f menor: %f maior:%f \n", media, menor, maior);
	
	
	return 0;
}
