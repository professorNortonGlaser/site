﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace pw13correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string sc = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=C:\\basedados\\basedados.accdb;Persist Security Info=False;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void carregar(object sender, EventArgs e)
        {
            OleDbConnection conexao = new OleDbConnection(sc);
            conexao.Open();
            DataSet ds = new DataSet();

            string sql = "select * from cliente order by nome";
            OleDbDataAdapter conversor = new OleDbDataAdapter(sql, conexao);
            conversor.Fill(ds, "tbCliente");

            sql = "select * from livro where valor <= 50 ";
            OleDbDataAdapter conversor2 = new OleDbDataAdapter(sql, conexao);
            conversor2.Fill(ds, "tbPromo");
            conexao.Close();

            GridView1.DataSource = ds.Tables["tbCliente"];
            GridView1.DataBind();

            DropDownList1.DataSource = ds.Tables["tbPromo"];
            DropDownList1.DataTextField  = "titulo";
            DropDownList1.DataValueField = "codigo";
            DropDownList1.DataBind();

        }
    }
}