#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int op;
	int tabuleiro[10][10];
	int pontos;
	int j, l, c;
	
	do{
		printf("Jogo Batalha Naval \n 1-Criar Campo \n 2-Jogar \n 3-Resultado \n 4-Sair \n");
		scanf("%d",&op);
		
		switch(op) 
		{
			case 1:{				
				//zerando tabuleiro
				for(l=0; l<10; l++){
					for(c=0; c<10; c++){
						tabuleiro[l][c]=0;	
					}	
				}
				//coletando jogadas
				for(j=0; j <10; j++){
					printf("Jogada %d posicao linha :", j);
					scanf("%d", &l);
					printf("Jogada %d posicao coluna :", j);
					scanf("%d", &c);	
					printf("Jogada %d 1-Para fragata 2- para destroier e 3 � para submarino :", j);
					scanf("%d", &tabuleiro[l][c]);	
				}	
				system("cls");
				printf("CAMPO PRONTO !!!!");
				break;
			}
			case 2: {
				pontos=0;
				//coletando jogadas
				for(j=0; j <10; j++){
					printf("Jogada %d posicao linha :", j);
					scanf("%d", &l);
					printf("Jogada %d posicao coluna :", j);
					scanf("%d", &c);	
					if(tabuleiro[l][c] > 0 ){
						printf("VC ACERTOU :-) !! \n");
						pontos = pontos + 	tabuleiro[l][c];
					} else {
						printf("AGUA :-( \n");
					}
				}	
				system("cls");
				printf("GAME OVER pontos=%d \n", pontos);
				break;
			}
			case 3:{
				for(l=0; l<10; l++){
					for(c=0; c<10; c++){
						printf("%d ", tabuleiro[l][c]);	
					}	
					printf("\n");
				}
				
				printf("Total de pontos = %d \n", pontos);
				break;
			}
			case 4:{
				printf("ATE MAIS !!!!! \n");
				break;
			}
			default :{
				printf("OPCAO INVALIDA !!!!! \n");
			}						
		}		

	} while(op!=4);
	
	
	
	return 0;
}
