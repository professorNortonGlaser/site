﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw11_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <strong>VALIDAÇÃO<br />
        </strong>
        <br />
Data de Inscrição 
        <asp:TextBox ID="txtData" runat="server"></asp:TextBox>
        <asp:RangeValidator ID="RangeValidator1" runat="server" ControlToValidate="txtData" ErrorMessage="RangeValidator" ForeColor="Red" MaximumValue="30/06/2016" MinimumValue="01/01/2016" Type="Date">– Período de 01/01/2016 ate 30/06/2016 </asp:RangeValidator>
        <br />
        Email 
        <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
        <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" ControlToValidate="txtEmail" ErrorMessage="RegularExpressionValidator" ForeColor="Red" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*">– validação de e-mail valido </asp:RegularExpressionValidator>
        <br />
        Senha 
        <asp:TextBox ID="txtSenha" runat="server" TextMode="Password"></asp:TextBox>
        <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtSenha" ErrorMessage="– campo obrigatório " ForeColor="Red"></asp:RequiredFieldValidator>
        <br />
        Confirmação de senha 
        <asp:TextBox ID="txtConfirma" runat="server" TextMode="Password"></asp:TextBox>
        <asp:CompareValidator ID="CompareValidator1" runat="server" ControlToCompare="txtSenha" ControlToValidate="txtConfirma" ErrorMessage="– verificar se esta igual ao campo senha " ForeColor="Red"></asp:CompareValidator>
        <br />
        cep  
        <asp:TextBox ID="txtCep" runat="server"></asp:TextBox>
        <asp:RegularExpressionValidator ID="RegularExpressionValidator2" runat="server" ControlToValidate="txtCep" ErrorMessage="– código numérico de 8 dígitos " ForeColor="Red"></asp:RegularExpressionValidator>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" Text="testar" />
    </div>
    </form>
</body>
</html>
