﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="email.aspx.cs" Inherits="pw14exemplo.email" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <asp:ScriptManager ID="ScriptManager1" runat="server">
        </asp:ScriptManager>
        <br />
        <asp:UpdateProgress ID="UpdateProgress1" runat="server">
            <ProgressTemplate>
                Enviando.....
            </ProgressTemplate>
        </asp:UpdateProgress>
        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
                <br />
                para:<asp:TextBox ID="txtPara" runat="server"></asp:TextBox>
                <br />
                <br />
                Assunto:<asp:TextBox ID="txtAssunto" runat="server"></asp:TextBox>
                <br />
                <br />
                Texto:<asp:TextBox ID="txtTexto" runat="server" TextMode="MultiLine"></asp:TextBox>
<br />
                <br />
                <asp:Button ID="Button1" runat="server" OnClick="enviar" Text="Enviar" />
                <br />
<br />
                <asp:Label ID="lblMensagem" runat="server"></asp:Label>
<br />
            </ContentTemplate>
        </asp:UpdatePanel>
        <br />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
