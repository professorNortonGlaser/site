﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

namespace pw14exemplo
{
    public partial class email : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void enviar(object sender, EventArgs e)
        {
            MailAddress de = new MailAddress("fatecpwAds2016@outlook.com");
            MailAddress para = new MailAddress(txtPara.Text);

            MailMessage email = new MailMessage();
            email.From = de;
            email.To.Add(para);

            email.Subject = txtAssunto.Text;
            email.Body = txtTexto.Text;
            email.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient("smtp-mail.outlook.com");
            try
            {
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.Credentials = new 
                    NetworkCredential("fatecpwAds2016@outlook.com", "FreiJoao59");
                smtp.Send(email);
                lblMensagem.Text = "Email enviado com sucesso !";
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro no envio de email !";
            }


        }
    }
}