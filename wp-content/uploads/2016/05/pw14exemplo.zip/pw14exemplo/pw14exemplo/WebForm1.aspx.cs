﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw14exemplo
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void semAjax(object sender, EventArgs e)
        {
            long x = 0;
            for(long i = 0; i < 9999999999; i++)
            {
                x = i;
            }
            Label1.Text = DateTime.Now.ToString();
        }

        protected void comAjax(object sender, EventArgs e)
        {
            long x = 0;
            for (long i = 0; i < 9999999999; i++)
            {
                x = i;
            }
            Label2.Text = DateTime.Now.ToString();
        }
    }
}