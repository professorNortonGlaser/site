#include <stdio.h>
#include <stdlib.h>

/* Crie dois vetores do tipo inteiro com a capacidade de 10 posi��es,
 leia n�meros que ser�o armazenados sequencialmente no primeiro vetor,
  fa�a um novo la�o que armazene no segundo vetor o valor do primeiro
   multiplicado por 2 quando o �ndice for par, 
   e multiplique por 3 quando o �ndice for impar. */

int main(int argc, char *argv[]) {
	int vetor1[10], vetor2[10];
	int resto, cont;
	
	for(cont=0; cont<10; cont++){
		printf("Informe o valor :");
		scanf("%d", & vetor1[cont]);			
	}
	
	for(cont=0; cont<10; cont++){
		resto = cont % 2;
		if(resto==0){
			vetor2[cont] = vetor1[cont] * 2;	
		} else {
			vetor2[cont] = vetor1[cont] * 3;	
		}
		printf("%d => %d => %d \n", cont, vetor1[cont], vetor2[cont]);	
	}
	
	return 0;
	
	
	
	
	
}
