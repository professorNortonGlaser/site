#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que armazene um vetor de inteiros de 20 posi��es, 
identifique  o percentual de n�meros impares e de n�meros pares informados.
 */

int main(int argc, char *argv[]) {
	int vetor[20];
	int i;
	int resto;
	float impares =0;
	float pares =0;
		
	for(i=0; i<20; i++){
		printf("Informe um valor para a posicao %d ", i);
		scanf("%d", &vetor[i]);					
		resto = vetor[i] % 2;
		if(resto == 0){
			pares++;	
		} 
		else{
			impares++;	
		}		
	}
	pares = (pares / 20)*100;
	impares = (impares / 20)*100;
	printf("Percentual de pares %f , percentual de impares %f ", pares, impares);

	return 0;
}
