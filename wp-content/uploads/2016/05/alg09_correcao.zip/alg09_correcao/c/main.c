#include <stdio.h>
#include <stdlib.h>

/* fa�a um algoritmo que implemente um vetor de 20 posi��es, 
leia as 20 posi��es e identifique em um novo la�o, 
qual o maior e menor numero informado e qual a media dos n�meros informados.
  */

int main(int argc, char *argv[]) {
	int vetor[20];
	int cont=0;
	int maior, menor;
	float media = 0;
	
	do{
		printf("%d - Informe um valor: ", cont);
		scanf("%d", &vetor[cont]);				
		cont++;	
	}while(cont<20); 
	
	for(cont=0; cont<20; cont++){
		if(cont==0){
			menor = vetor[0]; 
			maior = vetor[0];	
		} 
		else {
			if(vetor[cont] > maior){
				maior = vetor[cont];	
			}
			if(vetor[cont] < menor){
				menor = vetor[cont];	
			}									
		}				
		media = media + vetor[cont];		
	}
	media = media / 20;
	printf("Menor=%d , maior=%d , media=%f ", menor, maior, media);
	
	
	
	
	return 0;
}
