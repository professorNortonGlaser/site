﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Net.Mail;
using System.Net;

namespace pw14correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string sc = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=C:\\basedados\\basedados.accdb;Persist Security Info=False;";
        protected void Page_Load(object sender, EventArgs e)
        {
            if(IsPostBack == false)
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();
                string sql = "select * from livro order by titulo";
                OleDbDataAdapter conversor = new OleDbDataAdapter(sql, conexao);
                DataSet ds = new DataSet();
                conversor.Fill(ds, "produtos");
                conexao.Close();
                cboProduto.DataSource = ds.Tables["produtos"];
                cboProduto.DataTextField = "Titulo";
                cboProduto.DataValueField = "codigo";
                cboProduto.DataBind();
            }
        }

        protected void Enviar(object sender, EventArgs e)
        {
            MailAddress from = new MailAddress("fatecpwAds2016@outlook.com");
            MailAddress to = new MailAddress("norton.glaser@fatec.sp.gov.br");

            MailMessage email = new MailMessage();
            email.From = from;
            email.To.Add(to);
            email.Subject = "Orçamento de produto";
            email.Body = txtNome.Text + "<br>" + cboProduto.SelectedValue + "<br>" +
                        txtQtd.Text + "<br>" + txtTelefone.Text + "<br>" +
                        txtMensagem.Text;
            email.IsBodyHtml = true;

            SmtpClient smpt = new SmtpClient("smtp-mail.outlook.com");
            smpt.Port = 587;
            smpt.EnableSsl = true;
            smpt.Credentials = new NetworkCredential("fatecpwAds2016@outlook.com",
                                                          "FreiJoao59");
            try
            {
                smpt.Send(email);
                lblMensagem.Text = "Envio de email com sucesso !";
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro no envio de e-mail !";
            }


        }
    }
}