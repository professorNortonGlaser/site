﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace exemplo15
{
    public partial class produtos : System.Web.UI.Page
    {
        string sc = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=C:\\basedados\\basedados.accdb;Persist Security Info=False;";
        protected void Page_Load(object sender, EventArgs e)
        {
            string tipoDados = Request["tipo"];
            if (tipoDados == "1")
            {
                Response.Write(carregarLista());
            }
            if (tipoDados == "2")
            {
                Response.Write(carregarDetalhe(Request["codigo"]));
            }
            
        }

        private String carregarLista()
        {
            String retorno = "";
            OleDbConnection conexao = new OleDbConnection(sc);
            conexao.Open();
            string sql = "select * from livro";
            OleDbCommand comando = new OleDbCommand(sql, conexao);
            OleDbDataReader registros = comando.ExecuteReader();
            while (registros.Read())
            {
                retorno = retorno + "<option value=" + registros["codigo"] + ">" +
                                registros["titulo"] + "</option>";
            }
            conexao.Close();
            return retorno;
        }


        private String carregarDetalhe(string codigo)
        {
            String retorno = "";
            OleDbConnection conexao = new OleDbConnection(sc);
            conexao.Open();
            string sql = "select * from livro where codigo="+ codigo;
            OleDbCommand comando = new OleDbCommand(sql, conexao);
            OleDbDataReader registros = comando.ExecuteReader();
            if(registros.Read())
            {
                retorno = "titulo=" + registros["titulo"] + "<br>autor=" + registros["autor"] +
                          "<br>valor=" + registros["valor"] + "<br>paginas=" + registros["paginas"] +
                          "<br>resumo=" + registros["resumo"];
            }
            conexao.Close();

            return retorno;
        }
    }
}