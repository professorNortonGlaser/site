﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//adicionar biliotecas de acesso a dados
using System.Data;
using System.Data.OleDb;

namespace pw12_exemplo
{
    public partial class cliente : System.Web.UI.Page
    {
        string sc = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=C:\\basedados\\basedados.accdb;Persist Security Info=False;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Inserir(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();

                string sql = "insert into cliente(nome, email, telefone, senha) " +
                   " values('{0}','{1}','{2}','{3}')";

                sql = String.Format(sql, txtNome.Text, txtEmail.Text,
                    txtTelefone.Text, txtSenha.Text);

                OleDbCommand comando = new OleDbCommand(sql, conexao);
                comando.ExecuteNonQuery();
                lblMensagem.Text = "Registro inserido com sucesso !";
                conexao.Close();
                limpar();
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro !";
            }
        }

        protected void consultar(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();
                string sql = "select * from cliente where codigo=" + txtCodigo.Text;
                OleDbCommand comando = new OleDbCommand(sql, conexao);
                OleDbDataReader retorno = comando.ExecuteReader();
                if (retorno.Read())
                {
                    txtEmail.Text = retorno["email"].ToString();
                    txtNome.Text = retorno["nome"].ToString();
                    txtSenha.Text = retorno["senha"].ToString();
                    txtTelefone.Text = retorno["telefone"].ToString();
                    lblMensagem.Text = "";
                }
                else
                {
                    lblMensagem.Text = "Registro nao encontrado!";
                    limpar();
                }
                conexao.Close();
            }
            catch
            {
                lblMensagem.Text = "ocorreu um erro";
            }
        }

        protected void alterar(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();

                String sql = "update cliente set email='{1}', nome='{2}', senha='{3}', " +
                            " telefone='{4}' where codigo={0}";
                sql = String.Format(sql, txtCodigo.Text, txtEmail.Text, txtNome.Text,
                                    txtSenha.Text, txtTelefone.Text);
                OleDbCommand comando = new OleDbCommand(sql, conexao);
                comando.ExecuteNonQuery();
                lblMensagem.Text = "Registro Alterado com sucesso!";
                conexao.Close();
                limpar();
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro !";
            }
        }

        protected void excluir(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection conexao = new OleDbConnection(sc);
                conexao.Open();
        string sql = "delete * from cliente where codigo=" + txtCodigo.Text;
                OleDbCommand comando = new OleDbCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "Registro excluido !";
                limpar();
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro !";
            }
        }

        private void limpar()
        {
            txtEmail.Text = "";
            txtNome.Text = "";
            txtSenha.Text = "";
            txtTelefone.Text = "";
        }
    }
}