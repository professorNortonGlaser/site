﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="cliente.aspx.cs" Inherits="pw12_exemplo.cliente" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        CLIENTE<br />
        <br />
        Codigo:
        <asp:TextBox ID="txtCodigo" runat="server"></asp:TextBox>
        <asp:Button ID="Button2" runat="server" OnClick="consultar" Text="Consultar" />
        <br />
        <br />
        Nome: <asp:TextBox ID="txtNome" runat="server"></asp:TextBox>
        <br />
        <br />
        email:
        <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
        <br />
        <br />
        Telefone:
        <asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox>
        <br />
        <br />
        Senha:
        <asp:TextBox ID="txtSenha" runat="server"></asp:TextBox>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="Inserir" Text="Inserir" />
        <asp:Button ID="Button3" runat="server" Text="Alterar" OnClick="alterar" />
        <asp:Button ID="Button4" runat="server" Text="Excluir" OnClick="excluir" />
        <br />
        <br />
        <asp:Label ID="lblMensagem" runat="server"></asp:Label>
    
    </div>
    </form>
</body>
</html>
