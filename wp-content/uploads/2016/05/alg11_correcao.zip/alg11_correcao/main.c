#include <stdio.h>
#include <stdlib.h>

/* 
Construa um programa em C que utiliza uma matriz 10�3 que armazene as
  temperaturas m�xima e minima do dia, assim como a media de 
  temperatura na ultima coluna. 
   Crie um menu de escolha que ofere�a as seguintes informa��es:
1.temperatura minima de todos os dias.
2.temperatura m�xima de todos os dias.
3.maior varia��o de temperatura de todos os dias.
4.Sair do programa.
 */

int main(int argc, char *argv[]) {
	float temp[10][3];
	float minima, maxima, var, varMax;
	int i, op;
	
	for(i=0; i<10; i++){
		printf("Informe a temperatura minima do dia %d :", i);
		scanf("%f", &temp[i][0]);		
		printf("Informe a temperatura maxima do dia %d :", i);
		scanf("%f", &temp[i][1]);
		temp[i][2] = (temp[i][0]+temp[i][1]) /2;		
	}
	
	do{
		printf("1.temperatura minima de todos os dias.\n");
		printf("2.temperatura m�xima de todos os dias.\n");
		printf("3.maior varia��o de temperatura de todos os dias.\n");
		printf("4.Sair do programa.\n");
		scanf("%d", &op);
		
		switch(op){
			case 1:{
				minima = temp[0][0];
				for(i=0;i<10;i++){
					if(temp[i][0] < minima) {
						minima = temp[i][0];	
					}					
				}
				printf("A temperatura minima foi %f \n", minima);				
				break;
			}
			case 2:{
				maxima = temp[0][1];
				for(i=0;i<10;i++){
					if(temp[i][1] > maxima) {
						maxima = temp[i][1];	
					}					
				}
				printf("A temperatura maxima foi %f \n", maxima);	
				break;
			}	
			case 3:{
				varMax = temp[0][1] - temp[0][0];
				for(i=0;i<10;i++){
					var = temp[i][1] - temp[i][0];	
					if(var > varMax){
						varMax = var;	
					}
				}
				printf("A  maior variacao foi %f \n",varMax);	
				break;
			}
			case 4:{
				printf("SAINDO....");
				break;
			}
			default: {
				printf("OPCAO INVALIDA!!!!");
			}							
		}
		
	} while(op!=4);
	
	
	
	
	return 0;
}
