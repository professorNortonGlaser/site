<?php
	$a = 0;
	$b = 0;
	$r = 0;
	if(isset($_POST["n1"]) && isset($_POST["n2"])){
		$a = $_POST["n1"];
		$b = $_POST["n2"];
	}
	
	if(isset($_POST["bt1"])){
		$r = $a + $b;
	}
	
	if(isset($_POST["bt2"])){
		$r = $a - $b;
	}
	
	if(isset($_POST["bt3"])){
		$r = $a * $b;
	}
	
	if(isset($_POST["bt4"])){
		$r = $a / $b;
	}
	
	

?>
<html>
	<body>
		<form method="post" action="fw08correcao.php">
			N1: <input type="text" id="n1" name="n1"
				value="<?php 
							echo $a; 
						?>">
			<br>
			N2: <input type="text" id="n2" name="n2"
			value="<?php 
						echo $b; 
					?>">
			<br>
			<b><?php 
				echo "O resultado e = $r"; 
			   ?> </b><br>
			<input type="submit" value="+" name="bt1">			
			<input type="submit" value="-" name="bt2">
			<input type="submit" value="*" name="bt3">
			<input type="submit" value="/" name="bt4">
		</form>
	</body>
</html>	
	
	