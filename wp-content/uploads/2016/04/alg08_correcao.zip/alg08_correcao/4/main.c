#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i;
	int x;
	int produto;
	
	printf("Informe a tabuada:");
	scanf("%d", &x);
	
	for(i=1; i<=10; i++){
		produto = x * i;
		printf("%d X %d = %d \n", i, x, produto);			
	}
	
	return 0;
}
