#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int casa;
	int total=0; 
	int anterior=0;
	
	
	for(casa=1; casa <= 16; casa++){		
		if(anterior	<=0){
			anterior = 1;	
		} else {
			anterior = anterior * 2;
		}
		total = total + anterior;		
	}
	printf("Total de graos %d", total);
	
	
	return 0;
}
