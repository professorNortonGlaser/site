#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int cont=0;
	int x;
	int y;
	
	printf("Pense em um numero :");
	scanf("%d", &x);
	
	do{
		cont++;
		printf("Chute um numero:");
		scanf("%d", &y);
		if(y>x){
			printf("o numero informado e maior!\n")	;
		} else {
			if(x>y){
				printf("o numero informado e menor!\n")	;
			} else {
				printf("vc acertou %d tentativas!\n", cont)	;
			}			
		}					
	}while(x!=y);
	
	
	
	return 0;
}
