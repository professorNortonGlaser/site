#include <stdio.h>
#include <stdlib.h>

/* Fa�a um algoritmo que conte de 1 a 100 e a cada m�ltiplo de 3 e 5 
simultaneamente emita uma mensagem:  �M�ltiplo de 3 e 5�. */

int main(int argc, char *argv[]) {
	int c;
	int resto3, resto5;
	
	for(c=1; c<=100; c++){
		resto3 = c % 3;
		resto5 = c % 5;
		if(resto3==0 && resto5==0)
		{
			printf("%d e divido por 3 e 5 \n", c);	
		}				
	}
	
	return 0;
}
