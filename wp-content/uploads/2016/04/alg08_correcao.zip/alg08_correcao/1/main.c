#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int x;
	int resto;
	
	for(x=100; x<=200; x++){
		resto = x % 2;
		if(resto==1){
			printf("%d \n", x); 				
		}			
	}	
	
	return 0;
}
