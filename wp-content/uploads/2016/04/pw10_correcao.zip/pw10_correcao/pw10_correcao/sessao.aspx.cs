﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw10_correcao
{
    public partial class sessao : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtEmail.Text = (String)Session["email"];
            txtNome.Text = (String)Session["nome"];
            txtSenha.Text = (String)Session["senha"];
            txtTelefone.Text = (String)Session["telefone"];

        }
    }
}