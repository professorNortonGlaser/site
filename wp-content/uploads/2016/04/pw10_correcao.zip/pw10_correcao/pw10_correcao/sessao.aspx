﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="sessao.aspx.cs" Inherits="pw10_correcao.sessao" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        CONVERTER ASPX<br />
        <br />
        NOME:<asp:TextBox ID="txtNome" runat="server"></asp:TextBox>
        <br />
        <br />
        EMAIL:<asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
        <br />
        <br />
        TELEFONE:<asp:TextBox ID="txtTelefone" runat="server"></asp:TextBox>
        <br />
        <br />
        SENHA:<asp:TextBox ID="txtSenha" runat="server"></asp:TextBox>
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
