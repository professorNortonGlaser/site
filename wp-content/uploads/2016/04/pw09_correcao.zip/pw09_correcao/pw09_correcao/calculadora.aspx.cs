﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw09_correcao
{
    public partial class calculadora : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void somar(object sender, EventArgs e)
        {
            try
            {
                decimal a = Convert.ToDecimal(txtN1.Text);
                decimal b = Convert.ToDecimal(txtN2.Text);
                decimal r = a + b;
                lblMensagem.Text = Convert.ToString(r);
            }
            catch(Exception erro)
            {                
                lblMensagem.Text = "Informe apenas numeros";    
            }
        }

        protected void subtrair(object sender, EventArgs e)
        {
            try
            {
                decimal a = Convert.ToDecimal(txtN1.Text);
                decimal b = Convert.ToDecimal(txtN2.Text);
                decimal r = a - b;
                lblMensagem.Text = Convert.ToString(r);
            }
            catch (Exception erro)
            {
                lblMensagem.Text = "Informe apenas numeros";
            }
        }

        protected void multiplicar(object sender, EventArgs e)
        {
            try
            {
                decimal a = Convert.ToDecimal(txtN1.Text);
                decimal b = Convert.ToDecimal(txtN2.Text);
                decimal r = a * b;
                lblMensagem.Text = Convert.ToString(r);
            }
            catch (Exception erro)
            {
                lblMensagem.Text = "Informe apenas numeros";
            }
        }

        protected void dividir(object sender, EventArgs e)
        {
            try
            {
                decimal a = Convert.ToDecimal(txtN1.Text);
                decimal b = Convert.ToDecimal(txtN2.Text);
                decimal r = a / b;
                lblMensagem.Text = Convert.ToString(r);
            }
            catch (Exception erro)
            {
                lblMensagem.Text = "Informe apenas numeros";
            }
        }
    }
}