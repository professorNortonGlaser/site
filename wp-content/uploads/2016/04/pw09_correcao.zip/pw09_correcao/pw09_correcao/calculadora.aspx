﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="calculadora.aspx.cs" Inherits="pw09_correcao.calculadora" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        Calculadora<br />
        <br />
        <br />
        N1:<asp:TextBox ID="txtN1" runat="server"></asp:TextBox>
        <br />
        <br />
        <br />
        N2:<asp:TextBox ID="txtN2" runat="server"></asp:TextBox>
        <br />
        <br />
        <asp:Button ID="Button1" runat="server" OnClick="somar" Text="+" />
        <asp:Button ID="Button2" runat="server" OnClick="subtrair" Text="-" />
        <asp:Button ID="Button3" runat="server" OnClick="multiplicar" Text="*" />
        <asp:Button ID="Button4" runat="server" OnClick="dividir" Text="/" />
        <br />
        <br />
        <br />
        <asp:Label ID="lblMensagem" runat="server"></asp:Label>
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
