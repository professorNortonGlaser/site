#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b,c;
	
	printf("Informe um valor para A:");
	scanf("%d", &a);
	printf("Informe um valor para B:");
	scanf("%d", &b);
	printf("Informe um valor para C:");
	scanf("%d", &c);
	
	if(a!=b && b!=c && a!=c){
		if(a>b && a>c){
			printf("A e maior %d \n", a);
			if(b > c){
				printf("B esta no meio %d C e o menor %d \n", b, c);	
			} else {
				printf("C esta no meio %d B e o menor %d \n", c, b);		
			}				
		} 
		else {
			if(b>c){
				printf("B e maior %d \n", b);		
				if(a > c){
					printf("A esta no meio %d C e o menor %d \n", a, c);	
				} else {
					printf("C esta no meio %d A e o menor %d \n", c, a);		
				}								
			} else {
				printf("C e maior %d \n", c);		
				if(a > b){
					printf("A esta no meio %d B e o menor %d \n", a, b);	
				} else {
					printf("B esta no meio %d A e o menor %d \n", b, a);		
				}												
			}				
		}					
	} else {
		printf("Existem numero iguais !!!");
	}
	
		
	
	return 0;
}
