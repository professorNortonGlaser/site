#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que leia a temperatura em graus Celsius
 e converta para fahrenheit F = (9 * C + 160) / 5
 */

int main(int argc, char *argv[]) {
	/*
		real: f, c
		C = informe a temparatura em Celsius 
		F = (9 * C + 160) / 5
		O temperatura em fahrenheit = f	
	*/
	float f,c;
	
	printf("informe a temparatura em Celsius :");
	scanf("%f", &c);
	f = (9* c+160)/5;
	printf("a temperatura em fahrenheit = %.2f", f);
			
	return 0;
}
