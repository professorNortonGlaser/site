#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que calcule a media de 4 n�meros 
reais e mostre o resultado 
*/

int main(int argc, char *argv[]) {
	/*
		real: a,b,c,d,resultado
		informe um valor para a
		informe um valor para b
		informe um valor para c
		informe um valor para d
		resultado = (a+b+c+d)/4
		mostre resultado	
	*/
	float a,b,c,d, resultado;
	printf("informe um valor para a: ");
	scanf("%f", &a);
	printf("informe um valor para b: ");
	scanf("%f", &b);
	printf("informe um valor para c: ");
	scanf("%f", &c);
	printf("informe um valor para d: ");
	scanf("%f", &d);
	
	resultado = (a+b+c+d)/4;
	printf("O resultado = %f", resultado);
	
	return 0;
}
