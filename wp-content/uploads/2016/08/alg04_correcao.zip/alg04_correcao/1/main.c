#include <stdio.h>
#include <stdlib.h>

/* 1- Fa�a um algoritmo que receba um n�mero inteiro, 
identifique se este e par ou impar, 
utilize o modulo de 2 para calcular o resto da divis�o, 
se o resto da divis�o for zero (o n�mero e par) caso o
 resto da divis�o for 1 (o n�mero e impar) */

int main(int argc, char *argv[]) {
	int numero, resto;
	printf("informe um numero :");
	scanf("%d", &numero);
	// Modulo de 2 traz o resto da divis�o inteira
	resto = numero % 2; 
	//Express�es relacionais: == igual != diferente > maior < menor
	if(resto == 0)
	{
		printf("numero par \n");		
	} 
	else
	{
		printf("numero impar \n");		
	}
	
	
	return 0;
}
