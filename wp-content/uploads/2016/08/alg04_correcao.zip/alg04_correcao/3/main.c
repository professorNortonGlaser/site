#include <stdio.h>
#include <stdlib.h>

/* Crie um  algoritmo que informe dois valores reais,
 valor em reais do litro da gasolina e 
 valor em reais do litro do �lcool,  
 calcule os 70% do valor da gasolina para definir na tela 
 qual combust�vel e o mais vantajoso, 
 sabendo que o valor do �lcool para ser mais vantajoso
  deve ser menor que 70% do valor da gasolina.
 */

int main(int argc, char *argv[]) {
	float alcool, gasolina, percGasolina;
	
	printf("Informe um valor para gasolina:");
	scanf("%f", &gasolina);
	printf("Informe um valor para alcool:");
	scanf("%f", &alcool);
	
	percGasolina = gasolina * 0.7;
	
	if(percGasolina < alcool){
		printf("Gasolina e mais vantajosa");	
	} 
	else
	{
		printf("alcool e mais vantajoso");	
	}
	
	
	
	
	return 0;
}
