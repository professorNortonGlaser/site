#include <stdio.h>
#include <stdlib.h>

/*  fa�a um algoritmo em c que receba dois  n�meros, 
verifique qual o maior e qual o menor */

int main(int argc, char *argv[]) {
	int a, b;
	
	printf("Informe um valor para A: ");
	scanf("%d", &a);
	printf("Informe um valor para B: ");
	scanf("%d", &b);
	
	if(a > b)
	{
		printf("A e maior q B \n");	
	}
	else 
	{
		printf("B e maior q A \n");	
	}
	

	return 0;
}
