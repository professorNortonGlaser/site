#include <stdio.h>
#include <stdlib.h>

/* Informe as duas notas de um aluno (P1 e P2) e a quantidade de faltas no semestre,
 calcule a media das notas e o percentual de faltas sobre 20 aulas.  
 Caso o percentual de faltas for maior que 30% o aluno esta automaticamente reprovado,
 caso ao contrario verifique se a media e maior igual a 6,  
 se afirmativo o aluno esta aprovado, 
 sen�o informe uma nota P3 para recalcular a media, 
 se a nova media for maior igual a 6, escreva aprovado no exame, 
 caso negativo exiba reprovado por nota. */

int main(int argc, char *argv[]) {
	float p1, p2, p3, media, percFaltas;
	int totalAulas = 20;
	int faltas;
	
	printf("Informe a nota P1: ");
	scanf("%f", &p1);
	printf("Informe a nota P2: ");
	scanf("%f", &p2);
	printf("Informe a quantidade de faltas ");
	scanf("%d", &faltas);
	
	percFaltas = totalAulas * 0.3; // 0.3 = 30/100
	media = (p1+p2)/2; 
	
	if(faltas > percFaltas)
	{
		printf("Aluno reprovado por faltas %d \n", faltas);
	}
	else 
	{
		if(media>=6){
			printf("Aprovado %f \n", media);	
		} 
		else 
		{
			printf("Informe a nota P3: ");
			scanf("%f", &p3);
			media = (p1+p2+p3)/3; 
			if(media >=6)
			{
				printf("Aprovado no exame %f \n", media);		
			} 
			else 
			{
				printf("Aluno reprovado no exame %f \n", media);		
			}
		}
	}
	
	
	return 0;
}
