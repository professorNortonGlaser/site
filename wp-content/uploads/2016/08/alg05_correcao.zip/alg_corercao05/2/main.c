#include <stdio.h>
#include <stdlib.h>

/* Informe dois n�meros reais e um n�mero inteiro que represente 
a opera��o matem�tica a ser realizada (1-soma, 2-subtra��o, 3- multiplica��o, 
4-divis�o, 5-resto) utilize o comando sele��o aninhado e exiba o resultado
 da opera��o matem�tica escolhida. */

int main(int argc, char *argv[]) {
	float n1, n2, resultado;
	int op;
	
	printf("1-soma, 2-subtrair, 3- multiplicar, 4-dividir, 5-resto: ");
	scanf("%d",&op);
	
	printf("Informe um operando: ");
	scanf("%f",&n1);
	
	printf("Informe outro operando: ");
	scanf("%f",&n2);
	
	if(op==1)
	{
		resultado = n1 + n2;	
	} 
	else {
		if(op==2){
			resultado = n1 - n2;		
		} 
		else {
			if(op==3){
				resultado = n1 * n2;			
			} 
			else {
				if(op==4){
					resultado = n1 / n2;			
				} else {
					resultado = (int)n1 % (int)n2;			
				}					
			}	
		}
	}
	printf("O resultado = %f", resultado);
	
	return 0;
}
