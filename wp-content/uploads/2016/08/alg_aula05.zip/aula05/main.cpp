#include <cstdlib>
#include <iostream>

using namespace std;
/*
  autor: Prof. Norton
  data: 24/02/2014
  Obs: crie um programa que entre com 3 n�mero, identifique se as medidas s�o 
  de um triangulo, e depois verifique qual tipo de triangulo este pertence:
        equilatero: 3 lados iguais
        isoceles: 2 lados iguais
        escaleno: 3 lados diferentes  
*/
int main(int argc, char *argv[])
{
    float a,b,c;
    
    cout << "Informe o lado A:";
    cin >> a;
    cout << "Informe o lado B:";
    cin >> b;
    cout << "Informe o lado C:";
    cin >> c;
    
    if((a < (b+c)) && (b < (a+c)) && (c < (b+a)))
    {
          if((a==b) && (b==c)) 
          {
              cout << "\n => Equilatero\n ";                    
          } else {          
              if((a==b) || (a==c) || (b==c)){
                 cout << "\n => Isoceles \n";                  
              } else {
                 cout << "\n => Escaleno \n";    
              }   
          }
    } else {
         cout << "Nao e um triangulo";       
    }
    

    
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
