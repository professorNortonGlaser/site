﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data; //adicionado
using MySql.Data.MySqlClient; //adicionado

namespace pw13correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Carregar(object sender, EventArgs e)
        {
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from cliente order by nome";
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql, conexao);
            DataSet ds = new DataSet();
            conversor.Fill(ds, "tbCliente");
            sql = "select * from livro where valor <= 50";
            MySqlDataAdapter conversor2 = new MySqlDataAdapter(sql, conexao);
            conversor2.Fill(ds, "tbPromo");
            conexao.Close();

            GridView1.DataSource = ds.Tables["tbCliente"];
            GridView1.DataBind();

            DropDownList1.DataSource = ds.Tables["tbPromo"];
            DropDownList1.DataTextField  = "titulo";
            DropDownList1.DataValueField = "codigo";
            DropDownList1.DataBind();
        }
    }
}