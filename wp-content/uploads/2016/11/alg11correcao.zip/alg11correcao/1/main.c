#include <stdio.h>
#include <stdlib.h>

/* 
Construa um programa em C que utiliza uma matriz 10�3 
que armazene as  temperaturas m�xima e minima do dia, 
assim como a media de temperatura na ultima coluna.  
Crie um menu de escolha que ofere�a as seguintes informa��es
1-temperatura minima de todos os dias.
2-temperatura m�xima de todos os dias.
3-maior varia��o de temperatura de todos os dias.
4-Sair do programa.
*/

int main(int argc, char *argv[]) {
	float temp[10][3];
	int cont, op;
	float maior, menor, maiorV, variacao;
	
	for(cont=0; cont<10; cont++){
		printf("Informe a Temp. Minima do dia %d :", cont);
		scanf("%f",&temp[cont][0]);		
		printf("Informe a Temp. Maxima do dia %d :", cont);
		scanf("%f",&temp[cont][1]);		
		temp[cont][2] = (temp[cont][0] + temp[cont][1]) /2;
	}
	do{
		printf("1-temperatura minima de todos os dias.\n");
		printf("2-temperatura m�xima de todos os dias.\n");
		printf("3-maior varia��o de temperatura de todos os dias.\n");
		printf("4-Sair do programa.	\n");
		scanf("%d", &op);
		
		if(op==1){
			for(cont=0; cont<10; cont++){
				if(cont==0){
					menor=temp[cont][0];	
				} else {
					if(temp[cont][0]<menor)	{
						menor=temp[cont][0];				
					}
				}		
			}	
			printf("A menor temperatura foi %f \n", menor);
		}
		
		if(op==2){
			for(cont=0; cont<10; cont++){
				if(cont==0){
					maior=temp[cont][1];	
				} else {
					if(temp[cont][1]>maior)	{
						maior=temp[cont][1];				
					}
				}		
			}	
			printf("A maior temperatura foi %f \n", maior);
		}
				
		if(op==3){
			for(cont=0; cont<10; cont++){
				variacao = temp[cont][1] - temp[cont][0];
				if(cont==0){
					maiorV=variacao;	
				} else {
					if(variacao>maiorV)	{
						maiorV=variacao;				
					}
				}		
			}	
			printf("A maior variacao foi %f \n", maiorV);
		}
				
		
		
	}while(op!=4); 
	
	
	return 0;
}
