#include <stdio.h>
#include <stdlib.h>

/* 
Armazene em uma matriz 10�5 o resultado de uma prova de alternativas:
a � coluna 0
b � coluna 1
c � coluna 2
d � coluna 3
e � coluna 4
Com um gabarito j� definido e armazenado em uma matriz, 
verifique a nota obtida pelo aluno
*/

int main(int argc, char *argv[]) {
	int gabarito[10][5];
	int prova[10][5];
	int linha, coluna, alternativa, nota;
	int a = 0, b = 1, c = 2, d=3,e=4;
	
	for(linha =0; linha<10; linha++){
		for(coluna=0; coluna <5; coluna++){
			gabarito[linha][coluna] = 0;		
			prova[linha][coluna] = 0;		
		}				
	}
	gabarito[0][b] = 1;		
	gabarito[1][d] = 1;		
	gabarito[2][a] = 1;		
	gabarito[3][e] = 1;		
	gabarito[4][c] = 1;		
	gabarito[5][b] = 1;		
	gabarito[6][d] = 1;		
	gabarito[7][e] = 1;		
	gabarito[8][d] = 1;		
	gabarito[9][a] = 1;		
	
	nota = 0;
	for(linha=0;linha<10; linha++){
		printf("Informe a alternativa para a questao %d :", linha);
		scanf("%d", &alternativa);	
		prova[linha][alternativa] = 1;
		if(prova[linha][alternativa] == gabarito[linha][alternativa]){
			nota++;	
		}				
	}
	printf("A sua nota : %d \n", nota);
		
	for(linha=0; linha<10; linha++){
		printf("\n %d = ", linha);
		for(coluna=0; coluna<5; contColuna++){
			printf("%d ", prova[cont][contColuna]);
		}							
	}	
	
	return 0;
}
