#include <stdio.h>
#include <stdlib.h>

/*
3 � Crie uma tabela de um campeonato de futebol, com 10 times e 
5 colunas
Na coluna 0 e o total de vitorias (multiplique por 3 pontos)
Na coluna 1 o total de empates (multiplique por 1 ponto)
Na coluna 2 o total de derrotas (multiplique por 0 pontos)
Na coluna 3 , calcule o total de pontos
Na coluna 4, o saldo de gols
Mostre ao final, o tr�s primeiros colocados da tabela, 
caso haja empate na pontua��o o maior saldo de gols e o
 crit�rio de desempate
 */

int main(int argc, char *argv[]) {
	int times[10][5];
	int totalPontos, linha, coluna;
	int vitorias=0, empates=1, derrotas=2, pontos=3, gols=4;
	int maior, posicao, maiorSelecionado;
	
	for(linha=0; linha<10; linha++){
		printf("Informe o total de vitorias:");
		scanf("%d", &times[linha][vitorias]);		
		printf("Informe o total de empates:");
		scanf("%d", &times[linha][empates]);
		printf("Informe o total de derrotas:");
		scanf("%d", &times[linha][derrotas]);
		printf("Informe o total de gols:");
		scanf("%d", &times[linha][gols]);
		times[linha][pontos]=(times[linha][vitorias]*3) + times[linha][empates];		
	}
	maiorSelecionado = 9999;
	for(posicao=1; posicao<=3;posicao++){	
		for(linha=0; linha<10; linha++){
			if(times[linha][pontos] < maiorSelecionado){			
				if(linha==0){
					maior = times[linha][pontos];	
				} else {
					if(times[linha][pontos]>maior){
						maior = times[linha][pontos];
					}												
				} 						
			}
		}
		maiorSelecionado = maior;
		printf("%d pontos=%d \n", posicao, maiorSelecionado );
	}
	
	
	return 0;
}
