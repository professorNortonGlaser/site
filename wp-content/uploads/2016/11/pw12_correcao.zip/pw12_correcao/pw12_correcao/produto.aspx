﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="produto.aspx.cs" Inherits="pw12_correcao.produto" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        PRODUTO<br />
        <br />
        Codigo:<asp:TextBox ID="txtCodigo" runat="server"></asp:TextBox>
        <asp:Button ID="Button1" runat="server" Text="READ" OnClick="Read" /><br /><br />
        Titulo:<asp:TextBox ID="txtTitulo" runat="server"></asp:TextBox><br /><br />
        Autor:<asp:TextBox ID="txtAutor" runat="server"></asp:TextBox><br /><br />
        qtd:<asp:TextBox ID="txtQtd" runat="server"></asp:TextBox><br /><br />
        valor:<asp:TextBox ID="txtValor" runat="server"></asp:TextBox><br /><br />
        paginas:<asp:TextBox ID="txtPaginas" runat="server"></asp:TextBox><br /><br />
        resumo:<asp:TextBox ID="txtResumo" runat="server" TextMode="MultiLine"></asp:TextBox><br /><br />
        <asp:Button ID="Button2" runat="server" Text="Create" OnClick="Create" />
        <asp:Button ID="Button3" runat="server" Text="Update" OnClick="Update" />
        <asp:Button ID="Button4" runat="server" Text="Delete" OnClick="Delete" />
        <br />
        <asp:Label ID="lblMensagem" runat="server" Text=""></asp:Label>
    
    </div>
    </form>
</body>
</html>
