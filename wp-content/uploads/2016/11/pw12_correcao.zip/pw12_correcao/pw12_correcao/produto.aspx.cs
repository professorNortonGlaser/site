﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;  //adicionado
using MySql.Data.MySqlClient; //adicionado

namespace pw12_correcao
{
    public partial class produto : System.Web.UI.Page
    {
        string sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Create(object sender, EventArgs e)
        {
            try         {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                string sql = "insert into livro(titulo, autor, qtd, valor, paginas," +
                              "resumo) values('{0}','{1}',{2},{3},{4},'{5}')";
                sql = String.Format(sql, txtTitulo.Text, txtAutor.Text, txtQtd.Text,
                            txtValor.Text, txtPaginas.Text, txtResumo.Text);
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                lblMensagem.Text = "Produto inserido com sucesso";
                conexao.Close();
            }
            catch(Exception err)         {
                lblMensagem.Text = "Ocorreu um erro " + err.Message;            
            }
        }

        protected void Read(object sender, EventArgs e)
        {
            try           {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                string sql = "select * from livro where codigo=" + txtCodigo.Text;
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                MySqlDataReader registros = comando.ExecuteReader();
                if (registros.Read()) {
                    txtAutor.Text = registros["autor"].ToString();
                    txtPaginas.Text = registros["paginas"].ToString();
                    txtQtd.Text = registros["qtd"].ToString();
                    txtResumo.Text = registros["resumo"].ToString();
                    txtTitulo.Text = registros["titulo"].ToString();
                    txtValor.Text = registros["valor"].ToString();
                    lblMensagem.Text = "";
                } else {
                    lblMensagem.Text = "Registro não existe";
                }
                conexao.Close();
            }
            catch (Exception err)          {
                lblMensagem.Text = "Ocorreu um erro" + err.Message;
            }
        }

        protected void Update(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                string sql = "update livro set titulo='{0}',autor='{1}',qtd={2},valor={3}," +
                        " paginas={4},resumo='{5}' where codigo={6}";
                sql = String.Format(sql, txtTitulo.Text, txtAutor.Text, txtQtd.Text,
                       txtValor.Text, txtPaginas.Text, txtResumo.Text, txtCodigo.Text);
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                lblMensagem.Text = "Produto alterado com sucesso";
                conexao.Close();
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Ocorreu um erro " + err.Message;
            }
        }

        protected void Delete(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                string sql = "delete from livro where codigo="+ txtCodigo.Text;
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                lblMensagem.Text = "Produto removido com sucesso";
                conexao.Close();
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Ocorreu um erro " + err.Message;
            }
        }
    }
}