﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

namespace pw12_correcao
{
    public partial class produto : System.Web.UI.Page
    {
        string sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Create(object sender, EventArgs e)
        {
            try {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                string sql = "insert into produto(nome, valor, qtd) values('{0}'," +
                            "{1}, {2})";
                sql = String.Format(sql, txtNome.Text, txtValor.Text, txtQtd.Text);
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "Registro inserido com sucesso!";
                limpar();
            }
            catch (Exception err) {
                lblMensagem.Text = "Ocorreu um erro " + err.Message;
            }
        }

        private void limpar()
        {
            txtNome.Text = "";
            txtQtd.Text = "";
            txtValor.Text = "";
        }

        protected void Read(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                string sql = "select * from produto where codigo="+ txtCodigo.Text;                
                MySqlCommand comando = new MySqlCommand(sql, conexao);

                MySqlDataReader registro = comando.ExecuteReader();
                if (registro.Read())
                {
                    txtNome.Text = registro["nome"].ToString();
                    txtQtd.Text = registro["qtd"].ToString();
                    txtValor.Text = registro["valor"].ToString();
                    lblMensagem.Text = "";
                }
                else
                {
                    lblMensagem.Text = "Registro não encontrado !";
                    limpar();
                }
                conexao.Close();        
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Ocorreu um erro " + err.Message;
            }
        }

        protected void Update(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                string sql = "update produto set nome='{0}'," +
                            "valor={1}, qtd={2} where codigo={3}";
                sql = String.Format(sql, txtNome.Text, txtValor.Text, txtQtd.Text, 
                                        txtCodigo.Text);
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "Registro alterado com sucesso!";
                limpar();
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Ocorreu um erro " + err.Message;
            }
        }

        protected void Delete(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection(sc);
                conexao.Open();
                string sql = "delete from produto where codigo=" + txtCodigo.Text;
                MySqlCommand comando = new MySqlCommand(sql, conexao);
                comando.ExecuteNonQuery();
                conexao.Close();
                lblMensagem.Text = "Registro removido com sucesso!";
                limpar();
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Ocorreu um erro " + err.Message;
            }
        }


    }
}