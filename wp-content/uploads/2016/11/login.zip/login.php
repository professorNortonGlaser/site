<html>
	<body>
	<form method="post" action="login.php">
	Usuario: <input type="text" name="usuario">
	Senha: <input type="password" name="senha">
	<input type="submit" value="Enviar" 
	name="bt1">	
	</form>
	</body>
</html>
<?php	
	if(isset($_POST["bt1"])){
		$conn = new mysqli("localhost","segma","segma","fw");
		$usuario = $_POST["usuario"];
		$senha	 = $_POST["senha"];
		$sql = "select codigo,nome, email from usuario where email='$usuario' and md5('$senha')=senha";
		$registros = mysqli_query($conn, $sql);
		if($linha = mysqli_fetch_array($registros)){
			//redirecionar;
			echo "Bem vindo, ". $linha["nome"];
		} else {
			echo "Usuario ou senha incorretos";
		}
		$conn->close();
	}
?>