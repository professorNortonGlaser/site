#include <stdio.h>
#include <stdlib.h>

/* Fa�a um algoritmo que calcule a 
media de 4 n�meros reais e 
mostre o resultado */

int main(int argc, char *argv[]) {
	float a, b, c, d, media;
	//ENTRADA
	printf("Informe um valor para a: ");
	scanf("%f", &a);
	printf("Informe um valor para b: ");
	scanf("%f", &b);
	printf("Informe um valor para c: ");
	scanf("%f", &c);
	printf("Informe um valor para d: ");
	scanf("%f", &d);	
	//PROCESSAMENTO
	media = (a+b+c+d)/4;	
	//SAIDA
	printf("Media = %f", media);
	
	return 0;
}
