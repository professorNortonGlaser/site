#include <stdio.h>
#include <stdlib.h>

/* Fa�a um algoritmo que leia a 
temperatura em graus Celsius e converta para 
fahrenheit F = (9 * C + 160) / 5 */

int main(int argc, char *argv[]) {
	float c, f;
	//entrada
	printf("Informe a temperatura em celsius: ");
	scanf("%f", &c);
	//processamento
	f = (9*c+160) / 5;
	//saida
	printf("Em Fahrenheit = %f", f);
	
	return 0;
}
