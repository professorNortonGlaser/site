#include <stdio.h>
#include <stdlib.h>

//COMANDO DE ESCOLHA
//So funciona para variaveis to tipo caracter e inteiro
//Somente utiliza o operador de igualde


int main(int argc, char *argv[]) {
	int op;
	float n1, n2,r;
	
	printf("1-soma, 2-subtrair, 3-multiplica, 4-dividir:");
	scanf("%d", &op);
	
	printf("Escolha um numero para n1:");
	scanf("%f", &n1);
	
	printf("Escolha um numero para n2:");
	scanf("%f", &n2);
	
	switch(op){ //so aceita variaveis do tipo inteiro ou caracter
		case 1:{ //CASO VARIAVE OP == 1
			r = n1 + n2;
			break;
		}
		case 2:{ //CASO VARIAVE OP == 2
			r = n1 - n2; 
			break;
		}
		case 3: { //CASO VARIAVE OP == 3
			r = n1 * n2;
			break;
		}
		case 4: {  //CASO VARIAVE OP == 3
			r = n1 / n2;
			break;
		}
		default :{
			r = 0;
			printf("DIGITE UMA OPCAO CORRETA !");
		}
	}	
	printf("REsultato %f \n", r);
	
	
	return 0;
}
