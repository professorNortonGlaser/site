#include <stdio.h>
#include <stdlib.h>

/* Desenvolva um programa em C que:

Leia 4 (quatro) n�meros;
Calcule o quadrado de cada um;
Se o valor resultante do quadrado do terceiro for >= 1000, imprima-o e finalize;
Caso contr�rio, imprima os valores lidos e seus respectivos quadrados. */

int main(int argc, char *argv[]) {
	float a, b, c, d, qa, qb, qc, qd;
	
	printf("Informe um valor para A:");
	scanf("%f", &a);
	printf("Informe um valor para B:");
	scanf("%f", &b);	
	printf("Informe um valor para C:");
	scanf("%f", &c);
	printf("Informe um valor para D:");
	scanf("%f", &d);
	
	qa = a * a;
	qb = b * b;
	qc = c * c;
	qd = d * d;
	
	if(qc >= 1000)
	{
		printf("Quadrado do C %f = %f \n", c, qc);	
	} 
	else {
		printf("Quadrado do A %f = %f \n", a, qa);	
		printf("Quadrado do B %f = %f \n", b, qb);	
		printf("Quadrado do C %f = %f \n", c, qc);	
		printf("Quadrado do D %f = %f \n", d, qd);			
	}
	
	return 0;
}
