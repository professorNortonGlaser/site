

/**
 *
 * @author norton
 */
public class GeradorExtratos {
    public void geradorConta(Conta obj){
        System.out.println(obj.getTipo());
        System.out.println("Saldo atual="+ obj.getSaldo());
    } 
}
