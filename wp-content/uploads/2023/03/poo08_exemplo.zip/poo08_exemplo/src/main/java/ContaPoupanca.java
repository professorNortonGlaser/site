/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author norton
 */
public class ContaPoupanca implements Conta {
    private double saldo;


    public void deposita(double valor) {
        this.saldo = this.saldo + valor;
    }


    public void sacar(double valor) {
        this.saldo = this.saldo - valor;
    }


    public double getSaldo() {
        return this.saldo;
    }


    public String getTipo(){
        return "Conta Poupança";
    }

}
