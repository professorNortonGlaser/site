/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author norton
 */
public class ContaCorrente implements Conta {
    private double saldo;
    private double taxaOperacao = 0.45;

    public void deposita(double valor) {
        this.saldo = this.saldo + (valor - this.taxaOperacao);
    }

    public void sacar(double valor) {
        this.saldo = this.saldo - (valor - this.taxaOperacao);
    }

    public double getSaldo() {
        return this.saldo;
    }
    
    public String getTipo(){
        return "Conta Corrente";
    }
    
}
