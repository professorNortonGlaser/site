/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author norton
 */
public interface Conta {
    void deposita(double valor);
    void sacar(double valor);
    double getSaldo();
    String getTipo();
}
