#include <stdio.h>
#include <stdlib.h>

typedef struct x{
	char rua[50];
	int numero;
	int cep;
} endereco;

typedef struct y{
	int codigo;
	int cpf;
	endereco end;
} ficha;

ficha clientes[10];
int cont = 0;

void insere(ficha v[]){
	printf("Informe o codigo do novo cliente:");
	scanf("%i", &clientes[cont].codigo );
	printf("Informe o cpf do novo cliente:");
	scanf("%i", &clientes[cont].cpf );
	printf("Informe o cep do novo cliente:");
	scanf("%i", &clientes[cont].end.cep );
	cont++;
}

void mostrar(ficha v[]){
	int x;
	for(x=0; x<cont; x++){
		printf("Cliente=%i Cpf=%i \n",clientes[x].codigo,clientes[x].cpf);
	}
}

int main(int argc, char *argv[]) {
	insere(clientes);
	insere(clientes);
	insere(clientes);
	mostrar(clientes);
	
	return 0;
}
