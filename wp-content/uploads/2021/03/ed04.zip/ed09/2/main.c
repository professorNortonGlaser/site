#include <stdio.h>
#include <stdlib.h>



typedef struct x {
	char nome[30];
	char endereco[40];
	int telefone;
} pessoa;

void mudaNome(pessoa *p){
	printf("informe um nome:");
	scanf("%s", &p->nome);
}

int main(int argc, char *argv[]) {
	pessoa p1;
	p1.telefone =21344;
	mudaNome(&p1);
	printf("Pessoa 1 =%s", p1.nome);
	
	pessoa p2 = {"maria","rua x", 233};
	printf("Pessoa 2 =%s", p2.nome);
	return 0;
}
