#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
enum diaSemana {domingo, segunda, terca, quarta, quinta, sexta, sabado
};

typedef enum diaSemana dias;

int main(int argc, char *argv[]) {
	dias hoje = quinta; 
	
	if(hoje==quinta){
		printf("Hoje e quinta !");	
	} else {
		printf("Hoje e outro dia %i", hoje);
	}
	
	return 0;
}
