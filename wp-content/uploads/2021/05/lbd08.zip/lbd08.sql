create index IDX_PRODUTO_2 ON PRODUTO(nome);
select * from produto where lower(nome)='caneta';
drop index IDX_PRODUTO_2;

create view  vw_clientesNao as
select * from cliente where codigo
not in (select codigoCliente from pedido);

select * from vw_clientesNao;



create table auditlog(
    nomeTabela varchar(100),
    codigo  numeric,
    dataDelete date
);

create trigger trg_produto_delete before delete on produto 
for each row
begin
    insert into auditlog(nomeTabela, codigo, dataDelete)
    values('Produto', :old.codigo, sysdate);
end;
delete from produto where codigo=3;
select * from auditlog;