/*
create table categoria(
codigo numeric primary key,
nomeCategoria varchar(50)
);
insert into categoria(codigo, nomeCategoria) values(1, 'Materia de Escritorio');
insert into categoria(codigo, nomeCategoria) values(2, 'Acessorios');
insert into categoria(codigo, nomeCategoria) values(3, 'Eletronicos');
*/

select * from categoria;
select * from produto;

create table ProdutoCategoria(codigoProduto numeric, codigoCategoria numeric);
/*
insert into ProdutoCategoria(codigoProduto, codigoCategoria) values(1, 1);
insert into ProdutoCategoria(codigoProduto, codigoCategoria) values(2, 2);
insert into ProdutoCategoria(codigoProduto, codigoCategoria) values(2, 3);

insert into ProdutoCategoria(codigoProduto, codigoCategoria) values(3, 2);
insert into ProdutoCategoria(codigoProduto, codigoCategoria) values(3, 3);


insert into ProdutoCategoria(codigoProduto, codigoCategoria) values(4, 2);
insert into ProdutoCategoria(codigoProduto, codigoCategoria) values(4, 3);
*/

select * from ProdutoCategoria;

select p.codigo, p.nome, c.nomeCategoria 
from produto p inner join produtoCategoria pc on p.codigo=pc.codigoProduto
inner join categoria c on pc.codigoCategoria=c.codigo;

select p.codigo, p.nome, c.nomeCategoria 
from produto p , produtoCategoria pc, categoria c 
where  p.codigo=pc.codigoProduto and pc.codigoCategoria=c.codigo;
