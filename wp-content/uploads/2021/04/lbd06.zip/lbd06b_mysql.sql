insert into vendedor(vendedor, telefone,comissao)
values('Norton', '3444-43243',0.02);

alter table vendedor add codigoGerente bigint;

select * from vendedor;
update vendedor set codigoGerente=3 where codigo=2;

select * from vendedor where codigoGerente=3;

select * from vendedor where codigoGerente is null;

select v.vendedor, g.vendedor as nomeGerente
from vendedor v inner join vendedor g on
v.codigoGerente=g.codigo;

select nome from cliente
intersect
select nome from funcionario
