﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.Net.Mail;
using System.Net;

namespace pw14_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(IsPostBack==false) carregar();
        }

        private void carregar()
        {
            String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
            MySqlConnection con = new MySqlConnection(sc);
            con.Open();
            String sql = "select titulo from livro order by titulo";
            DataSet ds = new DataSet();
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql, con);
            conversor.Fill(ds, "todos");
            con.Close();
            cboProduto.DataSource = ds.Tables["todos"];
            cboProduto.DataTextField = "titulo";
            cboProduto.DataBind();
        }

        protected void enviarEmail(object sender, EventArgs e)
        {
            MailAddress de = new MailAddress("fatecpwAds2016@outlook.com");
            MailAddress para = new MailAddress("norton.glaser@fatec.sp.gov.br");
            MailMessage email = new MailMessage(de, para);
            email.Subject = "Orçamento de livros";
            email.IsBodyHtml = true;
            String corpo = "Nome:<b>" + txtNome.Value + "</b><br/>" +
                            "Telefone:<b>" + txtTelefone.Value + "</b><br/>" +
                            "Produto:<b>" + cboProduto.SelectedValue + "</b><br/>" +
                             "Qtd:<b>" + txtQtd.Value + "</b><br/>" +
                             "Mensagem:<b>" + mensagem.Value + "</b><br/>";
            email.Body = corpo;
            SmtpClient smtp = new SmtpClient("smtp-mail.outlook.com");
            try
            {
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.Credentials = new
                    NetworkCredential("fatecpwAds2016@outlook.com", "FreiJoao59");
                smtp.Send(email);
                lblMensagem.Text = "Email enviado com sucesso !";
            }
            catch
            {
                lblMensagem.Text = "Ocorreu um erro no envio de email !";
            }
        }

    }
}