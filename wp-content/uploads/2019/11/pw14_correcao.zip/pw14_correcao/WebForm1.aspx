﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw14_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>
        <h1>Orçamento</h1>
        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
                Nome:<input type="text" id="txtNome" runat="server" /><br />
                Telefone:<input type="text" id="txtTelefone" runat="server" /><br />
                Produto:<asp:DropDownList ID="cboProduto" runat="server"></asp:DropDownList><br />
                Qtd:<input type="text" id="txtQtd" runat="server" /><br />
                Mensagem:<textarea id="mensagem" runat="server" rows="5"></textarea><br />
                <asp:Button ID="Button1" runat="server" Text="Enviar" OnClick="enviarEmail" /><br /><br />
                <asp:Label ID="lblMensagem" runat="server" Text=""></asp:Label>
            </ContentTemplate>
        </asp:UpdatePanel>

        <asp:UpdateProgress ID="UpdateProgress1" runat="server">
         <ProgressTemplate>Enviando......</ProgressTemplate></asp:UpdateProgress>
    </div>
    </form>
</body>
</html>
