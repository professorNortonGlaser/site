<html>
	<head>
		<title>Fw12</title>
	</head>
	<body>
		<select id="usuarios">
			<?php montaLista(); ?>
		</select>
		<br/><br/>
		<table border="1">
		<tr><td>codigo</td><td>nome</td><td>email</td></tr>
		<?php montaTabela(); ?>
		</table>
		
		<form method="post" action="fw12.php">
		<input type="text" name="busca" />
		<input type="submit" name="b1"  value="Ok" />
		</form>
		<table border="1">
		<tr><td>codigo</td><td>nome</td><td>email</td></tr>
		<?php montaBusca(); ?>
		</table>
		
	</body></html>
<?php
function montaLista(){
	$con = new mysqli("localhost","root","","segna");
	$sql = "select nome from usuario order by nome";
	$resultado = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($resultado)){
		echo "<option>". $reg["nome"] ."</option>";
	}		
	$con->close();
}	
function montatabela(){
	$con = new mysqli("localhost","root","","segna");
	$sql = "select * from usuario order by codigo";
	$resultado = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($resultado)){
		echo "<tr><td>". $reg["codigo"] ."</td>";
		echo "<td>". $reg["nome"] ."</td>";
		echo "<td>". $reg["email"] ."</td></tr>";
	}		
	$con->close();
}	
function montaBusca(){
if(isset($_POST["b1"])){
	$con = new mysqli("localhost","root","","segna");
	$busca = $_POST["busca"];
	$sql = "select * from usuario where nome like '%$busca%' or email like '%$busca%' order by codigo";
	$resultado = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($resultado)){
		echo "<tr><td>". $reg["codigo"] ."</td>";
		echo "<td>". $reg["nome"] ."</td>";
		echo "<td>". $reg["email"] ."</td></tr>";
	}		
	$con->close();
}
}	
?>