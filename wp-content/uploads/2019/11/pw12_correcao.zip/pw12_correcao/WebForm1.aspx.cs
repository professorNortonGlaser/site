﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

namespace pw12_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            carregarTela();
        }
        private void carregarTela()
        {
            String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from livro order by titulo";
            DataSet ds = new DataSet();
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql, conexao);
            conversor.Fill(ds, "todos");
            sql = "select codigo, titulo from livro where valor <=50";
            MySqlDataAdapter conversor2 = new MySqlDataAdapter(sql, conexao);
            conversor2.Fill(ds, "promo");
            conexao.Close();

            GridView1.DataSource = ds.Tables["todos"];
            GridView1.DataBind();

            DropDownList1.DataSource = ds.Tables["promo"];
            DropDownList1.DataTextField = "titulo";
            DropDownList1.DataBind();

        }

    }
}