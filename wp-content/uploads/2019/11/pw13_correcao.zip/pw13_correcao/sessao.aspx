﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="sessao.aspx.cs" Inherits="pw13_correcao.sessao" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
      nome:<input type="text" id="txtNome" runat="server" /><br/>
        e-mail:<input type="text" id="txtEmail" runat="server" /><br/>
        telefone:<input type="text" id="txtTelefone" runat="server" /><br/>
        senha:<input type="password" id="txtSenha" runat="server" /><br/>
    </div>
    </form>
</body>
</html>
