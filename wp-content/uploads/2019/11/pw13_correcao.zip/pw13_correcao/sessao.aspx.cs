﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw13_correcao
{
    public partial class sessao : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                txtEmail.Value = Session["email"].ToString();
                txtNome.Value = Session["nome"].ToString();
                txtSenha.Value = Session["senha"].ToString();
                txtTelefone.Value = Session["telefone"].ToString();
            }

        }
    }
}