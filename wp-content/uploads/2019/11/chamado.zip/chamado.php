<html>
<head>
	<title>FW11 - CRUD</title>
</html>
<h1>Chamado</h1>
<form action="chamado.php" method="post">
codigo: <input type="text" name="codigo" id="codigo" />
<br/>
titulo: <input type="text" name="titulo" id="titulo" />
<br/>
descritivo: <textarea id="descritivo" name="descritivo" rows="5"></textarea> <br/>
prioridade: <select id="prior" name="prior"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select><br/>
status:<select id="stat" name="stat"><option value="1">Aberto</option><option value="2">Fechado</option>
<option value="3">Aberto</option></select><br/>
<input type="submit" name="b1" value="Inserir" />
<input type="submit" name="b2" value="Pesquisar" />
<input type="submit" name="b3" value="Alterar" />
<input type="submit" name="b4" value="Excluir" />
</form>
<?php
	if(isset($_POST["b1"])) inserir();
	if(isset($_POST["b2"])) pesquisar();
	if(isset($_POST["b3"])) alterar();
	if(isset($_POST["b4"])) excluir();	
?>
</body></html>
<?php
function inserir(){
	$con = new mysqli("localhost", "root","","segna");
	$titulo 	= $_POST["titulo"];
	$descritivo = $_POST["descritivo"];
	$prior 		= $_POST["prior"];
	$stat 		= $_POST["stat"];
	$sql = "insert into chamado(titulo, descritivo, prioridade, status) values('$titulo', '$descritivo', '$prior', '$stat')";
	mysqli_query($con, $sql);
	$con->close();
	echo "registro inserido com sucesso !";
}
function pesquisar(){
	$con = new mysqli("localhost", "root","","segna");
	$codigo = $_POST["codigo"];	
	$sql = "select * from chamado where codigo=$codigo";
	$resultado = mysqli_query($con, $sql);
	if($reg = mysqli_fetch_array($resultado)){
		echo "<script lang='javascript'>";
		echo "codigo.value='". $reg["codigo"] ."';";
		echo "titulo.value='". $reg["titulo"] ."';";
		echo "descritivo.value='". $reg["descritivo"] ."';";
		echo "prior.value='". $reg["prioridade"] ."';";
		echo "stat.value='". $reg["status"] ."';";
		echo "</script>";
	} else {
		echo "registro nao encontrado !";	
	}
	$con->close();
}
function alterar(){
	$con = new mysqli("localhost", "root","","segna");
	$codigo 	= $_POST["codigo"];
	$titulo 	= $_POST["titulo"];
	$descritivo = $_POST["descritivo"];
	$prior 		= $_POST["prior"];
	$stat 		= $_POST["stat"];
	$sql = "update chamado set titulo='$titulo', descritivo='$descritivo', prioridade='$prior', status='$stat' where codigo=$codigo";
	mysqli_query($con, $sql);
	$con->close();
	echo "registro alterado com sucesso !";
}
function excluir(){
	$con = new mysqli("localhost", "root","","segna");
	$codigo 	= $_POST["codigo"];
	$sql = "delete from chamado where codigo=$codigo";
	mysqli_query($con, $sql);
	$con->close();
	echo "registro removido com sucesso !";
}

?>
	