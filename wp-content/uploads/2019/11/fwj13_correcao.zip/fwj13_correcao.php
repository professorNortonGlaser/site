<html>
	<body>
		<table border="1">
			<tr>
				<td>Codigo</td>
				<td>nome</td>
				<td>Valor</td>
				<td>Qtd</td>
			</tr>
			<?php montaTabela(); ?>
		</table>
	</body>
</html>	
<?php
function montaTabela(){
	$con = new mysqli("localhost", "root","", "jogos");	
	$sql = "select * from produto order by nome";
	$resultado = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($resultado)){
		echo "<tr><td>". $reg["codigo"] ."</td><td>". $reg["nome"] ."</td><td>". $reg["valor"] ."</td><td>". $reg["qtd"] . "</td></tr>";
	}	
	$con->close();
}
?>