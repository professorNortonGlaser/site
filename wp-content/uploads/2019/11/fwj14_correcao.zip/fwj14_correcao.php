<html>
<body>
	<h1>Envio de email</h1>
	<form method="post" action="fwj14_correcao.php">
	nome:<input type="text" name="nome" /><br/>
	e-mail:<input type="text" name="email" /><br/>
	assunto:<input type="text" name="assunto" /><br/>
	texto:<textarea name="texto" rows="5"></textarea><br/>
	<input type="submit" value="Enviar" name="b1" />	
	</form>
	<?php if(isset($_POST["b1"])) enviarEmail(); ?>
</body>
</html>
<?php
function enviarEmail(){
	$para = "to:". $_POST["email"];
	$assunto = $_POST["assunto"];
	$mensagem = $_POST["nome"] ."<p>". 
				$_POST["texto"] ."</p>";
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= "from: teste<fatecpwAds2016@outlook.com>";
	
 

	mail($para, $assunto, $mensagem, $headers);
	echo "Email enviado com sucesso";	
}
?>	