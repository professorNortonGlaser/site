<html>
<head>
	<title>FWJ12 - CRUD</title>
</head>
<body>
	<h1>Produto</h1>
	<form method="post" action="produto.php">
codigo:
<input type="number" id="codigo" name="codigo" /><br/>
nome:
<input type="text" id="nome" name="nome" /><br/>
valor:
<input type="text" id="valor" name="valor" /><br/>
qtd:
<input type="number" id="qtd" name="qtd" /><br/>
<input type="submit" name="b1" value="inserir" />
<input type="submit" name="b2" value="pesquisar" />
<input type="submit" name="b3" value="alterar" />
<input type="submit" name="b4" value="excluir" />
</form>
<?php
	if(isset($_POST["b1"])) inserir();
	if(isset($_POST["b2"])) pesquisar();
	if(isset($_POST["b3"])) alterar();
	if(isset($_POST["b4"])) remover();
?> </body></html>
<?php
function inserir(){
	$con = new mysqli("localhost","root","","jogos");	
	$nome 	= $_POST["nome"];	
	$qtd 	= $_POST["qtd"];	
	$valor 	= $_POST["valor"];	
	$sql = "insert into produto(nome, qtd, valor) values('$nome','$qtd','$valor')";
	mysqli_query($con, $sql);
	$con->close();
	echo "Registro inserido com sucesso!";
}
function alterar(){
	$con = new mysqli("localhost","root","","jogos");	
	$nome 	= $_POST["nome"];	
	$qtd 	= $_POST["qtd"];	
	$valor 	= $_POST["valor"];	
	$codigo	= $_POST["codigo"];	
	$sql = "update produto set nome='$nome', qtd='$qtd', valor='$valor' where codigo=$codigo";
	mysqli_query($con, $sql);
	$con->close();
	echo "Registro alterado com sucesso!";
}
function remover(){
	$con = new mysqli("localhost","root","","jogos");		
	$codigo	= $_POST["codigo"];	
	$sql = "delete from produto where codigo=$codigo";
	mysqli_query($con, $sql);
	$con->close();
	echo "Registro removido com sucesso!";
}
function pesquisar(){
	$con = new mysqli("localhost","root","","jogos");		
	$codigo	= $_POST["codigo"];	
	$sql = "select * from produto where codigo=$codigo";
	$resultado = mysqli_query($con, $sql);
	if($reg = mysqli_fetch_array($resultado)){
		echo "<script lang='javascript'>";
		echo "codigo.value='". $reg["codigo"] ."';";
		echo "nome.value='". $reg["nome"] ."';";
		echo "valor.value='". $reg["valor"] ."';";
		echo "qtd.value='". $reg["qtd"] ."';";
		echo "</script>";
	} else {
		echo "registro não existe";		
	}
	$con->close();	
}

?>