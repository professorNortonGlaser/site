<html>
	<head>
		<title>Fwj10 - Correção</title>
	</head>
	<body>
	<h1>Tabuada</h1>
	
	<table border="1">
	<?php
		$numero = 13;
		for($i=1;$i<=10;$i++){	
			$prod = $i * $numero;
			echo "<tr><td>$i</td><td>x</td> <td>$numero</td><td>$prod</td></tr>";	
		}	
	?>
	</table>
</body>
</html>	
	
	