#include <stdio.h>
#include <stdlib.h>

/* 
A � Fa�a um algoritmo que implemente um la�o que leia X n�meros
 inteiros e identifique qual o menor o maior e a media, 
 quando o n�mero informado for zero, interrompa o la�o
  e exiba os valores.
*/

int main(int argc, char *argv[]) {
	int maior, menor, numero;
	int cont = 0;
	float media=0;
	//Fa�a enquanto 1...N
	do {
		printf("Informe um numero:");
		scanf("%d", &numero);
		if(numero!=0){
			media=media+numero;
			if(cont==0){ //vai entrar somente no primeiro intera��o
				menor = numero;
				maior = numero;	
			} else { //vai entrar da segunda ate x intera��es
				if(numero < menor){
					menor = numero;	
				}	
				if(numero > maior){
					maior = numero;
				}
			}
			cont++; // cont = cont + 1
		}		
	} while(numero!=0);
	media = media/cont;
	printf("Menor=%d, Maior=%d, media=%f", menor, maior, media);
	
	return 0;
}
