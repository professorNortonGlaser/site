#include <stdio.h>
#include <stdlib.h>

/* 
B- Reutilizando o algoritmo do caixa eletr�nico,
implemente um la�o fa�a enquanto que verifique se o usu�rio deseja continuar, 
caso a vari�vel coletada for igual 1 reinicie o la�o, mantendo o 
valor do saldo.
*/

int main(int argc, char *argv[]) {
	int op;
	int continua=1;
	float saldo = 1500;
	float valor;
	
	while(continua==1){	
		printf("1-Saldo, 2-Saque, 3-Deposito :");
		scanf("%d", &op);	
		switch(op){
			case 1:{
				printf("O seu saldo = %f", saldo);
				break;
			}	
			case 2:{
				printf("Informe o valor a ser sacado :");
				scanf("%f", &valor);	
				if(valor > saldo){
					printf("Saldo insuficiente %f", saldo);	
				} else {
					saldo = saldo - valor;	
					printf("Saque efetuado, saldo atual %f", saldo);	
				}		
				break;
			}
			case 3:{
				printf("Informe o valor a ser depositado :");
				scanf("%f", &valor);
				saldo = saldo + valor;
				printf("Deposito efetuado, saldo atual %f", saldo);	
				break;
			}
			default:{
				printf("Opcao invalida !");
				break;
			}		
		}			
		printf("\n\nDeseja continua 1-Sim 0-Nao:");
		scanf("%d", &continua);
		system("cls");
	}
	return 0;
}
