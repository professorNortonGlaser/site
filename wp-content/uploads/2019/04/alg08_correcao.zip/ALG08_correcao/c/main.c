#include <stdio.h>
#include <stdlib.h>

/* 
D- Fa�a um algoritmo que dado valor inteiro informado, calcule e exiba a tabuada do numero de 1 a 10
 */

int main(int argc, char *argv[]) {
	int numero, multiplo, x;
	
	printf("Informe um numero:");
	scanf("%d", &numero);
	
	for(x=1;x<=10;x++){
		multiplo = x * numero;
		printf("%d X %d = %d \n", x, numero, multiplo);	
	}
	
	return 0;
}
