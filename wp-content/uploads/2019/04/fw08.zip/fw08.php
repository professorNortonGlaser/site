<html>
<head>
	<title>Fw08 - Correção</title>
</head>
<body>
	<h1>Fw08</h1>
	<table border="1">
	<?php
		$x = 13;
		for($i=1;$i<=10;$i++){
			$p = $x * $i;
			echo "<tr><td>$x</td><td>x</td><td>$i</td><td>=</td><td>$p</td></tr>";	
		}
	?>	
	</table>
</body>
</html>