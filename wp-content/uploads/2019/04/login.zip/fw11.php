<html>
<body>
	<table border="1" align="center">
	<tr><td><b>Codigo</b></td>
		<td><b>Titulo</b></td>
		<td><b>Descritivo</b></td>
		<td><b>Prioridade</b></td>
		<td><b>Status</b></td></tr>
	<?php listaTodos(); ?>
	</table><br>
	<select id="abertos">
		<?php listaAbertos(); ?>
	</select>
</body>
</html>
<?php
session_start();
if(isset($_SESSION["codigo"])==false){
	header("location: login.php");
}
function listaTodos(){
	$con = new mysqli("localhost","root","","test");
	$sql = "select * from chamado order by status,prioridade";
	$resultado = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($resultado)){
		echo "<tr><td>". $reg["codigo"] ."</td>";
		echo "<td>". $reg["titulo"]  ."</td>";
		echo "<td>". $reg["descritivo"]  ."</td>";
		echo "<td>". $reg["prioridade"]  ."</td>";
		echo "<td>". $reg["status"]  ."</td></tr>";
	}	
	$con->close();
}
function listaAbertos(){
	$con = new mysqli("localhost","root","","test");
	$sql = "select * from chamado where status=1";
	$resultado = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($resultado)){
		echo "<option value='". $reg["codigo"] ."'>". $reg["titulo"]  ."</option>";
	}	
	$con->close();
}
?>