<?php
	if(isset($_POST["busca"])){
		$busca = $_POST["busca"];
		$con = new mysqli("localhost","root","","test");
		$sql = "select * from livro where titulo like '%$busca%'";
		$res = mysqli_query($con,$sql);
		while($reg = mysqli_fetch_array($res)){
			echo "<tr><td>". $reg["codigo"] . "</td>";
			echo "<td>". $reg["titulo"] . "</td>";
			echo "<td>". $reg["valor"] . "</td>";
			echo "<td>". $reg["qtd"] . "</td></tr>";
	
		}
		$con->close();
	}
?>