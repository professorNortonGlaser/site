﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="email.aspx.cs" Inherits="pw16.email" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <h1>Envio de Email<br />
        </h1>
        <asp:ScriptManager ID="ScriptManager1" runat="server">
        </asp:ScriptManager>
        <asp:UpdatePanel ID="UpdatePanel1" runat="server">
            <ContentTemplate>
                <br />
                Destinatario:<asp:TextBox ID="txtTo" runat="server"></asp:TextBox>
                <br />
                <br />
                Assunto:<asp:TextBox ID="txtSubject" runat="server"></asp:TextBox>
                <br />
                <br />
                Mensagem:<asp:TextBox ID="txtBody" runat="server" Height="78px" TextMode="MultiLine" Width="247px"></asp:TextBox>
<br />
<br />
                <asp:Button ID="Button1" runat="server" OnClick="enviarEmail" Text="Enviar" />
                <br />
                <br />
                <asp:Label ID="lblMensagem" runat="server" Text="Label"></asp:Label>
                <br />
                <br />
            </ContentTemplate>
        </asp:UpdatePanel>
        <asp:UpdateProgress ID="UpdateProgress1" runat="server">
            <ProgressTemplate>
                Aguarde....enviando o seu email!!!
            </ProgressTemplate>
        </asp:UpdateProgress>
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
