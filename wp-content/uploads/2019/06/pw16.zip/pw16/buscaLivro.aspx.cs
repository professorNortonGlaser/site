﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace pw16
{
    public partial class buscaLivro : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {
            String busca = Request["busca"];

            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from livro where titulo like '%" + busca + "%'";
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            MySqlDataReader registros = comando.ExecuteReader();
            while (registros.Read())
            {
                Response.Write("<tr><td>" + registros["codigo"] + "</td>");
                Response.Write("<td>" + registros["titulo"] + "</td>");
                Response.Write("<td>" + registros["valor"] + "</td>");
                Response.Write("<td>" + registros["qtd"] + "</td>");
                Response.Write("</tr>");
            }
            conexao.Close();
        }
    }
}