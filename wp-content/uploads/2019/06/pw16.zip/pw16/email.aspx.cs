﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Net;

namespace pw16
{
    public partial class email : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void enviarEmail(object sender, EventArgs e)
        {
            MailAddress from = new MailAddress("fatecpwAds2016@outlook.com");
            MailAddress to = new MailAddress(txtTo.Text);
            MailMessage email = new MailMessage();
            email.From = from;
            email.To.Add(to);
            email.Subject = txtSubject.Text;
            email.Body = txtBody.Text;
            SmtpClient smtp = new SmtpClient("smtp-mail.outlook.com");
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.Credentials = new
            NetworkCredential("fatecpwAds2016@outlook.com", "FreiJoao59");
            try
            {                
                smtp.Send(email);
                lblMensagem.Text = "Email enviado com sucesso !";
            }
            catch (Exception err)
            {
                lblMensagem.Text = "Ocorreu um erro ! " + err.Message;
            }
        }
    }
}