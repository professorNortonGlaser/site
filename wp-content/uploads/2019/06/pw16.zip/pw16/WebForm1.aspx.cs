﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw16
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CarregarSemAjax(object sender, EventArgs e)
        {
            //modo sincrono
            Label1.Text = dummyTest();
        }
        private String dummyTest()
        {
            String retorno = "";
            for (long x = 1; x < 9999999; x++)
            {
                retorno = x.ToString() + " " + DateTime.Now;
            }
            return retorno;
        }
        protected void comAjax(object sender, EventArgs e)
        {
            Label2.Text = dummyTest();
        }


    }
}