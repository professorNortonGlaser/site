#include <stdio.h>
#include <stdlib.h>

/* 
8- Crie um algoritmo onde ser� informado um valor inteiro inicial,  
e um la�o o usu�rio devera informar outro numero inteiro, o programa 
dever� responder se o numero atual e menor ou maior que o numero inicial 
informado, o la�o somente ser� interrompido quando o numero atual for 
igual ao n�mero anterior informado. Exiba quantas tentativas foram
 necess�rias para que o numero fosse descoberto.
 */

int main(int argc, char *argv[]) {
	int num1, num2, tentativas=0;
	
	printf("Informe um numero:");
	scanf("%d", &num1);
	system("cls");
	
	do{
		printf("Informe um numero:");
		scanf("%d", &num2);
		if(num1>num2){
			printf("Numero maior que %d \n", num2);	
		} else {
			if(num1<num2){
				printf("Numero menor que %d \n", num2);	
			}
		}		
		tentativas++;
	} while(num1!=num2);
	printf("\nO Total de Tentativas =%d", tentativas);
	return 0;
}
