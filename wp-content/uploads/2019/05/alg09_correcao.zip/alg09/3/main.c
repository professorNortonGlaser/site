#include <stdio.h>
#include <stdlib.h>

/* 
3- Fa�a um la�o que calcule a media de todos os n�meros informados, 
a condi��o de termino do la�o e quando for digitado ZERO
*/

int main(int argc, char *argv[]) {
	float numero, media=0, contador=0;
	//1 a N
	do{
		printf("Informe um numero:");
		scanf("%f", &numero);	
		if(numero != 0){
			media = media + numero; // media+=numero
			contador++; //contador = contador + 1	
		}				
	} while(numero !=0);
	if(contador > 0){
		media = media / contador; 
		printf("\nA media = %f ", media);
	}
	return 0;
}
