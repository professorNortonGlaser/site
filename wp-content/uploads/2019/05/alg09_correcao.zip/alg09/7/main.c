#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que conte de 1 a 100 e a cada m�ltiplo 
de 3 e 5 simultaneamente emita uma mensagem:  �M�ltiplo de 3 e 5�.
*/

int main(int argc, char *argv[]) {
	int x, resto3, resto5;
	
	for(x=1;x<=100;x++){
		resto3 = x % 3;
		resto5 = x % 5;	
		if(resto3==0 && resto5==0){
			printf("Multiplo de 3 e 5= %d \n", x);	
		}
	}
	
	return 0;
}
