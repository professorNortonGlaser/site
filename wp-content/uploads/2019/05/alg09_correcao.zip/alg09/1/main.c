#include <stdio.h>
#include <stdlib.h>

/* 
1- Dado o algoritmo abaixo escrito em C :
int i, a, b;
for(i=0; i<20; i++)
{
   scanf("%d",&a);
   scanf("%d",&b);
   r = a + b;
   printf("%d\n", r);
}
a- reescreva com o la�o enquanto fa�a (while)
b- reescreva com o la�o fa�a enquanto (do while)
*/

int main(int argc, char *argv[]) {
	int i, a, b, r;
	for(i=0; i<20; i++)
	{
   		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("%d\n", r);
	}
	//a- reescreva com o la�o enquanto fa�a (while)
	i = 0;
	while(i<20){
		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("%d\n", r);
		i++; //i = i + 1 
	}
	//b- reescreva com o la�o fa�a enquanto (do while)
	i =0;
	do{
		scanf("%d",&a);
   		scanf("%d",&b);
   		r = a + b;
   		printf("%d\n", r);
		i++; //i = i + 1 		
	} while(i<20);
	
	
	
	return 0;
}
