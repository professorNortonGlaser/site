#include <stdio.h>
#include <stdlib.h>

/* 
5- Crie um la�o e verifique qual a maior sequencia de n�meros
pares informados, o la�o fara 10 itera��es.
Exe:   1, 2,3,4,6,8,5,3,2,5,8,4,0   Sequencia :4,6,8   
O programa vai retornar: 3
*/

int main(int argc, char *argv[]) {
	int i, seq=0, maiorSeq=0, num, resto2; 
	for(i=0; i<10; i++){
		printf("Informe um numero:");
		scanf("%d", &num);
		resto2= num % 2;	
		if(resto2==0){
			seq++;	
			if(seq>maiorSeq){
				maiorSeq = seq;
			}				
		} else {
			seq=0;	
		}		
	}
	printf("A maior sequencia par = %d", maiorSeq);
	
	return 0;
}
