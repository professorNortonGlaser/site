#include <stdio.h>
#include <stdlib.h>

/* 
4- fa�a um la�o �fa�a at� com 10 intera��es, 
verifique quantas vezes os n�meros m�ltiplos de 2 e de 3 s�o informados
*/

int main(int argc, char *argv[]) {
	int numero, x, resto2, resto3, total=0;
	for(x=0;x<10;x++){
		printf("Informe um numero:");
		scanf("%d",&numero);
		resto2 = numero%2;
		resto3 = numero%3;
		if(resto2==0 && resto3==0){
			total++;	
		}
	}
	printf("Total de numeros multiplos de 2 e 3=%d", total);
	return 0;
}
