<html>
<head>
<title>FWJ11-login</title>
<body>

<h1>Login</h1>
	<form method="post" action ="login.php">
	email:
	<input type="text" id="email" name="email" /><br/>
	senha:
	<input type="password" id="senha" name="senha" /><br/>
	<input type="submit" name="bt1" value="Entrar" />
</form>
<?php 
	if(isset($_POST["bt1"])){
		$e = $_POST["email"];
		$s = $_POST["senha"];	
		if($e =="professor@norton.net.br" && $s == "123456"){
			header("location: calculadora.php");
		} else {
			echo "<h3>Email ou senha invalidos!</h3>";
		}		
	}
?>
</body></html>
