﻿<!doctype html>
<html>
<head>
<title>FWJ11 - Correção</title>
</head>
<body>
	<form method="post" action="calculadora.php">
	N1:<input type="number" id="n1" name="n1" /> 
	<br/>
	N2:<input type="number" id="n2" name="n2" /> 
	<br/>
	<input type="submit" value="+" name="bt1" />	
	<input type="submit" value="-" name="bt2" />	
	<input type="submit" value="*" name="bt3" />	
	<input type="submit" value="/" name="bt4" />	
	<input type="submit" value="T" name="bt5" />	
	</form>
	<?php
		if(isset($_POST["bt1"])) 
		{
			$a = $_POST["n1"];
			$b = $_POST["n2"];
			$r = $a + $b;
			echo "<h3>A soma = $r</h3>";	
		}		
		if(isset($_POST["bt2"])) 
		{
			$a = $_POST["n1"];
			$b = $_POST["n2"];
			$r = $a - $b;
			echo "<h3>A subtração = $r</h3>";	
		}		
		if(isset($_POST["bt3"])) 
		{
			$a = $_POST["n1"];
			$b = $_POST["n2"];
			$r = $a * $b;
			echo "<h3>A multiplicação = $r</h3>";	
		}		
		if(isset($_POST["bt4"])) 
		{
			$a = $_POST["n1"];
			$b = $_POST["n2"];
			$r = $a / $b;
			echo "<h3>A divisão = $r</h3>";	
		}		
		if(isset($_POST["bt5"])) 
		{
			$a = $_POST["n1"];
			echo "<ul>";
			for($i=1;$i<=10;$i++){
				$p = $a + $i;
				echo "<li>$i X $a = $p</li>";	
			}
			echo "</ul>";
		}		
	?>
</body>
</html>	