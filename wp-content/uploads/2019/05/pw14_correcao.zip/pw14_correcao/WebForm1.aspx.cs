﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

namespace pw14_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {
            carregar();
        }

        private void carregar()
        {
            DataSet ds = new DataSet();
            MySqlConnection conexao = new MySqlConnection(sc);
            conexao.Open();
            String sql = "select * from livro order by titulo";
            MySqlDataAdapter conversor = new MySqlDataAdapter(sql, conexao);
            conversor.Fill(ds, "todosLivros");
            sql = "select * from livro where valor <=50";
            MySqlDataAdapter conversor2 = new MySqlDataAdapter(sql, conexao);
            conversor2.Fill(ds, "livroPromo");
            conexao.Close();

            GridView1.DataSource = ds.Tables["todosLivros"];
            GridView1.DataBind();

            DropDownList1.DataSource = ds.Tables["livroPromo"];
            DropDownList1.DataValueField = "codigo";
            DropDownList1.DataTextField = "titulo";
            DropDownList1.DataBind();

        }
    }
}