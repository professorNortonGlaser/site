#include <stdio.h>
#include <stdlib.h>

/* 
1- Crie um programa que controle uma lista de inscritos em um 
vestibular, armazene em uma matriz 10�3 os seguintes dados: 
primeira coluna : cpf do inscrito , 
segunda coluna: idade do inscrito, 
terceira coluna: curso escolhido 1-ADS 2-GECOM 3-Eventos 4-RH

somente insira a linha da matriz caso o CPF n�o tenha sido 
cadastrado anteriormente
Exiba ao  final a quantidade de inscritos de cada curso
Mostre a media de idade dos inscritos
Caso ja exista um cpf, mostre a mensagem CPF ja cadastrado 
registro n�o inserido
 */

int main(int argc, char *argv[]) {
	int inscritos[10][3];
	int totais[4];
	int x,y, cpf, achou;	
	float mediaIdade=0;
	
	for(x=0;x<4;x++) totais[x]=0;
	
	for(x=0;x<10;x++){
		do{		
			achou = 0;
			printf("Informe o seu CPF:");
			scanf("%d", &cpf);
			for(y=0;y<x; y++){
				if(cpf==inscritos[y][0]){
					printf("CPF ja cadastrado registro nao inserido\n");	
					achou=1;
				}	
			}						
		} while(achou==1);
		inscritos[x][0] = cpf;
		printf("Informe a sua idade:");
		scanf("%d", &inscritos[x][1]);
		printf("Informe o curso 1-ADS 2-GECOM 3-Eventos 4-RH:");
		scanf("%d", &inscritos[x][2]);
	}
	for(x=0;x<10;x++){
		mediaIdade += inscritos[x][1];
		totais[inscritos[x][2]-1]++;		
	}
	mediaIdade = mediaIdade / 10;
	printf("A media de idade= %f \n", mediaIdade);
	printf("ADS=%d, GECOM=%d, Eventos=%d, RH=%d", totais[0], totais[1],totais[2],totais[3]);
	
	return 0;
}
