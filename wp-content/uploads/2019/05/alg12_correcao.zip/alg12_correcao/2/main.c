#include <stdio.h>
#include <stdlib.h>

/* 
2-Crie uma tabela de um campeonato de futebol, com 10 times 
e 4 colunas

Na coluna 0 e o total de vitorias (multiplique por 3 pontos)
Na coluna 1 o total de empates (multiplique por 1 ponto)
Na coluna 2 o total de derrotas (multiplique por 0 pontos)
Na coluna 3 , calcule o total de pontos
Mostre ao final, o tr�s primeiros colocados da tabela
*/

int main(int argc, char *argv[]) {
	int times[4][4];
	int x,y, maior, ultimo=0, time;
	for(x=0; x<4; x++){
		printf("Informe total vitorias time[%d]:", x);
		scanf("%d", &times[x][0]);	
		printf("Informe total de empates time[%d]:", x);
		scanf("%d", &times[x][1]);
		printf("Informe total derrotas time[%d]:", x);
		scanf("%d", &times[x][2]);
		times[x][3]=(times[x][0]*3)+times[x][1];
	}
	
	for(x=0; x<4; x++){	//posi��o classificatoria
		maior = 0;	
		for(y=0; y<4; y++){
			if(ultimo==0 || times[y][3]<ultimo){
				if(maior<times[y][3]) {
					maior =times[y][3];
					time  = y; 	
				}						
			}
		}
		ultimo = maior;
		printf("%d=>%d \n", time, maior);
	}
	
	/*
		15
		20
		10
		 5
	*/
	
	return 0;
}
