<html>
<body>
	<table border="1" align="center">
	<tr><td><b>Codigo</b></td>
		<td><b>Titulo</b></td>
		<td><b>Descritivo</b></td>
		<td><b>Prioridade</b></td>
		<td><b>Status</b></td></tr>
	<?php listaTodos(); ?>
	</table>
</body>
</html>
<?php
function listaTodos(){
	$con = new mysqli("localhost","root","","test");
	$sql = "select * from chamado order by status,prioridade";
	$resultado = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($resultado)){
		echo "<tr><td>". $reg["codigo"] ."</td>";
		echo "<td>". $reg["titulo"]  ."</td>";
		echo "<td>". $reg["descritivo"]  ."</td>";
		echo "<td>". $reg["prioridade"]  ."</td>";
		echo "<td>". $reg["status"]  ."</td></tr>";
	}	
	$con->close();
}
?>