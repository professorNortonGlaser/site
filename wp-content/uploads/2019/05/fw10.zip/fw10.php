<html>
<head><title>crud - correção</title></head>
<body>
<h1>Crud - Chamado</h1>
<form method="post" action="fw10.php">
<br/>codigo:
<input type="text" id="co" name="codigo" />
<br>titulo:
<input type="text" id="ti" name="titulo" />
<br>descritivo:
<textarea id="de" name="descritivo"></textarea>
<br>prioridade:
<select id="pr" name="prioridade">
<option value="1">Baixa</option>
<option value="2">Normal</option>
<option value="3">Urgente</option>
<option value="4">Critivo</option>
</select>
<br/>status:
<select id="st" name="status">
<option value="1">Aberto</option>
<option value="2">Fechado</option>
<option value="3">Cancelado</option>
</select><br/>
<input type="submit" value="inserir" name="b1" />
<input type="submit" value="pesquisar" name="b2" />
<input type="submit" value="alterar" name="b3" />
<input type="submit" value="excluir" name="b4" />
</form>
<?php
$con = new mysqli("localhost","root","","pweb");
if(isset($_POST["b1"])){
	$titulo 	= $_POST["titulo"];
	$descritivo	= $_POST["descritivo"]; 	
	$prioridade = $_POST["prioridade"];
	$status		= $_POST["status"];
	$sql = "insert into chamado(titulo,descritivo, prioridade, status) values('$titulo', '$descritivo','$prioridade', '$status')";
	mysqli_query($con, $sql);
	echo "registro inserido com sucesso !";
}
if(isset($_POST["b2"])){
	$codigo = $_POST["codigo"];
	$sql = "select * from chamado where codigo=$codigo";
	$res = mysqli_query($con, $sql);
	if($reg = mysqli_fetch_array($res)){
		$ti	= $reg["titulo"];
		$de	= $reg["descritivo"]; 	
		$pr = $reg["prioridade"];
		$st	= $reg["status"];
		echo "<script lang='javascript'>";
		echo "ti.value='$ti';de.value='$de'; pr.value='$pr';st.value='$st'; co.value='$codigo';</script>";
	} else {
		echo "registro não econtrado !";
	}
}
if(isset($_POST["b3"])){
	$codigo 	= $_POST["codigo"];
	$titulo 	= $_POST["titulo"];
	$descritivo	= $_POST["descritivo"]; 	
	$prioridade = $_POST["prioridade"];
	$status		= $_POST["status"];
	$sql = "update chamado set titulo='$titulo',descritivo='$descritivo', prioridade='$prioridade', status='$status' where codigo=$codigo";
	mysqli_query($con, $sql);
	echo "registro alterado com sucesso !";
}
if(isset($_POST["b4"])){
	$codigo 	= $_POST["codigo"];
	$sql = "delete from chamado where codigo=$codigo";
	mysqli_query($con, $sql);
	echo "registro removido com sucesso !";
}
$con->close();
?>
</body>
</html>


