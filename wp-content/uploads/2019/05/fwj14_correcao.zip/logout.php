<?php
	session_start();
	if(isset($_SESSION["nome"])){
		unset($_SESSION["nome"]);
		unset($_SESSION["codigo"]);		
	}
	header("location: login.php");
?>