<html>
<head>
	<title>FWJ - Correção</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
<div class="container">
<h1>Produtos</h1>
<?php autenticar(); ?>
<table border="1" align="center" class="table table-striped">
<tr><td><b>Codigo</b></td>
	<td><b>Nome</b></td>
	<td><b>Valor</b></td>
	<td><b>Qtd</b></td></tr>		
<?php mostraListra(); ?>
</table>
</div>
</body>
</html>	
<?php
function mostraListra(){
	$con = new mysqli("localhost","root","","pweb");
	$sql = "select * from produto order by nome";
	$resultado = mysqli_query($con, $sql);
	while($reg = mysqli_fetch_array($resultado)){
		echo "<tr><td>". $reg["codigo"] ."</td>";
		echo "<td>". $reg["nome"] ."</td>";
		echo "<td>". $reg["valor"] ."</td>";
		echo "<td>". $reg["qtd"] ."</td></tr>";
	}
	$con->close();
}

function autenticar(){
	session_start();
	if(isset($_SESSION["nome"])){
		echo "Ola, ".$_SESSION["nome"];
		echo "<a href='logout.php'>,sair</a>";	
	} else {
		header("location: login.php");
	}
}
?>