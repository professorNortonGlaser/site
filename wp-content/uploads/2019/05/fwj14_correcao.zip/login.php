<html>
<body>
<h1>Login</h1>
<?php validaLogin(); ?>
<form method="post" action="login.php">
email:
<input type="text" name="email" id="email" /> <br/>
senha:
<input type="password" name="senha" id="senha" />
<br/> 
<input type="submit" name="b1" value="entrar" />
</form>
</body></html>
<?php
function validaLogin(){
	if(isset($_POST["b1"]))	{
		$con = new mysqli("localhost","root","","pweb");
		$email	= $_POST["email"];
		$senha	= $_POST["senha"];
		$sql = "select codigo, nome from usuario where email='$email' and senha=md5('$senha')";
		$resultado = mysqli_query($con, $sql);	
		if($reg = mysqli_fetch_array($resultado)){
			session_start();
			$_SESSION["codigo"] = $reg["codigo"];
			$_SESSION["nome"] = $reg["nome"];
			header("location: fwj14.php");
		} else {
			echo "email ou senha invalidos !";
		}
		$con->close();
	}
}
?>