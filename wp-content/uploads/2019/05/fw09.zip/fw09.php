﻿<html>
<head>
	<title>Fw09 - Correção</title>
</head>
<body>
<h1>Calculadora</h1>
<form method="post" action="fw09.php">
N1:<input type="text" id="n1" name="n1" /><br/>
N2:<input type="text" id="n2" name="n2" /><br/>
<input type="submit" name="b1" value="+" />
<input type="submit" name="b2" value="-" />
<input type="submit" name="b3" value="*" />
<input type="submit" name="b4" value="/" />
<input type="submit" name="b5" value="T" />
</form>
<?php
if(isset($_POST["b1"])){
	$a = $_POST["n1"];
	$b = $_POST["n2"];	
	$c = $a+$b;
	echo "<h3>A soma=$c</h3>";
}
if(isset($_POST["b2"])){
	$a = $_POST["n1"];
	$b = $_POST["n2"];	
	$c = $a-$b;
	echo "<h3>A subtração=$c</h3>";
}
if(isset($_POST["b3"])){
	$a = $_POST["n1"];
	$b = $_POST["n2"];	
	$c = $a*$b;
	echo "<h3>A multiplicação=$c</h3>";
}
if(isset($_POST["b4"])){
	$a = $_POST["n1"];
	$b = $_POST["n2"];	
	$c = $a/$b;
	echo "<h3>A divisão=$c</h3>";
}
if(isset($_POST["b5"])){
	$a = $_POST["n1"];
	echo "<ul>";
	for($x=1;$x<=10;$x++){	
		$c = $a*$x;
		echo "<li>$a X $x = $c</li>";
	}
	echo "</ul>";
}
?>
</body></html>