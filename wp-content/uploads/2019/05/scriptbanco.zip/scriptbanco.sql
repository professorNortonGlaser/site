create database pweb;

use pweb;

create table usuario(
codigo bigint primary key 
auto_increment, 
nome varchar(100), 
email varchar(100) 
);

insert into usuario(nome,email) values('maria','m@m.com');
insert into usuario(nome,email)  values('ana','a@m.com');
insert into usuario(nome,email)  values('joão','j@m.com');
insert into usuario(nome,email)  values('jose','j@j.com');
