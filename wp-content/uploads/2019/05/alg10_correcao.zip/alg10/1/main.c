#include <stdio.h>
#include <stdlib.h>

/* 
a- Fa�a um algoritmo que armazene um vetor de inteiros de 20 posi��es, 
identifique  o percentual de n�meros impares e de n�meros pares informados.
*/

int main(int argc, char *argv[]) {
	int numeros[20];
	int x, resto2;
	float percPar=0, percImpar=0;
	// 0..19 indice
	for(x=0; x<20; x++){
		printf("Informe um valor do indice[%d]:", x);
		scanf("%d",&numeros[x]);	
		resto2 =  numeros[x] % 2; //MODULO DE 2 - RESTO DA DIVISAO INTEIRA
		if(resto2==0){
			percPar++; //percPar = percPar + 1;	
		} else {
			percImpar++; // percImpar = percImpar+1
		}		
	} 
	percPar = (percPar/20) * 100;
	percImpar = (percImpar/20) * 100;
	printf("Pares %f, Impares %f", percPar, percImpar);
	
	return 0;
}
