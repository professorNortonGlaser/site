#include <stdio.h>
#include <stdlib.h>

/* 
c � fa�a um algoritmo que implemente um vetor de 20 posi��es,
leia as 20 posi��es e identifique em um novo la�o, 
qual o maior e menor numero informado e 
qual a media dos n�meros informados.
*/

int main(int argc, char *argv[]) {
	float numeros[20], maior, menor, media=0;
	int i;
	
	for(i=0;i<20;i++){
		printf("Informe um valor para o indice[%d]",i);
		scanf("%f", &numeros[i]);	
	}
	for(i=0;i<20;i++){
		if(i==0){
			menor = numeros[i];
			maior = numeros[i];
		} else {
			if(numeros[i]<menor){
				menor = numeros[i];	
			} 
			if(numeros[i]>maior){
				maior = numeros[i];
			}
		}
		media+=numeros[i]; // media = media + numeros[i]
	}
	media = media / 20;
	printf("Menor=%f, maior=%f, Media=%f", menor, maior, media);
	
	return 0;
}
