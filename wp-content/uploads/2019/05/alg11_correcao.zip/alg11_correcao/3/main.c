#include <stdio.h>
#include <stdlib.h>

/* 
3 � Crie um programa que armazene em uma matriz 10�3 
em cada uma das colunas armazene o tamanho de uma aresta 
de um triangulo, ao final exiba o percentual de 
tri�ngulos isoceles, equil�teros e escalenos
*/

int main(int argc, char *argv[]) {
	float tri[10][3], iso=0, equ=0, esc=0;
	int x;
	
	for(x=0;x<10;x++){
		printf("Informe a aresta 1 do triangulo[%d]:",x);
		scanf("%f",&tri[x][0]);	
		printf("Informe a aresta 2 do triangulo[%d]:",x);
		scanf("%f",&tri[x][1]);	
		printf("Informe a aresta 3 do triangulo[%d]:",x);
		scanf("%f",&tri[x][2]);	
		
		if(tri[x][0]==tri[x][1] && tri[x][1]==tri[x][2]){
			equ++;	
		} else {
			if(tri[x][0]==tri[x][1] || tri[x][1]==tri[x][2]
			|| tri[x][0]==tri[x][2]){
				iso++;
			} else {
				esc++;	
			}
		}		
	}
	equ = (equ/10)*100;
	iso = (iso/10)*100;
	esc = (esc/10)*100;
	printf("O percentual: Equ=%f, Iso=%f, Esc=%f",equ,iso,esc);
	
	
	return 0;
}
