#include <stdio.h>
#include <stdlib.h>

/* 
1 � Construa um programa em C que utiliza uma matriz 10�3 que armazene 
as  temperaturas m�xima e minima do dia, 
assim como a media de temperatura na ultima coluna.  
Crie um menu de escolha que ofere�a as seguintes informa��es:
temperatura minima de todos os dias.
temperatura m�xima de todos os dias.
maior varia��o de temperatura de todos os dias.
Sair do programa.
*/

int main(int argc, char *argv[]) {
	float temp[10][3];
	float maior, menor, var, auxVar;
	int x; //0-menor 1-maior 2-media
	for(x=0;x<10;x++){
		printf("Informe a temp minima do dia[%d] :",x);
		scanf("%f", &temp[x][0]);	
		printf("Informe a temp maxima do dia[%d] :",x);
		scanf("%f", &temp[x][1]);	
		temp[x][2] = (temp[x][1]+temp[x][0])/2;
		auxVar = temp[x][1] - temp[x][0];
		if(x==0){
			menor = temp[x][0];
			maior = temp[x][1];	
			var   = auxVar;
		} else {
			if(temp[x][0] < menor) menor = temp[x][0];			
			if(temp[x][1] > maior) maior = temp[x][1];
			if(auxVar > var) var = auxVar;
		} 
	}
	do{  //1..N		
		printf("1-minima de todos os dias.\n");
		printf("2-maxima de todos os dias.\n");
		printf("3-variacao de temperatura.\n");
		printf("4-Sair do programa.\n");
		scanf("%d", &x);		
		switch(x){
			case 1:{
				printf("Minima=%f \n", menor);
				break;
			}	
			case 2:{
				printf("Maxima=%f \n", maior);
				break;
			}
			case 3:{
				printf("Variacao=%f \n", var);
				break;
			}
			default:{
				break;
			}
		}		
	} while(x!=4);
	
	return 0;
}
