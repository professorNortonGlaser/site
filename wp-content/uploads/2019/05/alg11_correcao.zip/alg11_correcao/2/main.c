#include <stdio.h>
#include <stdlib.h>

/* 
2 � Armazene em uma matriz 10�5 o resultado de uma prova de 
alternativas:

a � coluna 0
b � coluna 1
c � coluna 2
d � coluna 3
e � coluna 4
Exemplo da resposta da primeira quest�o com a alternativa C:

prova[0][0]=0 ; 
prova[0][1]=0; 
prova[0][2]=1;
prova[0][3]=0;
prova[0][4]=0;

Com um gabarito j� definido e armazenado em uma matriz, 
verifique a nota obtida pelo aluno
 */

int main(int argc, char *argv[]) {
	int prova[10][5], gabarito[10][5];
	int nota=0, alternativa, x, y;
	int a=0, b=1, c=2, d=3, e=4;
	for(x=0;x<10;x++){
		for(y=0;y<4;y++){
			gabarito[x][y]=0;	
			prova[x][y]=0;	
		}
	}
	gabarito[0][a]=1;
	gabarito[1][e]=1;
	gabarito[2][c]=1;
	gabarito[3][b]=1;
	gabarito[4][d]=1;
	gabarito[5][a]=1;
	gabarito[6][d]=1;
	gabarito[7][d]=1;
	gabarito[8][b]=1;
	gabarito[9][b]=1;
	// 0 0 0 0 1
	// 0 0 0 1 0
	for(x=0;x<10;x++){
		printf("Informe a resposta da questao[%d], ",x);	
		printf("a=0,b=1,c=2,d=3,e=4:");
		scanf("%d", &alternativa);
		prova[x][alternativa] = 1;
		if(gabarito[x][alternativa]==1){
			nota++;	
		}		
		system("cls");
	}
	printf("Sua nota foi: %d \n", nota);
	for(x=0;x<10;x++){
		printf("\n %d = ", x);
		for(y=0;y<4;y++){
			printf("%d ", gabarito[x][y]);
		}		
	}
	return 0;
}
