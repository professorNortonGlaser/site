<html>
<head>
<title>Correção fwj13</title>
</head>
<body>
<h1>Produto</h1>
<form method="post" action="fwj13.php">
codigo:
<input type="text" id="codigo" name="codigo"/>
<br/>nome:
<input type="text" id="nome" name="nome"/>
<br/>valor:
<input type="text" id="valor" name="valor"/>
<br/>qtd:
<input type="text" id="qtd" name="qtd"/>
<br/>
<input type="submit" name="b1" value="Inserir" />
<input type="submit" name="b2" value="Pesquisar" />
<input type="submit" name="b3" value="Alterar" />
<input type="submit" name="b4" value="Excluir" />
</form>
<?php
$con = new mysqli("localhost","root","","pweb");
if(isset($_POST["b1"])){
	$nome  = $_POST["nome"];
	$valor = $_POST["valor"];
	$qtd   = $_POST["qtd"]; 
	$sql = "insert into produto(nome, valor,qtd) values('$nome','$valor','$qtd')";
	mysqli_query($con, $sql);
	echo "<h3>Registro inserido!</h3>";
}
if(isset($_POST["b2"])){
	$codigo = $_POST["codigo"];
	$sql = "select * from produto where codigo=$codigo";
	$res = mysqli_query($con, $sql);
	if($reg = mysqli_fetch_array($res)){
		$nome  = $reg["nome"];
		$valor = $reg["valor"];
		$qtd   = $reg["qtd"]; 
		echo "<script lang='javascript'>";
		echo "codigo.value='$codigo';";
		echo "nome.value='$nome';";
		echo "valor.value='$valor';";
		echo "qtd.value='$qtd';";
		echo "</script>";
	} else {
		echo "<h3>Registro não existe!</h3>";
	}
}
if(isset($_POST["b3"])){
	$codigo = $_POST["codigo"];
	$nome  = $_POST["nome"];
	$valor = $_POST["valor"];
	$qtd   = $_POST["qtd"]; 
	$sql = "update produto set nome='$nome', valor='$valor',qtd='$qtd' where codigo=$codigo";
	mysqli_query($con, $sql);
	echo "<h3>Registro alterado!</h3>";
}
if(isset($_POST["b4"])){
	$codigo = $_POST["codigo"];	
	$sql = "delete from produto where codigo=$codigo";
	mysqli_query($con, $sql);
	echo "<h3>Registro removido!</h3>";
}

$con->close();
?>


