<html>
<body>
<?php
$para = "to:norton.glaser@fatec.sp.gov.br";
$assunto = "teste de email";
$mensagem = "Teste sexta 31/05 SCS";
$header = "MIME-Version: 1.0\r\n";
$header .= "from: teste<fatecpwAds2016@outlook.com>";

mail($para, $assunto, $mensagem, $header);
echo "Email enviado com sucesso";

?>
</body>
</html>
