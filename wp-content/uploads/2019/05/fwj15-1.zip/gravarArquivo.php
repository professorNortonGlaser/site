<html>
<body>
	<?php
		$name = 'arquivo.txt';
		$datahora=date('Y-m-d h:i:s');
		$texto = "Boa noite $datahora ". PHP_EOL ;
		$file = fopen($name,'a');
		fwrite($file, $texto);
		fclose($file);	
		echo "Arquivo salvo";
	?>
</body>
</html>	
	
	