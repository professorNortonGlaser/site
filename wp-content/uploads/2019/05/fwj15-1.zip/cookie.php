﻿<html>
<head>
<title>Teste de Cookie</title>
</head>
<body>
<?php gravaCookie(); ?>
Ola, <?php leCookie(); ?><bR><br>
<form action="cookie.php" method="post">
Se você não é esta pessoa acima, qual o seu nome:<br/>
<input type="text" name="nome" id="nome" /><br/>
<input type="submit" value="ok" name="b1" />
</form>
</body></html>
<?php
function gravaCookie(){
	if(isset($_POST["b1"])){
		$nome = $_POST["nome"];
		setcookie("nomeUsuario",$nome);
	}
}
function leCookie(){
	if(isset($_COOKIE["nomeUsuario"])){
		echo $_COOKIE["nomeUsuario"];
		}
}
?>