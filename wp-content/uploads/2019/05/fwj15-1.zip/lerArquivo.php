<html>
<body>
	<?php
		$name = 'arquivo.txt';		
		$file = fopen($name,'r');
		while(!feof($file)){
			$linha = fgets($file, 1024);
			echo "$linha<br/>";
		}
		fclose($file);		
	?>
</body>
</html>	
	