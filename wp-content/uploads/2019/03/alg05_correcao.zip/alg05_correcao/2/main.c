#include <stdio.h>
#include <stdlib.h>

/* 
Informe dois n�meros reais e um n�mero inteiro que represente 
a opera��o matem�tica a ser realizada 
(1-soma, 2-subtra��o, 3- multiplica��o, 4-divis�o) 
utilize o comando sele��o aninhado e exiba o resultado da opera��o 
matem�tica escolhida.
*/

int main(int argc, char *argv[]) {
	float n1, n2, resultado=0;
	int op;
	printf("1-soma, 2-subtrair, 3- multiplicar, 4-dividir:");
	scanf("%d", &op);
	printf("Informe o valor para n1:");
	scanf("%f", &n1);
	printf("Informe o valor para n2:");
	scanf("%f", &n2);
	if(op==1){ 
		resultado = n1+n2;	
	} else {
		if(op==2){
			resultado = n1 - n2;	
		} else {
			if(op==3){
				resultado = n1 *n2;	
			} else {
				if(op==4){
					resultado = n1 / n2;	
				} else {
					printf("Operacao invalida !!!");
				}
			}
		}		
	}
	printf("O Resultado = %f", resultado);
	
	return 0;
}
