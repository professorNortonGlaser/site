#include <stdio.h>
#include <stdlib.h>

/* 
Leia o salario de um trabalhador e o valor da presta��o de um empr�stimo. 
Se a presta��o for maior que 20% do salario imprima:  
Empr�stimo n�o concedido, caso contrario imprima: 
 Empr�stimo concedido.
*/

int main(int argc, char *argv[]) {
	float salario, emprestimo, percentual;
	
	printf("Informe o valor do salario:");
	scanf("%f", &salario);
	printf("Informe o valor do emprestimo:");
	scanf("%f", &emprestimo);
	percentual = salario * 0.2; //20%
	if(emprestimo > percentual)
	{
		printf("Emprestimo nao concedido")	;		
	}
	else
	{
		printf("Emprestimo concedido")	;		
	}
	
	return 0;
}
