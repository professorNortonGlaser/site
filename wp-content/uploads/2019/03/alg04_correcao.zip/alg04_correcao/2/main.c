#include <stdio.h>
#include <stdlib.h>

/* 
Crie um  algoritmo que informe dois valores reais, 
valor em reais do litro da gasolina e valor em reais do litro do �lcool,  
calcule os 70% do valor da gasolina para definir na tela qual combust�vel 
e o mais vantajoso, sabendo que o valor do �lcool para ser mais vantajoso 
deve ser menor que 70% do valor da gasolina.
*/

int main(int argc, char *argv[]) {
	float gasolina, alcool, percentual;
	
	printf("Informe o valor da gasolina:");
	scanf("%f", &gasolina);
	
	printf("Informe o valor da alcool:");
	scanf("%f", &alcool);
	percentual = gasolina * 0.7; // 0.7 => 70% => 70/100	
	
	if(percentual <= alcool)
	{
		printf("A gasolina e mais vantajosa");	
	} 
	else {
		printf("O alcool e mais vantajoso");		
	}
	
	return 0;
}
