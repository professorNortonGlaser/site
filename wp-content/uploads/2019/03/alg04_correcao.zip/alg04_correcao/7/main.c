#include <stdio.h>
#include <stdlib.h>

/* 
Elabore um programa em C que leia as vari�veis C e N, 
respectivamente c�digo e n�mero de horas trabalhadas de um oper�rio. 
E calcule o sal�rio sabendo-se que ele ganha R$ 10,00 por hora. 
Quando o n�mero de horas exceder a 50 calcule o excesso de pagamento 
armazenando-o na vari�vel E, caso contr�rio zerar tal vari�vel.
A hora excedente de trabalho vale R$ 20,00. 
No final do processamento imprimir o sal�rio total e o sal�rio excedente.
 */

int main(int argc, char *argv[]) {
	int c, n;
	float salarioBase, salarioTotal, salarioExtra;
	
	printf("Informe o codigo do funcionario:");
	scanf("%d", &c);
	
	printf("Informe a quantida de horas:");
	scanf("%d", &n);
	
	if(n > 50) {
		salarioBase = 50*10;
		salarioExtra = (n-50)*20;		
	} 
	else{
		salarioBase = n*10;
		salarioExtra = 0;		
	}
	salarioTotal = salarioBase + salarioExtra;
	printf("Salario Base = %f, Salario Extra= %f, Salario Total=%f ", salarioBase, salarioExtra, salarioTotal);
	
	return 0;
}
