#include <stdio.h>
#include <stdlib.h>

/* 
Fa�a um algoritmo que receba um n�mero inteiro, 
identifique se este e par ou impar, utilize o modulo de 
2 para calcular o resto da divis�o, se o resto da divis�o for zero 
(o n�mero e par) caso o resto da divis�o for 1 (o n�mero e impar)   
resto = numero % 2;
*/

int main(int argc, char *argv[]) {
	int numero, resto;
	
	printf("Informe um numero=");
	scanf("%d", &numero);
	// modulo = resto da divis�o inteira	%
	resto = numero % 2;
	//comando de sele��o  if
	if(resto==0)
	{		
		printf("O numero %d e par", numero);	
	}
	else 
	{
		printf("O numero %d e impar", numero);	
	}	
	
	return 0;
}
