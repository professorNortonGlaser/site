#include <stdio.h>
#include <stdlib.h>

/* 
Desenvolva um programa em C que: Leia 4 (quatro) n�meros; 
Calcule o quadrado de cada um; 
Se o valor resultante do quadrado do terceiro for >= 1000,
imprima-o e finalize; Caso contr�rio, 
imprima os valores lidos e seus respectivos quadrados.
*/

int main(int argc, char *argv[]) {
	float a, b, c, d, eA, eB, eC, eD;
	
	printf("Informe o valor de a:");
	scanf("%f", &a);	
	printf("Informe o valor de b:");
	scanf("%f", &b);
	printf("Informe o valor de a:");
	scanf("%f", &c);
	printf("Informe o valor de a:");
	scanf("%f", &d);
	
	eA = a*a;
	eB = b*b;
	eC = c*c;
	eD = d*d;
	
	if(eC >= 1000){
		printf("Quadrado do terceiro = %f", eC)	;
	} 
	else
	{
		printf("Quadrado de a = %f\n", eA);
		printf("Quadrado do b = %f\n", eB);
		printf("Quadrado do c = %f\n", eC);
		printf("Quadrado do d = %f\n", eD);
	}
	
	return 0;
}
