#include <stdio.h>
#include <stdlib.h>

/* 
1- A empresa XPTO concedeu um b�nus de 20% do valor do sal�rio a 
todos os funcion�rios
com tempo de trabalho na empresa igual ou superior a 5 anos e 
de 10% aos demais.
Fa�a um um programa em C que receba o sal�rio e o tempo de servi�o de um
funcion�rio, calcule e mostre o valor do b�nus recebido por ele.

 */

int main(int argc, char *argv[]) {
	float salario, bonus;
	int anos;
	
	printf("Informe o salario:");
	scanf("%f", &salario);
	
	printf("Informe a quantidade de anos:");
	scanf("%d", &anos);
	
	if(anos >=5){
		bonus = salario * 0.2; // (20/100)	
	} else {
		bonus = salario * 0.1; // (10/100)	
	}
	printf("Salario=%f, Bonus=%f", salario, bonus);
	
	return 0;
}
