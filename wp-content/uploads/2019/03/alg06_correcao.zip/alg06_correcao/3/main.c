#include <stdio.h>
#include <stdlib.h>

/* 
Leia a velocidade m�xima permitida em uma avenida e a velocidade
com que o motorista estava dirigindo nela.
Calcule e mostre a multa que uma pessoa vai receber, 
sabendo que s�o pagos: R$ 50 reais se o motorista ultrapassar 
em at� 10km/h a velocidade permitida; R$ 100 reais, 
se o motorista ultrapassar de 11 a 30 km/h a velocidade permitida; 
e R$ 200 reais, se estiver acima de 31km/h da velocidade permitida.
 */

int main(int argc, char *argv[]) {
	float velocidade, velocidadeVeiculo, excedente;
	float multa=0;
	
	printf("Informe a velocidade da via:");
	scanf("%f", &velocidade);
	
	printf("Informe a velocidade do veiculo:");
	scanf("%f", &velocidadeVeiculo);
	
	if(velocidadeVeiculo > velocidade){
		multa = 50;	
		excedente = velocidadeVeiculo - velocidade;		
		if(excedente >= 11 && excedente<=30){
			multa = 100;
		} else {
			if(excedente > 31){
				multa = 200;									
			}		
		}
		printf("Multa de %f ", multa);			 
	}
	
	
	return 0;
}
