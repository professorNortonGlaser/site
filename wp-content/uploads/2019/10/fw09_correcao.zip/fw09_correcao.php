<html>
<body>
<form action="fw09_correcao.php" method="post">
n1:<input type="text" name="n1" />	<br/>
n2:<input type="text" name="n2" />	<br/>
<input type="submit" value="+" name="b1" />
<input type="submit" value="-" name="b2" />
<input type="submit" value="*" name="b3" />
<input type="submit" value="/" name="b4" />
<input type="submit" value="T" name="b5" /><br/><br/>
<?php
if(isset($_POST["b1"])) somar();
if(isset($_POST["b2"])) subtrair();
if(isset($_POST["b3"])) multiplicar();
if(isset($_POST["b4"])) dividir();
if(isset($_POST["b5"])) tabuada();
?>
</form> </body></html>
<?php
function somar(){
	$a = $_POST["n1"];
	$b = $_POST["n2"];
	$r = $a + $b;
	echo "$a + $b = $r";
}
function subtrair(){
	$a = $_POST["n1"];
	$b = $_POST["n2"];
	$r = $a - $b;
	echo "$a - $b = $r";
}
function multiplicar(){
	$a = $_POST["n1"];
	$b = $_POST["n2"];
	$r = $a * $b;
	echo "$a * $b = $r";
}
function dividir(){
	$a = $_POST["n1"];
	$b = $_POST["n2"];
	$r = $a / $b;
	echo "$a / $b = $r";
}
function tabuada(){
	$a = $_POST["n1"];
	for($i=1; $i<=10; $i++){	
		$r = $a * $i;
		echo "$a X $i = $r <br/>";
	}
}
?>