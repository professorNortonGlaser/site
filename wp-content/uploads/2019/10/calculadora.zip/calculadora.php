<html>
<head>
	<title>Assunto: FWJ10</title>
</head>
<body>	
	<h1>calculadora</h1>
	<form action="calculadora.php" method="post">
	n1:<input type="text" id="n1" name="n1" /><br/> 
	n2:<input type="text" id="n2" name="n2" /><br/>
	<input type="submit" name="b1" value="+" /> 
	<input type="submit" name="b2" value="*" />
	<input type="submit" name="b3" value="-" /> 
	<input type="submit" name="b4" value="/" />
	<input type="submit" name="b5" value="T" />
	</form>
	<?php
		if(isset($_POST["b1"])) somar();
		if(isset($_POST["b2"])) multiplicar();
		if(isset($_POST["b3"])) subtrair();
		if(isset($_POST["b4"])) dividir();
		if(isset($_POST["b5"])) tabuada();
	?>
</body></html>
<?php
function somar(){
	$a = $_POST["n1"];	
	$b = $_POST["n2"];	
	$r = $a + $b;	
	echo "A soma = $r";
}
function subtrair(){
	$a = $_POST["n1"];	
	$b = $_POST["n2"];	
	$r = $a - $b;	
	echo "A subtração = $r";
}
function multiplicar(){
	$a = $_POST["n1"];	
	$b = $_POST["n2"];	
	$r = $a * $b;	
	echo "A soma = $r";
}
function dividir(){
	$a = $_POST["n1"];	
	$b = $_POST["n2"];	
	$r = $a / $b;	
	echo "A divisão = $r";
}
function tabuada(){
	$a = $_POST["n1"];	
	for($i=1; $i<=10; $i++){
		$p = $a * $i;	
		echo "$a X $i = $p <br>";
	}
}


?>	