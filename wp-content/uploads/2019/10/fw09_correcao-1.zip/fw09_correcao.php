<html>
<head>
	<title>Fwj09 - Correção</title>
</head>
<body>
	<table border="1">
	<?php montaTabuada(); ?>
	</table>
</body>
</html>	
<?php
function montaTabuada(){	
	$x = 5;
	for($i = 1;$i <=10; $i++){
		$p = $x * $i;
		echo "<tr><td>$i</td><td>$x</td><td>$p</td></tr>";	
	}
}
?>