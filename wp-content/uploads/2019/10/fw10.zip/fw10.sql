CREATE database segma;
use segma;
create table cliente(
	codigo bigint auto_increment,
    nome varchar(100),
    email varchar(100),
    senha varchar(100),	
	primary key(codigo)
);
#drop table cliente;

insert into cliente(nome, email, senha) 
values('joao', 'j@norton.net.br', 
md5('123456'));

select codigo,nome, email
from cliente where codigo=1
# update produto set valor=valor*1.05
update cliente set nome='Maria da silva',
senha=md5('654321') where nome='maria'

delete from cliente where codigo=3


start transaction 

select * from cliente


rollback
commit