﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace pw11_correcao
{
    public partial class livro : System.Web.UI.Page
    {
        String sc = "Server=localhost;Database=pweb;Uid=root;Pwd=;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void inserir(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(sc);
            con.Open();
            String sql = "insert into livro(titulo, autor, qtd, valor, paginas, resumo) " +
                "values('{0}','{1}','{2}','{3}','{4}','{5}')";
            sql = String.Format(sql, txtTitulo.Value, txtAutor.Value, txtQtd.Value,
                txtValor.Value, txtPaginas.Value, txtResumo.Value);
            MySqlCommand comando = new MySqlCommand(sql, con);
            comando.ExecuteNonQuery();
            con.Close();
            lblMensagem.Text = "Registro inserido com sucesso !";
            limpar();
        }

        protected void pesquisar(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(sc);
            con.Open();
            String sql = "select * from livro where codigo="+ txtCodigo.Value;
            MySqlCommand comando = new MySqlCommand(sql, con);
            MySqlDataReader registros = comando.ExecuteReader();
            if (registros.Read())
            {
                txtAutor.Value = registros["autor"].ToString();
                txtPaginas.Value = registros["paginas"].ToString();
                txtQtd.Value = registros["qtd"].ToString();
                txtResumo.Value = registros["resumo"].ToString();
                txtTitulo.Value = registros["titulo"].ToString();
                txtValor.Value = registros["valor"].ToString();
                lblMensagem.Text = "";                
            }
            else
            {
                limpar();
                lblMensagem.Text = "Registro não existe";
            }

            con.Close();
   
        }

        protected void alterar(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(sc);
            con.Open();
            String sql = "update livro set titulo='{0}', autor='{1}', qtd='{2}', valor='{3}', " +
                " paginas='{4}', resumo='{5}' where codigo={6}";
                
            sql = String.Format(sql, txtTitulo.Value, txtAutor.Value, txtQtd.Value,
                txtValor.Value, txtPaginas.Value, txtResumo.Value, txtCodigo.Value);
            MySqlCommand comando = new MySqlCommand(sql, con);
            comando.ExecuteNonQuery();
            con.Close();
            lblMensagem.Text = "Registro alterado com sucesso !";
            limpar();
        }

        protected void exlcuir(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(sc);
            con.Open();
            String sql = "delete from livro where codigo="+ txtCodigo.Value;

            MySqlCommand comando = new MySqlCommand(sql, con);
            comando.ExecuteNonQuery();
            con.Close();
            lblMensagem.Text = "Registro removido com sucesso !";
            limpar();
        }

        private void limpar()
        {
            txtAutor.Value = "";
            txtPaginas.Value = "";
            txtQtd.Value = "";
            txtResumo.Value = "";
            txtTitulo.Value = "";
            txtValor.Value = "";
        }
    }
}