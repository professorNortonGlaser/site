﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="livro.aspx.cs" Inherits="pw11_correcao.livro" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
     <h1>livro</h1>
     codigo:<input type="number" id="txtCodigo" runat="server" /><br />
     titulo:<input type="text" id="txtTitulo" runat="server" /><br />
    autor:<input type="text" id="txtAutor" runat="server" /><br /> 
    qtd: <input type="number" id="txtQtd" runat="server" /><br />
    valor: <input type="text" id="txtValor" runat="server" /><br /> 
    paginas: <input type="number" id="txtPaginas" runat="server" /><br />
    resumo: <textarea id="txtResumo" rows="5" runat="server"></textarea> <br />
    <asp:Button ID="Button1" runat="server" Text="Inserir" OnClick="inserir" />
    <asp:Button ID="Button2" runat="server" Text="Pesquisar" OnClick="pesquisar" />
    <asp:Button ID="Button3" runat="server" Text="Alterar" OnClick="alterar" />
    <asp:Button ID="Button4" runat="server" Text="Excluir" OnClick="exlcuir" /> <br />
    <asp:Label ID="lblMensagem" runat="server" ></asp:Label>
    </div>
    </form>
</body>
</html>
