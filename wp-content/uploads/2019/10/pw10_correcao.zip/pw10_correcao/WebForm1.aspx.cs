﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pw10_correcao
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void somar(object sender, EventArgs e)
        {
            try
            {
                double a, b, c;
                a = Convert.ToDouble(n1.Value);
                b = Convert.ToDouble(n2.Value);
                c = a + b;
                Label1.Text = "A soma = " + c.ToString();
            }
            catch (Exception err)
            {
                //TODO gravar arquivo com log de erro
                Label1.Text = "Por favor digite somente numeros !";
            }
        }

        protected void subtrair(object sender, EventArgs e)
        {
            try
            {
                double a, b, c;
                a = Convert.ToDouble(n1.Value);
                b = Convert.ToDouble(n2.Value);
                c = a - b;
                Label1.Text = "A subtração = " + c.ToString();
            }
            catch (Exception err)
            {
                //TODO gravar arquivo com log de erro
                Label1.Text = "Por favor digite somente numeros !";
            }
        }

        protected void multiplicar(object sender, EventArgs e)
        {
            try
            {
                double a, b, c;
                a = Convert.ToDouble(n1.Value);
                b = Convert.ToDouble(n2.Value);
                c = a * b;
                Label1.Text = "A multiplicação = " + c.ToString();
            }
            catch (Exception err)
            {
                //TODO gravar arquivo com log de erro
                Label1.Text = "Por favor digite somente numeros !";
            }
        }

        protected void dividir(object sender, EventArgs e)
        {
            try
            {
                double a, b, c;
                a = Convert.ToDouble(n1.Value);
                b = Convert.ToDouble(n2.Value);
                c = a / b;
                Label1.Text = "A divisão = " + c.ToString();
            }
            catch (Exception err)
            {
                //TODO gravar arquivo com log de erro
                Label1.Text = "Por favor digite somente numeros !";
            }
        }
    }
}