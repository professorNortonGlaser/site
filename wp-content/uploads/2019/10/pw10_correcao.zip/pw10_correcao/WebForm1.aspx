﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="pw10_correcao.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <h1>PW10</h1>
        N1:<input type="text" id="n1" runat="server" /><br />
        N2:<input type="text" id="n2" runat="server" /><br />
        <asp:Button ID="Button1" runat="server" Text="+" OnClick="somar" />
        <asp:Button ID="Button2" runat="server" Text="-" OnClick="subtrair" />
        <asp:Button ID="Button3" runat="server" Text="*" OnClick="multiplicar" />
        <asp:Button ID="Button4" runat="server" Text="/" OnClick="dividir" /> <br />
        <br />
        <asp:Label ID="Label1" runat="server" Text="Label"></asp:Label>
    </div>
    </form>
</body>
</html>
