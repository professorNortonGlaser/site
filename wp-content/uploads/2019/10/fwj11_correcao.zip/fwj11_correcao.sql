create database jogos;

use jogos;

create table usuario (
	codigo bigint auto_increment,
    nome varchar(100),
    email varchar(100),
	senha varchar(100),
    primary key (codigo)
);

create table chamado(
	codigo bigint auto_increment, 
    titulo varchar(100), 
    descritivo varchar(1000), 
    prioridade int, 
    status int, primary key(codigo) );
    
    
create table logAcesso(
codigo bigint auto_increment,
login varchar(100), 
dataLogin timestamp, 
dataLogout timestamp, primary key(codigo))    