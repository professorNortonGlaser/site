#include <stdio.h>
#include <stdlib.h>

struct Node{
    int num;
    struct Node *prox;
} typedef node;

struct {
    node *primeiro;
} typedef fila;

int tam;

int menu(void)
{
    int opt;
    printf("Escolha a opcao\n");
    printf("0. Sair\n");
    printf("1. Zerar fila\n");
    printf("2. Exibir fila\n");
    printf("3. Adicionar Elemento na Fila\n");
    printf("4. Retirar Elemento da Fila\n");
    printf("Opcao: "); 
    scanf("%i", &opt);
    return opt;
}

void opcao(fila *FILA, int op)
{
    node *tmp;
    switch(op){
        case 0:{
            limpar(FILA);
            break;
        }
        case 1:{
            limpar(FILA);
            break;
        }
        case 2:{
            exibe(FILA);
            break;
        }
        case 3:{
            insere(FILA);
            break;
        }
        case 4: {
            tmp= retira(FILA);
            if(tmp != NULL){
                printf("Retirado: %i\n\n", tmp->num);
            }
            break;
        }
        default:{
            printf("Comando invalido\n\n");
        }
    }
}

int vazia(fila *FILA)
{
     if(FILA->primeiro == NULL) {
        return 1;
     } else {
        return 0;
     }
}

node *aloca()
{
    node *novo=(node*)malloc(sizeof(node));
    if(!novo){
        printf("Sem memoria disponivel!\n");
        exit(1);
    }else{
        printf("Novo elemento: "); 
        scanf("%i", &novo->num);
        return novo;
    }
}

void insere(fila *FILA)
{
    node *novo=aloca();
    novo->prox = NULL;
    if(vazia(FILA))
        FILA->primeiro=novo;
    else{
        node *tmp = FILA->primeiro;
        while(tmp->prox != NULL){
            tmp = tmp->prox;
        }
        tmp->prox = novo;
    }
    tam++;
}

void retira(fila *FILA)
{
    if(FILA->primeiro == NULL){
        printf("Fila ja esta vazia\n");
    } else {
        node *tmp = FILA->primeiro;
        FILA->primeiro = tmp->prox;
        tam--;
        free(tmp);
    }
}

void limpar(fila *FILA){
    while(FILA->primeiro != NULL){
        retira(FILA);
    }
    printf("FILA LIMPA\n");
}

void exibe(fila *FILA)
{
    if(vazia(FILA)){
        printf("Fila vazia!\n\n");
    } else {
        node *tmp;
        tmp = FILA->primeiro;
        printf("Fila :");
        while( tmp != NULL){
            printf("\n %x %d", tmp, tmp->num);
            tmp = tmp->prox;
        }
        printf("\n\n");
    }
}

int main(void)
{
    fila FILA = {NULL};
    int opt;
    do{
        opt=menu();
        opcao(&FILA,opt);
    } while(opt);
    return 0;
}


