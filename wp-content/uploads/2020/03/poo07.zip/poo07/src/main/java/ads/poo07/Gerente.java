/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo07;

/**
 *
 * @author norton
 */
public class Gerente extends Funcionario {
    private double bonus;

    /**
     * @return the bonus
     */
    public double getBonus() {
        return bonus;
    }

    /**
     * @param bonus the bonus to set
     */
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public double calculoSalario(){        
        double salarioBase = super.calculoSalario();
        return salarioBase+getBonus();        
    }
    
            
            
}
