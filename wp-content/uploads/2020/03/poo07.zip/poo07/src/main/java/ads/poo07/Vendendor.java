/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ads.poo07;

/**
 *
 * @author norton
 */
public class Vendendor extends Funcionario {
    private double comissao;

    /**
     * @return the comissao
     */
    public double getComissao() {
        return comissao;
    }

    /**
     * @param comissao the comissao to set
     */
    public void setComissao(double comissao) {
        this.comissao = comissao;
    }
    
    @Override
     public double calculoSalario(){
        return getSalarioBase()+getComissao();        
    }
     
    public double calculoSalario(double premio){
        double salarioBase = super.calculoSalario();
        salarioBase += ((premio+this.comissao)/2); 
        return salarioBase;
    }
    
    
}
