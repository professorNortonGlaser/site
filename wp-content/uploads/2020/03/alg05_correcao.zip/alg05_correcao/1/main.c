#include <stdio.h>
#include <stdlib.h>

/* 
Informe as duas notas de um aluno (P1 e P2) e a quantidade 
de faltas no semestre, calcule a media das notas e o 
percentual de faltas sobre 20 aulas.  
Caso o percentual de faltas for maior que 30% o 
aluno esta automaticamente reprovado,
 caso ao contrario verifique se a media e maior igual a 6,  
 se afirmativo o aluno esta aprovado, 
 sen�o informe uma nota P3 para recalcular a media,
  se a nova media for maior igual a 6, 
  escreva aprovado no exame, 
  caso negativo exiba reprovado por nota.
 */

int main(int argc, char *argv[]) {
	float p1, p2, p3, media, faltas, percFaltas;
	//entrada de dados
	printf("Informe a nota p1:");
	scanf("%f", &p1);
	printf("Informe a nota p2:");
	scanf("%f", &p2);
	printf("Informe a qtd de faltas:");
	scanf("%f", &faltas);
	//processamento
	media = (p1+p2)/2;
	percFaltas =  faltas / 20;	
	
	if(percFaltas >= 0.3)
	{
		printf("reprovado por faltas !");
	} 
	else 
	{
		if(media >= 6){
			printf("Aluno aprovado= %f", media);	
		} 
		else	
		{
			printf("Informe a nota p3:");
			scanf("%f", &p3);
			media = (p1+p2+p3)/3;
			if(media >= 6){
				printf("Aluno aprovado na p3= %f", media);	
			} 
			else 
			{
				printf("Aluno reprovado por nota= %f", media);	
			}			
		}		
	}
	
	return 0;
}
