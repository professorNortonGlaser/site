#include <stdio.h>
#include <stdlib.h>

/* 
Informe dois n�meros reais e um n�mero inteiro que
represente a opera��o matem�tica a ser realizada 
(1-soma, 2-subtra��o, 3- multiplica��o, 4-divis�o) 
utilize o comando sele��o aninhado e exiba o 
resultado da opera��o matem�tica escolhida.
*/

int main(int argc, char *argv[]) {
	int op;
	float a, b, res;
	
	//a entrada de dados
	printf("Informe a operacao 1-somar, 2-subtrair, 3- multiplicar, 4-dividir");
	scanf("%i", &op);
	printf("Informe o valor de a:")	;
	scanf("%f", &a);
	printf("Informe o valor de b:")	;
	scanf("%f", &b);
	//processamento
	if(op==1){
		res = a + b;	
	} else {
		if(op==2){
			res = a - b;		
		} else {
			if(op==3){
				res = a * b;			
			} else {
				res = a / b;		
			}			
		}			
	}
	//Saida da informa��o
	printf("resultado :%f", res);
	
	return 0;
}
