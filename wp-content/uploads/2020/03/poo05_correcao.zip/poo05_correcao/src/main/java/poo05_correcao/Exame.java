package poo05_correcao;

public class Exame {
    private String consulta;
    private String data;
    private String descritivo;
   
    public Exame(){        
    }
    
    public Exame(String pC, String pD, String pT)
    {
        try{
            this.consulta = pC;
            this.data = pD;
            this.descritivo = pT;
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    public String getConsulta(){
        return this.consulta;
    }
    public void setConsulta(String p){
        this.consulta = p;
    }
    
    
    public void solicitar(){}
    public void cosultar(){}
    public void mostrar(){
        System.out.println("EXAME===>");
        System.out.println("consulta="+ getConsulta());
        System.out.println("data="+ getData());
        System.out.println("descritivo="+ getDescritivo());
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return the descritivo
     */
    public String getDescritivo() {
        return descritivo;
    }

    /**
     * @param descritivo the descritivo to set
     */
    public void setDescritivo(String descritivo) {
        this.descritivo = descritivo;
    }
}
