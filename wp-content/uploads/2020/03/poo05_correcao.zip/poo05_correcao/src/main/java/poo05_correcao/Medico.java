package poo05_correcao;

public class Medico {
    private String nome;
    private long crm;
    private String telefone;
    private String especialidade;
    private String senha;
    
    public Medico(){        
    }
    public Medico(String pNome, long pCrm, 
            String pTelefone, String pEspecialidade)
    {
       try{
        this.nome = pNome;
        this.crm = pCrm;
        this.telefone = pTelefone;
        this.especialidade = pEspecialidade;
       }
       catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }       
    
    
    public void acessar(){
        //todo
    }
    public void mostrar(){
        System.out.println("nome="+ getNome());
        System.out.println("crm="+ getCrm());
        System.out.println("telefone="+ getTelefone());
        System.out.println("esp.="+ getEspecialidade());
        System.out.println("senha="+getSenha() );
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the crm
     */
    public long getCrm() {
        return crm;
    }

    /**
     * @param crm the crm to set
     */
    public void setCrm(long crm) {
        this.crm = crm;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the especialidade
     */
    public String getEspecialidade() {
        return especialidade;
    }

    /**
     * @param especialidade the especialidade to set
     */
    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    public void realizarConsulta(Consulta obj){
        Receita r1 = new Receita();
        r1.setData("12/03/2020");
        r1.setDescritivo("tylenol");
        obj.getReceitas().add(r1);
        Exame e1 = new Exame();
        e1.setData("12/03/2020");
        e1.setDescritivo("Exame de sangue");
        obj.getExames().add(e1);
        Exame e2 = new Exame();
        e2.setData("12/03/2020");
        e2.setDescritivo("raio x");
        obj.getExames().add(e2);
        obj.mostrar();
    }
}
