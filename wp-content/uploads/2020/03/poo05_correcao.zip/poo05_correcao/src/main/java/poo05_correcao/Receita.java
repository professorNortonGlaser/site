package poo05_correcao;

public class Receita {
    private String consulta;
    private String data;
    private String descritivo;
    
    public Receita(){};
    
    public Receita(String pConsulta, 
            String pData, String pDescritivo){
        try{
            this.consulta = pConsulta;
            this.data = pData;
            this.descritivo = pDescritivo;
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    
    public void preescrever(){}
    public void cosultar(){}
    public void mostrar(){
        System.out.println("consulta="+ getConsulta());
        System.out.println("data="+ getData());
        System.out.println("descritivo="+ getDescritivo());
    }

    /**
     * @return the consulta
     */
    public String getConsulta() {
        return consulta;
    }

    /**
     * @param consulta the consulta to set
     */
    public void setConsulta(String consulta) {
        this.consulta = consulta;
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return the descritivo
     */
    public String getDescritivo() {
        return descritivo;
    }

    /**
     * @param descritivo the descritivo to set
     */
    public void setDescritivo(String descritivo) {
        this.descritivo = descritivo;
    }
}
