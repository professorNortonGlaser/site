/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo05;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author professor
 */
public class Pedido {
    private int codigo;
    private double total;
    //Agregação 0 ... N
    private Cliente comprador;
    //Composição 1...N
    private List<ItemPedido> itens = new
            ArrayList<ItemPedido>();

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the total
     */
    public double getTotal() {
        return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(double total) {
        this.total = total;
    }

    /**
     * @return the comprador
     */
    public Cliente getComprador() {
        return comprador;
    }

    /**
     * @param comprador the comprador to set
     */
    public void setComprador(Cliente comprador) {
        this.comprador = comprador;
    }

    public void gravarPedido() {
        System.out.println("Pedido "+ 
                this.codigo);
        System.out.println("Cliente="+ 
                this.comprador.getNome());
        System.out.println("itens"+ 
                this.itens.size());
        for(ItemPedido obj : this.itens){
           System.out.println("Item "+ 
                   obj.getCodigo() );                
        }
    }

    /**
     * @return the itens
     */
    public List<ItemPedido> getItens() {
        return itens;
    }

    /**
     * @param itens the itens to set
     */
    public void setItens(List<ItemPedido> itens) {
        this.itens = itens;
    }

   
    
}
