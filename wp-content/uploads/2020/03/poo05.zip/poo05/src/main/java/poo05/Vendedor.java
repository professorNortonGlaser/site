/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo05;

/**
 *
 * @author professor
 */
public class Vendedor {
    private int codigo;
    private String nome;

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void novaVenda(){
        Cliente maria = new Cliente();
        maria.setCpf("123123");
        maria.setNome("Maria da silva");
        maria.cadastrar();
        
        Pedido objPedido = new Pedido();
        objPedido.setCodigo(123);
        objPedido.setTotal(1000);
        objPedido.setComprador(maria);
        
        ItemPedido item1 = new 
        ItemPedido(1,2,100);
        objPedido.getItens().add(item1);
        ItemPedido item2 = new 
        ItemPedido(2,5,50);
        objPedido.getItens().add(item2);
        
        objPedido.gravarPedido();
    }
}
