package com.mycompany.poo06;

public class Receita extends Procedimento {
    private String consulta;
        
    public Receita(){};
    
    public Receita(String pConsulta, 
            String pData, String pDescritivo){
        try{
            setConsulta(pConsulta);
            setData(pData);
            setDescritivo(pDescritivo);
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    
    public void preescrever(){}

    public void mostrar(){
        System.out.println("consulta="+ getConsulta());
        System.out.println("data="+ getData());
        System.out.println("descritivo="+ getDescritivo());
    }

    /**
     * @return the consulta
     */
    public String getConsulta() {
        return consulta;
    }

    /**
     * @param consulta the consulta to set
     */
    public void setConsulta(String consulta) {
        this.consulta = consulta;
    }

  
}
