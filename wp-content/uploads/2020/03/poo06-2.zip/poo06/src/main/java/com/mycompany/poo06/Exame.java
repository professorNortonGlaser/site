package com.mycompany.poo06;

public class Exame extends Procedimento {
    private String consulta;

   
    public Exame(){        
    }
    
    public Exame(String pC, String pD, String pT)
    {
        try{
            setConsulta(pC);
            setData(pD);
            setDescritivo(pT);
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    public String getConsulta(){
        return this.consulta;
    }
    public void setConsulta(String p){
        this.consulta = p;
    }
    
    
    public void solicitar(){}
    public void cosultar(){}
    public void mostrar(){
        System.out.println("EXAME===>");
        System.out.println("consulta="+ getConsulta());
        System.out.println("data="+ getData());
        System.out.println("descritivo="+ getDescritivo());
    }

    
}
