package com.mycompany.poo06;

import java.util.ArrayList;
import java.util.List;

public class Consulta  extends Agenda{
    private Medico medico; //0-N
    private Paciente paciente; //0-N
    private String motivo;
    private String historico; 
    private List<Exame> exames 
            = new ArrayList<Exame>(); //N-N
    private List<Receita> receitas 
            = new ArrayList<Receita>(); //N-N
    private Agenda agenda;
    
    public Consulta(){        
    }
    
    public Consulta(String pData, String pHora,
            Medico pMedico, Paciente pPaciente, 
            String pMotivo, String pHistorico){
        try{
            setData(pData);
            setHora(pHora);
            setMedico(pMedico);
            setPaciente(pPaciente);
            setMotivo(pMotivo);
            setHistorico(pHistorico);
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    
    public void marcar(){};
    public void cancelar(){};
    
    public void realizar(){};
    public void atualizar(){};
    

    

    /**
     * @return the medico
     */
    public Medico getMedico() {
        return medico;
    }

    /**
     * @param medico the medico to set
     */
    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    /**
     * @return the paciente
     */
    public Paciente getPaciente() {
        return paciente;
    }

    /**
     * @param paciente the paciente to set
     */
    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    /**
     * @return the motivo
     */
    public String getMotivo() {
        return motivo;
    }

    /**
     * @param motivo the motivo to set
     */
    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    /**
     * @return the historico
     */
    public String getHistorico() {
        return historico;
    }

    /**
     * @param historico the historico to set
     */
    public void setHistorico(String historico) {
        this.historico = historico;
    }

    /**
     * @return the exames
     */
    public List<Exame> getExames() {
        return exames;
    }

    /**
     * @param exames the exames to set
     */
    public void setExames(List<Exame> exames) {
        this.exames = exames;
    }

    /**
     * @return the receitas
     */
    public List<Receita> getReceitas() {
        return receitas;
    }

    /**
     * @param receitas the receitas to set
     */
    public void setReceitas(List<Receita> receitas) {
        this.receitas = receitas;
    }

    /**
     * @return the agenda
     */
    public Agenda getAgenda() {
        return agenda;
    }

    /**
     * @param agenda the agenda to set
     */
    public void setAgenda(Agenda agenda) {
        this.agenda = agenda;
    }
    
}
