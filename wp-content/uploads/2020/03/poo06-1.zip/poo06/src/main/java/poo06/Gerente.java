/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo06;

import java.util.ArrayList;
import java.util.List;

public class Gerente extends Funcionario{
    private List<Vendedor> vendedores = 
            new ArrayList<Vendedor>();

    /**
     * @return the vendedores
     */
    public List<Vendedor> getVendedores() {
        return vendedores;
    }

    /**
     * @param vendedores the vendedores to set
     */
    public void setVendedores(List<Vendedor> vendedores) {
        this.vendedores = vendedores;
    }
    
}
