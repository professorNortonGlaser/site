/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo06;

/**
 *
 * @author professor
 */
public class Vendedor extends Funcionario {
    private double meta;

    /**
     * @return the meta
     */
    public double getMeta() {
        return meta;
    }

    /**
     * @param meta the meta to set
     */
    public void setMeta(double meta) {
        this.meta = meta;
    }
    
}
