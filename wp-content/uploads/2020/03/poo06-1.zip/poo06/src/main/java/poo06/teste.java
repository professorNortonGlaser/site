/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo06;

/**
 *
 * @author professor
 */
public class teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vendedor v1 = new Vendedor();
        v1.setCelular("3423-2344");
        v1.setCpf("234324324");
        v1.setNome("Maria");
        v1.setMeta(1000);
        v1.mostrar();
        
        Gerente g1 = new Gerente();
        g1.setCelular("4564-7878");
        g1.setCpf("324523545");
        g1.setNome("Joao");
        g1.getVendedores().add(v1);
        g1.mostrar();
                
    }
    
}
