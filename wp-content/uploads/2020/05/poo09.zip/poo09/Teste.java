/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo09;

/**
 *
 * @author norton
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Teste1 obj1 = new Teste1();
        Teste2 obj2 = new Teste2();
        
        Thread t1 = new Thread(obj1);
        t1.start();

        Thread t2 = new Thread(obj2);
        t2.start();
        
        // TODO code application logic here
    }
    
}
