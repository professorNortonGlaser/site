/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo09;

/**
 *
 * @author norton
 */
public class Teste1  implements Runnable {

    @Override
    public void run() {
        for(long i=0; i < 999; i++){
           System.out.println("Teste 1 => "+ i); 
        }
    }
    
}
