/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo8;

/**
 *
 * @author norton
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente();
        cc.deposita(1500);
        cc.sacar(350);
        ContaPoupanca cp = new ContaPoupanca();
        cp.deposita(200);
        cp.deposita(50);
               GeradorExtratos obj = new GeradorExtratos();
               obj.geradorConta(cc);
               obj.geradorConta(cp);
        
    }
    
}
