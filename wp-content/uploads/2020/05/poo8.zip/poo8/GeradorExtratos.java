/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo8;

/**
 *
 * @author norton
 */
public class GeradorExtratos {
    public void geradorConta(Conta obj){
        System.out.println(obj.getTipo());
        System.out.println("Saldo atual="+ obj.getSaldo());
    } 
}
