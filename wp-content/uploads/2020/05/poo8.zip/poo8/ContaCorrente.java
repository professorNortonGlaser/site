/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo8;

/**
 *
 * @author norton
 */
public class ContaCorrente implements Conta {
    private double saldo;
    private double taxaOperacao = 0.45;

    @Override
    public void deposita(double valor) {
        this.saldo = this.saldo + (valor - this.taxaOperacao);
    }

    @Override
    public void sacar(double valor) {
         this.saldo = this.saldo - (valor - this.taxaOperacao);
    }

    @Override
    public double getSaldo() {
       return this.saldo; 
    }
    
    @Override
    public String getTipo(){
       return "Conta Corrente"; 
    }
    
}
