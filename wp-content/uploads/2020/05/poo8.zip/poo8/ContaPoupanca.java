/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo8;

/**
 *
 * @author norton
 */
public class ContaPoupanca implements Conta {
    private double saldo;

    @Override
    public void deposita(double valor) {
        this.saldo = this.saldo + valor;
    }

    @Override
    public void sacar(double valor) {
        this.saldo = this.saldo - valor;
    }

    @Override
    public double getSaldo() {
       return this.saldo; 
    }
    
     @Override
    public String getTipo(){
       return "Conta Poupança"; 
    }
    
}
