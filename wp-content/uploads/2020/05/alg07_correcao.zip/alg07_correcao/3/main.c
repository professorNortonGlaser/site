#include <stdio.h>
#include <stdlib.h>

/* 
3-Leia a velocidade m�xima permitida em uma avenida e a 
velocidade com que o motorista estava dirigindo nela. 
Calcule e mostre a multa que uma pessoa vai receber, 
sabendo que s�o pagos: 
R$ 50 reais se o motorista ultrapassar em at� 10km/h 
a velocidade permitida; 
R$ 100 reais, se o motorista ultrapassar de 11 a 30 km/h 
a velocidade permitida; 
e R$ 200 reais, se estiver acima de 31km/h 
da velocidade permitida.
*/

int main(int argc, char *argv[]) {
	float velocidadeVia, velocidadeCarro, multa, percVelocidade;
	printf("Informe a velocidade da via:");
	scanf("%f", &velocidadeVia);
	printf("Informe a velocidade do carro:");
	scanf("%f", &velocidadeCarro);
	if(velocidadeCarro <= velocidadeVia){
		multa = 0;	
	} else {
		percVelocidade = velocidadeCarro - velocidadeVia;
		if(percVelocidade <= 10){
			multa = 50;	
		} 
		else 
		{
			if(percVelocidade <= 20){
				multa = 100;	
			} 
			else {
				multa = 200;	
			}	 
		} 
	}
	printf("Multa de=  %f", multa);
	return 0;
}
