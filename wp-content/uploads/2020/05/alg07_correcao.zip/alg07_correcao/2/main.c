#include <stdio.h>
#include <stdlib.h>

/* 
2-Fa�a um programa em C que verifique se o ano � bissexto ou n�o. 
Se ele n�o for bissexto, 
indique quanto tempo falta para o pr�ximo bissexto.
Para ser bissexto, o ano deve ser:
1-Divis�vel por 4. Sendo assim, a divis�o � exata com o resto igual a zero;
2-N�o pode ser divis�vel por 100. Com isso, a divis�o n�o � exata, ou seja, deixa resto diferente de zero;
3-Pode ser que seja divis�vel por 400.
*/

int main(int argc, char *argv[]) {
	int ano, resto4, resto100, resto400, proximoAno;
	
	printf("Informe um ano:");
	scanf("%i", &ano);
	
	resto4 = ano % 4;
	if(resto4==0)
	{
		resto100 = ano % 100;
		if(resto100 > 0){
			printf("Ano bissexto=%i", ano);
		} else {
			resto400 = ano % 400;
			if(resto400==0){
				printf("Ano bissexto=%i", ano);	
			} else {
				proximoAno = ano + 4;
				printf("Proximo ano bissexto=%i",proximoAno);
			}			
		}		
	} 
	else
	{
		proximoAno = ano + (4 -resto4);
		printf("Proximo ano bissexto=%i",proximoAno);
	}
	
	return 0;
}
