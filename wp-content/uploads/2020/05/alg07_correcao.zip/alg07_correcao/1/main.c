#include <stdio.h>
#include <stdlib.h>

/* 
1- A empresa XPTO concedeu um b�nus de 20% do valor do sal�rio 
a todos os funcion�rios com tempo de trabalho na empresa 
igual ou superior a 5 anos e de 10% aos demais.
Fa�a um um programa em C que receba o sal�rio e o tempo
de servi�o de um funcion�rio, calcule e mostre o 
valor do b�nus recebido por ele.
*/

int main(int argc, char *argv[]) {
	float salario, novoSalario;
	int tempoEmpresa;
	
	printf("Informe o salario atual:");
	scanf("%f", &salario);
	printf("Tempo de Empresa:");
	scanf("%i", &tempoEmpresa);
	
	if(tempoEmpresa >= 5){
		novoSalario = salario * 1.2;	
	}
	else 
	{
		if(tempoEmpresa >=1)
		{
			novoSalario = salario * 1.1;				
		} 
		else
		{
			novoSalario = salario;
		}			
	}
	printf("Novo Salario: %.2f",novoSalario);
	
	return 0;
}
