/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

typedef struct no {
  int valor;
  struct no* ant; 
  struct no* prox;
}No;

typedef struct lista{
    No *inicio, *fim;
}Lista_dl;


void inicia(Lista_dl *lista){
  lista->inicio = lista->fim = NULL;
}


void insere_lista_duplamente_ligada(No **lista, int v){
  No *no;
  no = (No*)malloc(sizeof(No));
  no->valor = v;
  if(*lista == NULL){
	no->ant = NULL;
	no->prox = NULL;
  }else{ 
	no->prox = *lista;
	no->ant = NULL;
	(*lista)->ant = no;
  }
  *lista = no;    
}

void imprime_lista(Lista_dl lista){  
  No *aux = lista.inicio;
  while (aux != NULL) {
    printf("%d ", aux->valor);
    aux = aux->prox;
  }
  printf("\n");
}

void insere_fim(Lista_dl *lista, int v){
  No* no;
  no = (No*)malloc(sizeof(No));
  no->valor = v;
  no->prox = NULL;
  if(lista->inicio == NULL){
    no->ant = NULL;
    lista->inicio = lista->fim = no;  
  }else{ 
    no->ant = lista->fim; 
    (lista->fim)->prox = no;
    lista->fim = no;
  }
}

int remove_fim(Lista_dl *lista) {
  No *no;
  int v;
  if (lista->inicio == NULL) return 1;
  no = lista->fim;
  if(lista->inicio == lista->fim){
	lista->inicio = lista->fim = NULL;
  } else {
	lista->fim = no->ant;  
  	(lista->fim)->prox = NULL;
  }
   v = no->valor;
   free(no);
  return v;
}

int main()
{
    Lista_dl lista_dl;
    inicia(&lista_dl);

   /* insere_lista_duplamente_ligada(&lista_dl, 7);
    insere_lista_duplamente_ligada(&lista_dl, 2);*/
    insere_fim(&lista_dl, 7);
     insere_fim(&lista_dl, 2);
     insere_fim(&lista_dl, 8);
    imprime_lista(lista_dl);  
    remove_fim(&lista_dl);
    imprime_lista(lista_dl);  
    return 0;
}
