/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

typedef struct no {
  int valor;
  struct no* prox;
}No;

void insere_lista_circular(No** lista, int v){
  No* no;
  no = (No*)malloc(sizeof(No));
  no->valor = v;
  if(*lista == NULL){
	no->prox = no;
  }else{ 
	no->prox = (*lista)->prox;
	(*lista)->prox = no;
  }
  *lista = no;
}
void imprime_lista(No* lista){
  No *aux = lista->prox;
  
  do {
      printf("%d ", aux->valor);
      aux = aux->prox;
  }while (aux != lista->prox);
  printf("\n");
}
int remove_lista_circular(No** lista) {
  No* n;
  int v;
  if (*lista == NULL)
    return 1;
   
  if((*lista)->prox == *lista){
	n =*lista;
	*lista = NULL;
  }  else{
	n = (*lista)->prox;
	(*lista)->prox = n->prox;  
   	v = n->valor;
  }
  free(n);
  return v;
}


int main()
{
   No *lista;
	lista = NULL;
	insere_lista_circular(&lista, 3);
	insere_lista_circular(&lista, 8);
	insere_lista_circular(&lista, 6);
	imprime_lista(lista);
	remove_lista_circular(&lista);
		imprime_lista(lista);
    return 0;
}
