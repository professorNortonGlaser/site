/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

typedef struct no {
  int valor;
  struct no* prox;
}No;

void imprime_lista(No *lista) {
  printf("=========>\n");    
  while (lista != NULL) {
    printf("%d\n", lista->valor);
    lista = lista->prox;
  }
}

void insere_comeco(No **lista, int valor){
  No* no;
  no = (No*)malloc(sizeof(No));
  no->valor = valor;
  no->prox = *lista;
  *lista = no;
}

void insere_final(No **lista, int v) {
  No *n, *aux;
  n = (No*)malloc(sizeof(No));
  n->valor = v;
  n->prox = NULL;  // Ultimo elemento da lista
  if (*lista == NULL) { 
    *lista = n; //lista vazia 
  } else {
    aux = *lista;
    while (aux->prox != NULL) //procurando o fim da lista
      aux = aux->prox;
 	  aux->prox = n;
    }
}

int remove_inicio(No **lista) {
  No* n;
  int v;
  if(*lista == NULL) return 1; //lista vazia
  n = *lista;
  *lista = n->prox; //substitui o atual pelo proximo  
  v = n->valor;
  free(n); //remove item da memoria
  return v;
}

int remove_final(No **lista) {
  No *n, *aux;
  int v;
  if (*lista == NULL) //fim da lista
    return 1;
  if ((*lista)->prox == NULL) {
     n = *lista; 
     *lista = NULL;
  } else {
    aux = *lista; /* Para no penúltimo nó */
    while (aux->prox->prox != NULL)
      aux = aux->prox;
      n = aux->prox;
      aux->prox = NULL;
  }
  v = n->valor;
  free(n);
  return v;
}


int main()
{
   No *lista;
	lista = NULL;
	insere_comeco(&lista, 3);
	insere_comeco(&lista, 8);
	insere_comeco(&lista, 6);
	imprime_lista(lista);
	insere_comeco(&lista, 6);
	imprime_lista(lista);
	insere_final(&lista, 12);
	imprime_lista(lista);
	remove_inicio(&lista);
	imprime_lista(lista);
	remove_final(&lista);
	imprime_lista(lista);
    return 0;
}
