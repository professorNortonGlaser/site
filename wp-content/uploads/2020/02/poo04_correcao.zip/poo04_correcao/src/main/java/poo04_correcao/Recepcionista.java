package poo04_correcao;

public class Recepcionista {
    private String nome;
    private String cpf;
    private String telefone;
    private String senha;
    
    public Recepcionista(){}
    
    public Recepcionista(String pNome, 
            String pCpf, String pTelefone){
        try{
            this.nome = pNome;
            this.cpf = pCpf;
            this.telefone = pTelefone;
        }
        catch(Exception err){
            System.out.println("Parametros invalidos");
        }        
    }
    
    
    public void acessar(){ 
        //todo
    }
    public void mostrar(){
        System.out.println("nome="+ getNome());
        System.out.println("cpf="+ getCpf());
        System.out.println("telefone="+ getTelefone());
        System.out.println("senha="+getSenha() );
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
}
