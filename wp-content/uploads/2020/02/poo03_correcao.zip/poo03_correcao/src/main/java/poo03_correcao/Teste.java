/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo03_correcao;

/**
 *
 * @author professor
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Agenda a2702 = new Agenda();
        a2702.setHora("18:00");
        a2702.setData("27/02/2020");
        a2702.setPaciente("maria");
        a2702.setMedico("Joao");
        a2702.mostrar();
        
        Agenda a2802 = new Agenda("28/02/2020",
        "17:00", "Ana", "Jose");
        a2802.mostrar();
        
        Consulta objConsulta1 = 
            new Consulta("28/02/2020","17:00",
                    "Ana","Jose","Enxaqueca","");
        objConsulta1.mostrar();
        
        Exame exame1 = new Exame("Consult 1", 
                "28/02/2020","Tomografia");
        exame1.mostrar();
        
        Medico ana = new Medico("Ana Paula", 
                1231,"7898-7877","Neuro");
        ana.mostrar();
    }
    
    
}
