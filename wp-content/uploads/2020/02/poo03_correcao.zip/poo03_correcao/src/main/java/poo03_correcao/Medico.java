package poo03_correcao;

public class Medico {
    private String nome;
    private long crm;
    private String telefone;
    private String especialidade;
    private String senha;
    
    public Medico(){        
    }
    public Medico(String pNome, long pCrm, 
            String pTelefone, String pEspecialidade)
    {
        this.nome = pNome;
        this.crm = pCrm;
        this.telefone = pTelefone;
        this.especialidade = pEspecialidade;
    }       
    
    
    public void acessar(){
        //todo
    }
    public void mostrar(){
        System.out.println("nome="+ getNome());
        System.out.println("crm="+ getCrm());
        System.out.println("telefone="+ getTelefone());
        System.out.println("esp.="+ getEspecialidade());
        System.out.println("senha="+getSenha() );
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the crm
     */
    public long getCrm() {
        return crm;
    }

    /**
     * @param crm the crm to set
     */
    public void setCrm(long crm) {
        this.crm = crm;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the especialidade
     */
    public String getEspecialidade() {
        return especialidade;
    }

    /**
     * @param especialidade the especialidade to set
     */
    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
}
