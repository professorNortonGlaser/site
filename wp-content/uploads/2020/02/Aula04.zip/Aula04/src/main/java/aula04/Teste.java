/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04;

/**
 *
 * @author professor
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Tratamento obj = new Tratamento();
       float resultado = obj.dividir(5, 0);
       System.out.println("Divisao="
               + resultado);
       
       String frase = obj.concatenar(null, 
               "Fatec");
       System.out.println("Concatenar="
               + frase);
       
    }
    
}
