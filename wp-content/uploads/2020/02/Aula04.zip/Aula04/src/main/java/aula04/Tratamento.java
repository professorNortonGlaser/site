/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula04;

/**
 *
 * @author professor
 */
public class Tratamento {
    public float dividir(float a, float b){
        float r = 0;        
        try{       
            if(b == 0) throw new ArithmeticException("Divisao por zero");
            r = a/b;
        }
        catch(ArithmeticException err){
            System.out.println(err.getMessage());
        }
        return r;
    }
    public String concatenar(String t1, String t2){
        String r = "";        
        try{
            if(!t1.equals(t2)){
                r = t1 + " " + t2;
            }
        }
        catch(NullPointerException err){
            r = "frase vazia";
        }
        finally{
            return r.toUpperCase();
        }        
    }
}
