/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author professor
 */
public class Exame {
    private String consulta;
    private String data;
    private String descritivo;
   
    public Exame(){
        this.consulta = "";
        this.data = "20/02/2020";
        this.descritivo = "";
    }
    
    public Exame(String pC, String pD, String pT)
    {
        this.consulta = pC;
        this.data = pD;
        this.descritivo = pT;
    }
    
    public String getConsulta(){
        return this.consulta;
    }
    public void setConsulta(String p){
        this.consulta = p;
    }
    
    
    public void solicitar(){}
    public void cosultar(){}
    public void mostrar(){
        System.out.println("EXAME===>");
        System.out.println("consulta="+ getConsulta());
        System.out.println("data="+ getData());
        System.out.println("descritivo="+ getDescritivo());
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return the descritivo
     */
    public String getDescritivo() {
        return descritivo;
    }

    /**
     * @param descritivo the descritivo to set
     */
    public void setDescritivo(String descritivo) {
        this.descritivo = descritivo;
    }
}
