/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author professor
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Paciente maria = new Paciente();
        maria.nome = "maria da silva";
        maria.idade = 45;
        maria.mostrar();
        Medico rey = new Medico();
        rey.nome = "Reynivaldo da silva";
        rey.especialidade = "todas";
        rey.mostrar();
        Agenda fev20 = new Agenda();
        fev20.data = "20/02/2020";
        fev20.hora = "20:30";
        fev20.medico ="Rey";
        fev20.paciente = "maria";
        fev20.mostrar();
        
    }
    
}
