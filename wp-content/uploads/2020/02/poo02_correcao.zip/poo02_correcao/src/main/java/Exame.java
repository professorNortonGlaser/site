/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author professor
 */
public class Exame {
     public String consulta;
    public String data;
    public String descritivo;
    public void solicitar(){}
    public void cosultar(){}
    public void mostrar(){
        System.out.println("consulta="+ consulta);
        System.out.println("data="+ data);
        System.out.println("descritivo="+ descritivo);
    }
}
