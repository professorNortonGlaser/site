/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author professor
 */
public class Consulta {
    public String data;
    public String hora;
    public String medico;
    public String paciente;
    public String motivo;
    public String historico;
    public void marcar(){};
    public void cancelar(){};
    public void consultar(){};
    public void realizar(){};
    public void atualizar(){};
    public void mostrar(){
        System.out.println("data="+ data);
        System.out.println("hora="+ hora);
        System.out.println("medico="+ medico);
        System.out.println("paciente="+ paciente);
        System.out.println("motivo="+ motivo);
        System.out.println("historico="+ historico);
    }
    
}
