/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author professor
 */
public class Medico {
    public String nome;
    public long crm;
    public String telefone;
    public String especialidade;
    public String senha;
    public void acessar(){
        //todo
    }
    public void mostrar(){
        System.out.println("nome="+ nome);
        System.out.println("crm="+ crm);
        System.out.println("telefone="+ telefone);
        System.out.println("esp.="+ especialidade);
        System.out.println("senha="+senha );
    }
}
